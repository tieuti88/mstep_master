<?php
/*
 * Copyright 2016 SPC Vietnam Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2017-04-20 15:44:07
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2017-04-20 15:49:57
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepClient extends AppModel{

    var $name = "TblMstepClient";
    var $useTable = "clients";
    var $primaryKey = "id";
    var $useDbConfig="master";
}
