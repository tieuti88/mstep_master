<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-13 14:36:01
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-10-04 23:46:36
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepSiteRemarkTitle extends AppModel{

    var $name       = "TblMstepSiteRemarkTitle";
    var $useTable   = "tbl_mstep_site_remark_titles";
    var $primaryKey = "id";

	function getRemarkTitles(){
	
			$titleRemarks=array();
			if($titles=$this->find('first')) $titleRemarks=$titles["TblMstepSiteRemarkTitle"];

			$titles=tsv("remark_titles.tsv");
			foreach($titles as $k=>$v) if(!isset($titleRemarks[$k]) OR empty($titleRemarks[$k])) $titleRemarks[$k]=$v;
			return $titleRemarks;
	}

}
