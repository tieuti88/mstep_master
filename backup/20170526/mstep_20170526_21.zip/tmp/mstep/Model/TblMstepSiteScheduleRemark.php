<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-23 15:27:42
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-12-26 17:21:16
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 * @package       app.Model
 */
class TblMstepSiteScheduleRemark extends AppModel{

    	var $name      ="TblMstepSiteScheduleRemark";
    	var $useTable  ="tbl_mstep_site_schedule_remarks";
    	var $primaryKey="schedule_id";

		function getScheduleRemarks($schedule_ids=array(),$f=array()){
		
				$current_recursive=$this->recursive;
				$this->recursive=-1;
				$work_details=$this->findAllByScheduleIdAndDelFlg($schedule_ids,0,$f);
				$this->recursive=$current_recursive;
				return $work_details;
		}

}
