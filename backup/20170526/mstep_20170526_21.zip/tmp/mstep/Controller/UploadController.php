<?php
/*
 * Copyright 2016 SPC Vietnam Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2017-04-24 15:17:52
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2017-04-28 09:17:03
 */
App::uses('Folder', 'Utility');
App::uses('File', 'Utility');
class UploadController extends AppController {

    var $name = 'upload';

    public function index($sub_dir = null) {

        $sub_dir = ($this->request->pass)?$this->request->pass:'';

        $str_dir = "/";
        if ($sub_dir) {

            foreach ($sub_dir as $value) {
                $str_dir .= $value."/";
            }
        }

        $dirs = $this->getDirContents(DIR_UPLOAD.$str_dir);

        //arrange results by type is folder
        usort($dirs, function($folder, $file) {

            return strcmp($file["type"], $folder["type"]);
        });

        $this->set(compact('dirs', 'str_dir', 'sub_dir'));
    }

    public function getDirContents($dir = null){

        $files = array();

        if(file_exists($dir)){

            foreach(scandir($dir) as $f) {

                if(!$f || $f[0] == '.') continue;

                if(is_dir($dir . '/' . $f)) {

                    $files[$f] = array(
                        "name" => $f,
                        "type" => "folder",
                        "path" => $dir . '/' . $f,
                        "pare" => str_replace('//', '/', dirname($dir . '/' . $f, 1)),
                        "size" => "",
                        // "items" => $this->getDirContents($dir . '/' . $f), // Recursively get the contents of the folder
                        "exte" => "",
                        "time" => date("F d Y H:i:s.", filemtime($dir . '/' . $f))
                    );
                } else {

                    $files[] = array(
                        "name" => $f,
                        "type" => "file",
                        "path" => $dir . '/' . $f,
                        "pare" => str_replace('//', '/', dirname($dir . '/' . $f, 1)),
                        "size" => filesize($dir . '/' . $f), // Gets the size of this file
                        "exte" => array_key_exists('extension', pathinfo($f)) ? pathinfo($f)['extension'] : "",
                        "time" => date("F d Y H:i:s.", filemtime($dir . '/' . $f))
                    );
                }
            }
        }

        return $files;
    }

    public function uploadFiles() {

        if(!$this->isPostRequest()) exit;

        $request = $_REQUEST;

        if(!empty($request['name'])){
            $fileName = $request['name'];
            $uploadPath = $request['upload_url'];
            //remove / in link upload
            if($uploadPath == '/') $uploadPath = str_replace('/', '', $uploadPath);

            $uploadFile = DIR_UPLOAD.$uploadPath.'/'.$fileName;
            if(move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)){
                Output::__outputYes($fileName);
            }else{
                Output::__outputNo(1);
            }
        }else{
            Output::__outputNo(2);
        }
    }

    public function renameFolder($path = array(), $newName) {
        $oldPath = $this->wwwRoot . implode(DS, $path);
        $nameToChange = array_pop($path);
        array_push($path, $newName);
        $newPath = $this->wwwRoot . implode(DS, $path);
        return rename($oldPath, $newPath);
    }

    public function createFolderUpload() {

        if(!$this->isPostRequest()) exit;
        $post = $_POST;
        $folder_name = $post["folder_name"];
        $folder_path = $post["folder_path"];

        $store_folder_path = DIR_UPLOAD.$folder_path;
        if($folder_path == "/") $store_folder_path = DIR_UPLOAD;

        $relpath = $store_folder_path.DS.$folder_name;

        if (file_exists($relpath)) Output::__outputNo();

        $folder = new Folder($relpath, true, 0775);

        Output::__outputYes();
    }

}
