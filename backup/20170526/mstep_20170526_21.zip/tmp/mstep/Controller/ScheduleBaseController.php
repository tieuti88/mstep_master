<?php

/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

class ScheduleBaseController extends AppController{

		function beforeFilter() {
	
				parent::beforeFilter();
		}

		#
		# @author Kiyosawa
		# @date 2011/05/07 14:44:59
		function beforeRender() {
	
				parent::beforeRender();
		}

		function __checkDateFormat($value){
		
				if(empty($value))       return false;
				if(!is_numeric($value)) return false;
				if(strlen($value)!=8)   return false;
				return true;
		}

		function __isEditAuthority($user_id,$last_edit_time,$local_time_key){

             	$instance_s=ScheduleLog::getInstance($this);
                $current_last_edit_time=$instance_s->getLastEditTime();
				if($last_edit_time!=$current_last_edit_time) throw new Exception(2);

				$instance_t=new TimeoutInvestigationExec($this,$this->Session);
				$check_result=$instance_t->checkLastEditTimeSesKey(UNIQUE_KEY,$user_id);

				if(empty($check_result)){

						if(empty($local_time_key)) throw new Exception(13);
						$bin_key=$instance_s->getBinKey();
						$dec=TimeoutInvestigationKeys::decBinKey($bin_key,$local_time_key);
						if($user_id!=$dec["user_id"] OR $dec["time_key"]=!$local_time_key) throw new Exception(3);
				}

				return true;
		}

		function __parseDateHistory($values=array()){
		
				$dates=array();
				foreach($values as $y=>$v){

						foreach($v as $m=>$_v){
						
								foreach($_v as $k=>$d){
								
										$dates[]=$y.sprintf("%02d",$m).sprintf("%02d",$d);
								}
						}
				}

				sort($dates);
				return $dates;
		}

		function __isEditAuthorityOutput(...$args){

				try{

						$this->__isEditAuthority($args[0],$args[1],$args[2]);

				}catch(Exception $e){

						$error=$e->getMessage();

						switch($error){
								case(1):
								Output::__outputStatus(1);
						break;
								case(2):
								$instance=ScheduleLog::getInstance($this);
								$last_edit_user_id=$instance->getLastEditUser();
			                    $this->TblMstepMasterUser->unbindFully();
		                        if(!$login_user=$this->TblMstepMasterUser->findById($last_edit_user_id)) return true;
		                        $login_user=$login_user["TblMstepMasterUser"];
		                        $user_informations["name"]="{$login_user["first_name"]} {$login_user["last_name"]}";
		                        Output::__outputStatus(2,array(

		                                "user_informations"=>$user_informations

		                        ),array(

		                                "##USER##"=>$user_informations["name"]
		                        ));
						break;
								case(3):
								Output::__outputStatus(3);
						break;
								case(13):
								Output::__outputStatus(13);
						break;
						}
				}

				return true;
		}

		function __getRefreshLastEditTime(){
		
				$instance=ScheduleLog::getInstance($this);
				$res=$instance->updateEditCurrentTime();
				return strtotime($res["TblMstepScheduleLog"]["edit_time"])*1000;
		}

		function __checkPostDataEmpty($post){

				$errors=array();

				foreach($this->requiredParams as $k=>$v){

						if(isset($post[$k]) AND !empty($post[$k])) continue;
						$errors[$k]=$v;
				}

				return $errors;
		}

		function __updateRemarks($site_remark_inserts,$schedule_ids=array()){

				if(empty($site_remark_inserts)){

						$res["schedule_ids"]=$schedule_ids;
						$res["status"]=true;
						return $res;
				}

				$information=array_shift($site_remark_inserts);
				$schedule_id=$information["schedule_id"];

				$save=array();
				$save["schedule_id"]=$information["schedule_id"];
				if(isset($information["remarks1"])) $save["remarks1"]=$information["remarks1"];
				if(isset($information["remarks2"])) $save["remarks2"]=$information["remarks2"];
				if(isset($information["remarks3"])) $save["remarks3"]=$information["remarks3"];
				if(!$this->TblMstepSiteScheduleRemark->save($information)){
				
						$res["status"]=false;
						return $res;
				}

				$schedule_ids[]=$information["schedule_id"];
				return $this->__updateRemarks($site_remark_inserts,$schedule_ids);
		}

		function __getWorkerInsertPrice(&$data=array()){

				$schedule_ids=Set::extract($data,"{}.schedule_id");
				$schedules=$this->TblMstepSiteSchedule->getSchedule($schedule_ids);
				$start_month_prefix=Set::combine($schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_month_prefix");
				$start_days=Set::combine($schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_day");
				$worker_ids=array_unique(Set::extract($data,"{}.worker_id"));
				if(!$res=$this->TblMstepWorkerPrice->findAllByWorkerIdAndDelFlg($worker_ids,0,null,"TblMstepWorkerPrice.date DESC")) return;

				foreach($res as $k=>$v){

						$d=$v["TblMstepWorkerPrice"];
						$mtime=max(0,strtotime($d["date"]));
						if(!isset($worker_price[$d["worker_id"]])) $worker_price[$d["worker_id"]]=array();
						$count=count($worker_price[$d["worker_id"]]);
						$worker_price[$d["worker_id"]][$count]["time"] =$mtime;
						$worker_price[$d["worker_id"]][$count]["price"]=$d["price"];
				}

				foreach($data as $k=>$v){

						$start_month=$start_month_prefix[$v["schedule_id"]];
						$start_day=sprintf("%02d",$start_days[$v["schedule_id"]]);
						$start_date=$start_month.$start_day;
						$t_mtime=strtotime($start_date);
						$worker_id=$v["worker_id"];

						$save_price=0;
						if(!isset($worker_price[$worker_id])){

								$data[$k]["price"]=$save_price;
								continue;
						}

						foreach($worker_price[$worker_id] as $_k=>$_v){

								$s_mtime=$_v["time"];
								if($s_mtime>$t_mtime){

										if(!isset($worker_price[$worker_id][$_k+1])) break;

										$next_values=$worker_price[$worker_id][$_k+1];
										$next_time=$next_values["time"];
										if($t_mtime>=$next_time){

												$save_price=$next_values["price"];
												break;
										}

										continue;
								}

								$save_price=$_v["price"];
								break;
						}

						$data[$k]["price"]=$save_price;
				}
		}

		function __siteWorkerInsert($site_worker_inserts){

				$inserts=array();
				$inserts[0]=array();
				$inserts[1]=array();
				foreach($site_worker_inserts as $k=>$v){

						$is_new=0;
						//if(empty($v["id"]) OR empty($v["assign_flg"])) $is_new=1;
						if(empty($v["id"])) $is_new=1;
						$inserts[$is_new][]=$v;
				}

				//for update.
				if(!empty($inserts[0])){

						$res=$this->__multiInsert($this->TblMstepSiteWorker,$inserts[0]);
						if(empty($res["status"])) return $res;
				}

				//for new regist.
				if(!empty($inserts[1])){

						//refer
						$this->__getWorkerInsertPrice($inserts[1]);
						$res=$this->__multiInsert($this->TblMstepSiteWorker,$inserts[1]);
						if(empty($res["status"])) return $res;
				}

				$res["status"]=true;
				return $res;
		} 

		function __closeDandoriHandlings($is_done,$user_id){
		
				switch(true){

					case(!empty($is_done)):

							$last_edit_time=time();
							$instance=ScheduleLog::getInstance($this);
							if(!$instance->timeInitialize($user_id,$last_edit_time)) Output::__outputStatus(1);
							$last_edit_time=($last_edit_time*1000);
							break;
					default:
							$last_edit_time=$this->__getRefreshLastEditTime();
							break;
				}

				return $last_edit_time;
		}
}

?>
