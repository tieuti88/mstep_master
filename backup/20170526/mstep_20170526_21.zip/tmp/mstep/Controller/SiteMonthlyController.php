<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

class SiteMonthlyController extends AppController{

        var $name = "SiteMonthly";
		var $uses = [
		
				"TblMstepAreaInformation",
				"TblMstepSiteDetail"

		];
	
	public function isAuthorized($user) {
		
		// All registered users can view index and search staff
//		return true;
		if (in_array($this->action, array('index'))) {return true;}
		
		return parent::isAuthorized($user);
	}

        function beforeFilter(){

                parent::beforeFilter();

				// base informations.
				$firstname = $this->Auth->user("first_name");
				$this->set(compact("firstname"));
				$this->__init();
        }

		function __init(){

				$this->unbindFully();
		}

		function __getPeriod($date,$range=4,$format="Ym"){

				$base_ym=date("Ym",strtotime($date."01"));
				$base_time=strtotime($base_ym."01");
				$ym_dates[]=$base_ym;
				for($i=1;$i<$range;$i++){

						$ym_dates[]=date($format,strtotime("- {$i} month",$base_time));
						$ym_dates[]=date($format,strtotime("+ {$i} month",$base_time));
				}

				sort($ym_dates);
				return $ym_dates;
		}

		function getDateRange(){

				if(!$this->isPostRequest()) exit;

				$post=$_POST;
				$start=(!isset($post["start"]))?date("Ym01"):$post["start"];
				$end  =(!isset($post["end"]))?date("Ymt",strtotime($start)):$post["end"];
				$informations=$this->__getDateRange($start,$end);

				$res["data"]["informations"]=$informations;
				$res["status"] = "YES";
				Output::__output($res);
		}

		function getPrevInformations(){

				$post=$this->data;
				$start_date=$post["date"];
				$start_date=date("Ym",strtotime("- 3 month",strtotime($start_date."01")));

				$period=$this->__getPeriod($start_date);
				$informations=$this->__getDateRange((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$res["informations"]=$informations;
				$this->__outputYes($res);
		}

		function getNextInformations(){

				$post=$this->data;
				$start_date=$post["date"];
				$start_date=date("Ym",strtotime("+ 3 month",strtotime($start_date."01")));

				$period=$this->__getPeriod($start_date);

				$informations=$this->__getDateRange((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$res["informations"]=$informations;
				$this->__outputYes($res);
		}

		function getAddDateApi() {

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;
				$date  =isset($post["date"]) ?$post["date"]:date("Ym");
				$month =isset($post["month"])?$post["month"]:"6";

				$start =date("Ym01",strtotime($date."01"));
				$end   =date("Ymt",strtotime("+ {$month} month",strtotime($date."01")));
				$data=$this->__getInformations($start,$end);

				$edit_informations=$this->getLastEditUsers();

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function getSubDateApi() {

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				$date =isset($post["date"])?$post["date"]:date("Ym");
				$month=isset($post["month"])?$post["month"]:"6";

				$end  =date("Ymt",strtotime($date."01"));
				$start=date("Ym01",strtotime("-{$month} month",strtotime($date."01")));
				$data=$this->__getInformations($start,$end);

				$edit_informations=$this->getLastEditUsers();

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function __startDateArgesValidate($start_date){

				if(empty($start_date) OR !is_numeric($start_date) OR strlen($start_date)!=6) return false; 

				$year =substr($start_date,0,4);
				$month=substr($start_date,4,2);
				if(!checkDate($month,"01",$year)) return false;
				return true;
		}

		function getLastEditUsers(){
		
				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$instance=ScheduleGetLastEditSiteUser::getInstance($controller);
				$edit_informations=$instance->getEditUsersInformations();
				return $edit_informations;
		}

		function index($start_date=""){

				if(!$this->__startDateArgesValidate($start_date)) $start_date=date("Ym");

				$user_id  =$this->Auth->user("id");
				$pref_id  =$this->Auth->user('pref_id');
				$period=$this->__getPeriod($start_date);

				$data=$this->__getInformations((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$informations=$data["informations"];
				$site_ids=$data["data"]["site_ids"];

				$edit_informations=$this->getLastEditUsers();

				$site_ids=array();
				if(!empty($informations)) $site_ids=array_values(array_unique(array_filter(Set::classicExtract($informations,"{[a-zA-Z0-9-_.]}.0.site_detail.id"),"strlen")));
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$weather=$this->__getImageByWeatherDate($pref_id);

				//remark title
				$remark_titles=$this->__getRemarkTitles();

		        //prefs
				$tsv=new TSV();
				$prefs=$tsv->getTSV("pref");
			
			//■memo
			$memos=$this->__getMemoList();
			
				//color
				$color_list=$this->__getColorList(false);

				$instance=ScheduleLog::getInstance($this);
				$last_edit_time =$instance->getLastEditTime();
				$last_start_user=$instance->getLastStartUser();
				$edit_time_expired_ms=$instance->getLastEditTimeExpireMs();
				$last_edit_user_id=$instance->getLastEditUser();

				//■user edited last imformation.
				$last_modified_user=array();
				if(!empty($last_edit_user_id)){ 

						$last_modified_user=$this->__getLastModifiedInformations($last_edit_user_id);
						$last_modified_user["last_edit_ms"]=$last_edit_time;
						$last_modified_user["edit_time_expired"]=$edit_time_expired_ms;
				}

				$user_id=$this->Auth->user("id");
				$is_authority=$this->__checkAuthorityToEdit($user_id)?1:0;

				$weather      =mstepJsonEncode($weather);
				$remark_titles=mstepJsonEncode($remark_titles);
				$edit_informations=mstepJsonEncode($edit_informations);
				$informations =mstepJsonEncode($informations);
				$last_modified_user=mstepJsonEncode($last_modified_user);
				$prefs        =mstepJsonEncode($prefs);
				$color_list   =mstepJsonEncode($color_list);
				$ninku_situations=mstepJsonEncode($ninku_situations);
			$memos =               mstepJsonEncode($memos);

				$this->set(compact("remark_titles",
								   "informations",
								   "is_authority",
								   "edit_informations",
								   "last_modified_user",
								   "ninku_situations",
								   "last_edit_time",
								   "edit_time_expired_ms",
								   "last_start_user",
								   "weather",
								   "prefs",
				"memos",
								   "color_list",
								   "start_date",
								   "user_id"));
		}

		function __getRemarkTitles(){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				return $controller->__getRemarkTitles();
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();

				$is_worker_senior=$this->__isWorkerSenior();
				$worker_id       =$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id,
						"is_worker_senior"=>$is_worker_senior
				));
				return $res;
		}

		function __getColorList($is_set){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getColorList($is_set);
				return $res;
		}

        function __getImageByWeatherDate($user_pref_id) {

				App::uses("SiteManagesWeatherController","Controller");
				$controller=new SiteManagesWeatherController();
				$res=$controller->__getImageByWeatherDate($user_pref_id);
				return $res;
        }

        function __getLastModifiedInformations($last_edit_user_id){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getLastModifiedInformations($last_edit_user_id);
				return $res;
        }

		function __getSiteNinkuSituations($site_ids=array()) {
	
				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __checkAuthorityToEdit($user_id){
	
				$time_key=$this->Session->read(TimeoutInvestigationKeys::makeTimeSesKey(UNIQUE_KEY));
				//v($time_key,1);
	
				App::uses("SiteManagesEditAuthoritiesController","Controller");
				$controller=new SiteManagesEditAuthoritiesController();
				$is_edit=$controller->__checkAuthorityToEditWithDeadline($user_id,$time_key);
				return $is_edit;
		}

		function __getDateRange($start,$end){

				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$is_worker_senior=$this->__isWorkerSenior();
				$res=$controller->__getDateRange($start,$end,$worker_id,$is_worker_senior);
				return $res;
		}
	
	
	
	function __getMemoList() {
		
		App::uses("SiteManagesMemoController", "Controller");
		$controller = new SiteManagesMemoController();
		$res = $controller->__getMemoList();
		return $res;
	}


}//END class

?>
