<?php

/**
 * Created by PhpStorm.
 * User: Edward
 * Date: 5/12/17
 * Time: 1:21 PM
 */
class ScheduleReportController extends AppController {
    var $name = 'ScheduleReport';
    
    public function beforeFilter() {
        
        $this->Auth->allow('viewReport');
    
        parent::beforeFilter();
    }
    
    
    public function viewReport(){

        $this->layout = false;
        if(!$this->params['file']) { die('File not found.'); }
        $file_name=$this->params['file'];
        $file_path=SCHEDULE_REPORT_CONTENT_PATH.DS.$file_name;
        if(!file_exists($file_path)) { die('File not found.'); }
        $content=file_get_contents($file_path);
        $this->set('file_content',$content);
    }
    
    public function index(){}
}
