<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleNinku.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

App::uses('ScheduleBaseController','Controller');
class SiteManagesInformationRegistsController extends ScheduleBaseController{

        var $name = "SiteManagesInformationRegists";
		var $allScheduleDetails=array();
		var $sendInformations=array();
        var $uses = [

				"TblMstepGroupWorker",
				"TblMstepWorker",
				"TblMstepSiteSchedule",
				"TblMstepSiteWorker",
				"TblMstepScheduleTruck",
				"TblMstepSiteDetail",
				"TblMstepAreaInformation",
				"TblMstepScheduleTruck",
				"TblMstepSiteScheduleRemark",
				"TblMstepMasterUser",
                "TblMstepWorkerPrice"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				if(!defined("TMP_PREFIX")) define("TMP_PREFIX","TMP_");
				if(!defined("SCHEDULE_TYPE_NORMAL"))  define("SCHEDULE_TYPE_NORMAL","NORMAL");
				if(!defined("SCHEDULE_TYPE_VISIBLE")) define("SCHEDULE_TYPE_VISIBLE","VISIBLE");
				if(!defined("SCHEDULE_TYPE_REMOVE"))  define("SCHEDULE_TYPE_REMOVE","REMOVE");
				//$this->unbindFully();
		}

		function __scheduleIDs($schedule_ids=array()){

				$res["copy"]=array_filter($schedule_ids,function($a){

						return is_numeric(strpos($a,TMP_PREFIX));
				});

				$res["normal"]=$all_schedule_ids=array_filter($schedule_ids,function($a){

						return !is_numeric(strpos($a,TMP_PREFIX));
				});

				sort($res["copy"]);
				sort($res["normal"]);
				return $res;
		}

		function __setInformations($informations=array()){

				$this->sendInformations=$informations;
		}

		function __setSchedules($schedule_ids=array()){

				$this->TblMstepSiteSchedule->unbindFully();
				$all_schedules=$this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_ids,0);
				$this->allScheduleDetails=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule");
		}

		function __addScheduleByCopy($site_id,$schedule_ids=array(),$insert_ids=array()){

				if(1>count($schedule_ids)){

						return $insert_ids;
				}

				$tmp_schedule_id=array_shift($schedule_ids);
				$schedule_id=explode("_",$tmp_schedule_id)[1];
				$schedule=$this->allScheduleDetails[$schedule_id];
				$options=$this->sendInformations[$tmp_schedule_id];

				$save["site_id"]=$site_id;
				$save["schedule_id"]=$schedule_id;
				$save["color_id"]=$options["color"];
				$save["position_num"]=$options["options"]["position_num"];
				$save["start_month_prefix"]=date("Ym",strtotime($options["options"]["day"]));
				$save["start_day"]   =date("j",strtotime($options["options"]["day"]));
				$save["start_date"]  =date("Y/m/d 00:00:00",strtotime($options["options"]["day"]));
				$save["end_date"]    =$save["start_date"];
				$this->TblMstepSiteSchedule->id=null;
				if(!$this->TblMstepSiteSchedule->save($save)) return false;

				$last_id=$this->TblMstepSiteSchedule->getLastInsertID();
				$insert_ids[$tmp_schedule_id]=$last_id;
				return $this->__addScheduleByCopy($site_id,$schedule_ids,$insert_ids);
		}

		function __changeToNormalScheduleIdKeyFromCopy(&$schedule_ids,$map_values=array()){

				foreach($schedule_ids as $k=>$__schedule_id){

						if(!isset($map_values[$__schedule_id])) continue;
						$index=array_search($__schedule_id,$schedule_ids);
						$schedule_ids[$index]=(Int)$map_values[$__schedule_id];
				}
		}

		function __changeToNormalScheduleIdKeyFromCopyInformation($map_values=array()){

				foreach($this->sendInformations as $__schedule_id=>$v){

						if(!isset($map_values[$__schedule_id])) continue;
						$schedule_id=$map_values[$__schedule_id];
						unset($this->sendInformations[$__schedule_id]);
						$this->sendInformations[$schedule_id]=$v;
				}
		}

		function informationsRegist(){

				if(!$this->isPostRequest()) exit;

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				$user_id=$post["user_id"];
				$site_id     =$post["site_id"];
				$informations=$post["informations"];
				$all_schedule_ids=array_keys($informations);
				$schedule_ids=$this->__scheduleIDs($all_schedule_ids);
				$normal_schedule_ids=$schedule_ids["normal"];
				$copy_schedule_ids  =$schedule_ids["copy"];
				$around_value=(isset($post["around_value"]) AND is_numeric($post["around_value"]))?$post["around_value"]:false;
				$local_time_key=isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;
	
				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				//set schedules.
				$this->__setSchedules($normal_schedule_ids);
				$this->__setInformations($informations);

				$worker_id_histories=$this->__workerRegistedIdHistory($all_schedule_ids);
				$truck_id_histories=$this->__truckRegistedIdHistory($all_schedule_ids);
	            $datasource=$this->TblMstepSiteWorker->getDataSource();
	            $datasource->begin();

				if(!is_bool($around_value)){

						$inserts[$site_id]=$around_value;
						$res=$this->TblMstepSiteDetail->updateAroundValues($inserts);
						if(empty($res["status"])) Output::__outputStatus(1);
				}

				//copy.
				$insert_copy_ids=array();
				if(!empty($copy_schedule_ids)){

						$insert_copy_ids=$this->__addScheduleByCopy($site_id,$copy_schedule_ids);
						if(empty($insert_copy_ids)) Output::__outputStatus(1);

						//change from type of copy to normal about schedule_id.
						$this->__changeToNormalScheduleIdKeyFromCopy($all_schedule_ids,$insert_copy_ids);
						$this->__changeToNormalScheduleIdKeyFromCopyInformation($insert_copy_ids);
				}

				// worker.
				$res=$this->TblMstepSiteWorker->deleteSiteWorkerBySiteID($site_id,$all_schedule_ids);
				if(empty($res["status"])) Output::__outputNo(1);
				$site_worker_inserts=$this->__insertWorkerArray(array(

						"id_histories"=>$worker_id_histories,
						"site_id"     =>$site_id
				));

				// truck.
				$res=$this->TblMstepScheduleTruck->deleteSiteTrucks($site_id,$all_schedule_ids);
				if(empty($res["status"])) Output::__outputNo(1);
				$site_truck_inserts=$this->__insertTruckArray(array(

						"id_histories"=>$truck_id_histories,
						"site_id"     =>$site_id
				));

				//color. remarks. primary key is schedule_id.
				$site_color_inserts =$this->__insertColorArray();
				$site_remark_inserts=$this->__insertRemarkArray();
				$site_option_inserts=$this->__insertOptionsArray();

				$res["status"]=true;
				if(!empty($site_option_inserts)) $res=$this->__multiInsert($this->TblMstepSiteSchedule,$site_option_inserts);
				if(empty($res["status"])) Output::__outputStatus(5);

				if(!empty($site_worker_inserts)){ 

						$res=$this->__siteWorkerInsert($site_worker_inserts);
						//$res=$this->__multiInsert($this->TblMstepSiteWorker,$site_worker_inserts);
						if(empty($res["status"])) Output::__outputStatus(5);
				}

				$res["status"]=true;
				if(!empty($site_truck_inserts)) $res=$this->__multiInsert($this->TblMstepScheduleTruck,$site_truck_inserts);
				if(empty($res["status"])) Output::__outputStatus(5);

				$res["status"]=true;
				if(!empty($site_color_inserts)) $res=$this->__multiInsert($this->TblMstepSiteSchedule,$site_color_inserts);
				if(empty($res["status"])) Output::__outputStatus(5);

				$res["status"]=true;
				if(!empty($site_remark_inserts)) $res=$this->__updateRemarks($site_remark_inserts);
				if(empty($res["status"])) Output::__outputStatus(5);

				$datasource->commit();
				
				$refresh_ninku_siteids=$this->__refreshNinku($informations);

				// edit information.
				$edit_detail[$site_id]=array("edit_user_id"=>$user_id,"modified"=>date("Y/m/d H:i:s"));
				$instance=new ScheduleGetLastEditSiteUser($this);
				$instance->setSiteInformations($edit_detail);
				$edit_informations=$instance->getEditUsersInformations();

				// range of date for site_id.
				$schedule_range=$this->TblMstepSiteSchedule->getRangeDataBySiteId($site_id);

				$ninku_situations=$this->__getSiteNinkuSituations($refresh_ninku_siteids);

				$schedule_info=$post["schedule_info"];
				$start_date=min($schedule_info["start_date"],date("Ymd",strtotime($schedule_range["min"])));
				$end_date  =max($schedule_info["end_date"]  ,date("Ymd",strtotime($schedule_range["max"])));
				$informations=$this->__getInformations($start_date,$end_date);

				$last_edit_time=$this->__getRefreshLastEditTime();

				$output["insert_copy_ids"] =$insert_copy_ids;
				$output["ninku_situations"]=$ninku_situations;
				$output["informations"]    =$informations["informations"];
				$output["edit_information"]=$edit_informations;
				$output["last_edit_time"]  =$last_edit_time;
				Output::__outputYes($output);
		}

		function __insertOptionsArray(){

				$inserts=array();
				$counter=0;
				foreach($this->sendInformations as $schedule_id=>$v){

						if(!isset($v["options"]) OR $v["options"]["type"]==SCHEDULE_TYPE_NORMAL) continue;
						if(is_numeric(strpos($schedule_id,TMP_PREFIX))) continue;
						$type=$v["options"]["type"];
						$inserts[$counter]["id"]=$schedule_id;
						$s=strtotime($v["options"]["day"]);
						$inserts[$counter]["position_num"]=$v["options"]["position_num"];
						$inserts[$counter]["start_month_prefix"]=date("Ym",$s);
						$inserts[$counter]["start_day"]=date("j",$s);
						$inserts[$counter]["del_flg"]=(($type==SCHEDULE_TYPE_REMOVE)?1:0);
						$inserts[$counter++]["start_date"]=date("Y/m/d 00:00:00",$s);
				}

				return $inserts;
		}

		function __insertRemarkArray(){

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["remarks"])) continue;
						$remarks=$values["remarks"];
						$inserts[$counter]["schedule_id"]=$schedule_id;
						if(isset($remarks["remarks1"])) $inserts[$counter]["remarks1"]=$remarks["remarks1"];
						if(isset($remarks["remarks2"])) $inserts[$counter]["remarks2"]=$remarks["remarks2"];
						if(isset($remarks["remarks3"])) $inserts[$counter]["remarks3"]=$remarks["remarks3"];
						$counter++;
				}

				return $inserts;
		}

		function __insertColorArray(){

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						$inserts[$counter]["id"]=$schedule_id;
						$inserts[$counter++]["color_id"]=$values["color"];
				}

				return $inserts;
		}

		function __insertTruckArray($params=array()){

				$site_id     =$params["site_id"];
				$id_histories=$params["id_histories"];

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["trucks"])) continue;
						$truck_ids=$values["trucks"];
						foreach($truck_ids as $k=>$truck_id){

								$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$truck_id])?$id_histories[$site_id][$schedule_id][$truck_id]:"");
								$inserts[$counter]["site_id"]=$site_id;
								$inserts[$counter]["schedule_id"]=$schedule_id;
								$inserts[$counter]["del_flg"]=0;
								$inserts[$counter++]["truck_id"]=$truck_id;
						}
				}

				return $inserts;
		}

		function __insertWorkerArray($params=array()){

				$site_id     =$params["site_id"];
				$id_histories=$params["id_histories"];

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["workers"])) continue;
						$worker_ids=$values["workers"];
						$leaders   =(isset($values["leader"])?$values["leader"]:array());
						foreach($worker_ids as $k=>$worker_id){

								$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$worker_id])?$id_histories[$site_id][$schedule_id][$worker_id]:"");
								$inserts[$counter]["site_id"]=$site_id;
								$inserts[$counter]["schedule_id"]=$schedule_id;
								$inserts[$counter]["del_flg"]=0;
								$inserts[$counter]["assign_flg"]=1;
								$inserts[$counter]["leader_flg"]=(isset($leaders[$worker_id])?$leaders[$worker_id]:0);
								$inserts[$counter++]["worker_id"]=$worker_id;
						}
				}

				return $inserts;
		}

		function __truckRegistedIdHistory($schedule_ids=array()){

				$this->TblMstepScheduleTruck->unbindFully();
				//if(!$site_workers=$this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();
				if(!$site_workers=$this->TblMstepScheduleTruck->findAllByScheduleId($schedule_ids)) return array();

				$ids=array();
				foreach($site_workers as $k=>$v){

						$data=$v["TblMstepScheduleTruck"];
						$ids[$data["site_id"]][$data["schedule_id"]][$data["truck_id"]]=$data["id"];
				}

				return $ids;
		}

		function __workerRegistedIdHistory($schedule_ids=array()){

				$this->TblMstepSiteWorker->unbindFully();
				//if(!$site_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();
				if(!$site_workers=$this->TblMstepSiteWorker->findAllByScheduleId($schedule_ids)) return array();

				$ids=array();
				foreach($site_workers as $k=>$v){

						$data=$v["TblMstepSiteWorker"];
						$ids[$data["site_id"]][$data["schedule_id"]][$data["worker_id"]]=$data["id"];
				}

				return $ids;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$is_worker_senior=$this->__isWorkerSenior();
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id,
						"is_worker_senior"=>$is_worker_senior
				));
				return $res;
		}

		function __getSiteNinkuSituations($site_ids=array()) {

				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __refreshNinku($informations){

				$refresh_ninku_date=array();
				foreach($informations as $k=>$v){
				
						if(empty($v["is_worker_edit"])) continue;
						$refresh_ninku_date[]=$v["options"]["day"];
				}

				if(empty($refresh_ninku_date)){
				
						return array(); 
				}

				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($refresh_ninku_date);
				if(empty($inserts)) return array();
				$res=$this->__multiInsert($this->TblMstepSiteWorker,$inserts);
				return array_unique(Set::extract($inserts,"{}.site_id"));
		}

}//END class

?>
