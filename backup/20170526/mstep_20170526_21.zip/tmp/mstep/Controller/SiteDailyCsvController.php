<?php

class SiteDailyCsvController extends AppController{

        var $name = "SiteDailyCsv";
		var $uses = [
		
				"TblMstepSiteSchedule",
				"TblMstepSiteDetail",
				"TblMstepSiteRemarkTitle",
				"TblMstepSiteScheduleRemark",
				"TblMstepAreaInformation",
				"TblMstepCustomer",
				"TblMstepWorker",
				"TblMstepTruck"
		];

		var $csvInititalTitles=array("現場名","スタッフ","住所","配車","顧客名");
	
		public function isAuthorized($user) {
			
				return true;
		}

        function beforeFilter(){

				$this->__init();
        }

		function __init(){
		
				$remark_titles=$this->TblMstepSiteRemarkTitle->findOne();
				$this->csvInititalTitles[]=$remark_titles["TblMstepSiteRemarkTitle"]["site_remark1"];
				$this->csvInititalTitles[]=$remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark1"];
				$this->csvInititalTitles[]=$remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark2"];
				$this->csvInititalTitles[]=$remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark3"];
		}

		function __getSchedule($date){

				$timestamp=strtotime($date);
				$ym=date("Ym",$timestamp);
				$d=date("d",$timestamp);

				$w=null;
				$w["and"]["TblMstepSiteSchedule.start_month_prefix"]=$ym;
				$w["and"]["TblMstepSiteSchedule.start_day"]=$d;
				$w["and"]["TblMstepSiteSchedule.del_flg"]=0;
				$order="TblMstepSiteSchedule.position_num ASC";
				if(!$data=$this->TblMstepSiteSchedule->findAll($w,null,$order)) return array();
				return $data;
		}

		function __getScheduleCombine($date){

				if(!$schedules=$this->__getSchedule($date)) return array();

				$worker_ids=array();
				$truck_ids =array();
				$customer_ids=array();
				$schedule_ids=array();
				$area_ids=array();
				foreach($schedules as $k=>$v){

						if(!empty($v["TblMstepSiteWorker"])) $worker_ids=array_merge($worker_ids,Set::extract($v["TblMstepSiteWorker"],"{}.worker_id"));
						if(!empty($v["TblMstepScheduleTruck"])) $truck_ids=array_merge($truck_ids,Set::extract($v["TblMstepScheduleTruck"],"{}.truck_id"));
						$customer_ids[]=$v["TblMstepSiteDetail"]["customer_id"];
						$schedule_ids[]=$v["TblMstepSiteSchedule"]["id"];
						$area_ids[]=$v["TblMstepSiteDetail"]["area_id"];
				}

				$workers=array();
				if(!empty($worker_ids)){
				
						$this->TblMstepWorker->unbindFully();
						$workers=$this->TblMstepWorker->findAllById($worker_ids);
						$workers=Set::combine($workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker");
				}

				$trucks=array();
				if(!empty($truck_ids)){
				
						$this->TblMstepTruck->unbindFully();
						$trucks=$this->TblMstepTruck->findAllById($truck_ids);
						$trucks=Set::combine($trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck");
				}

				$customers=array();
				if(!empty($customer_ids)){
				
						$customer_ids=array_unique($customer_ids);
						$customers=$this->TblMstepCustomer->getCustomerInfomration($customer_ids);
						$customers=Set::combine($customers,"{n}.TblMstepCustomer.id","{n}.TblMstepCustomer");
				}

				$areas=array();
				if(!empty($area_ids)){
				
						$areas=$this->TblMstepAreaInformation->getWorkArea($area_ids);
						$areas=Set::combine($areas,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation");
				}

				$remarks=array();
				if($_remarks=$this->TblMstepSiteScheduleRemark->getScheduleRemarks($schedule_ids)){
				
						$remarks=Set::combine($_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");
				}

				foreach($schedules as $k=>$v){

						if(isset($areas[$v["TblMstepSiteDetail"]["area_id"]])) $schedules[$k]["TblMstepSiteDetail"]["area"]=$areas[$v["TblMstepSiteDetail"]["area_id"]];

						foreach($v["TblMstepSiteWorker"] as $_k=>$_v) $schedules[$k]["TblMstepSiteWorker"][$_k]["worker"]=$workers[$_v["worker_id"]];
						foreach($v["TblMstepScheduleTruck"] as $_k=>$_v) $schedules[$k]["TblMstepScheduleTruck"][$_k]["truck"]=$trucks[$_v["truck_id"]];
						if(isset($customers[$v["TblMstepSiteDetail"]["customer_id"]])){
						
								$schedules[$k]["TblMstepSiteDetail"]["customer"]=$customers[$v["TblMstepSiteDetail"]["customer_id"]];
						}

						if(isset($remarks[$v["TblMstepSiteSchedule"]["id"]])){
						
								$schedules[$k]["TblMstepSiteSchedule"]["remarks1"]=$remarks[$v["TblMstepSiteSchedule"]["id"]]["remarks1"];
								$schedules[$k]["TblMstepSiteSchedule"]["remarks2"]=$remarks[$v["TblMstepSiteSchedule"]["id"]]["remarks2"];
								$schedules[$k]["TblMstepSiteSchedule"]["remarks3"]=$remarks[$v["TblMstepSiteSchedule"]["id"]]["remarks3"];
						}
				}

				return $schedules;
		}

		function __replace($csv=array()){

				return array_map(function($s){
				
						$s=array_map(function($s){

								$s=trim($s);
								$s=str_replace(",","、",$s);
								//$s=str_replace(array("\r\n","\r","\n"),"",$s);
								//$s=str_replace(array("\r\n","\r","\n"),chr(10),$s);
								$s=str_replace(array("\r\n","\r","\n")," ",$s);
								$s=mb_convert_encoding($s,"SJIS-win",mb_detect_encoding($s));
								return $s;
	
						},$s);

						return implode(",",$s);

				},$csv);
		}

		function __createCSV($schedules){

				$csv=array();
				$csv[]=$this->csvInititalTitles;
				foreach($schedules as $k=>$v){

						$workers=$v["TblMstepSiteWorker"];
						$trucks =$v["TblMstepScheduleTruck"];
						$__csv=array();
						$__csv[]=$v["TblMstepSiteDetail"]["name"];

						$__workers=array();
						foreach($workers as $_k=>$_v) $__workers[]=!empty($_v["worker"]["nickname"])?$_v["worker"]["nickname"]:$_v["worker"]["first_name"];
						$__csv[]=implode(" ",$__workers);

						$__area="";
						if(isset($v["TblMstepSiteDetail"]["area"])) $__area=$v["TblMstepSiteDetail"]["area"]["pref"].$v["TblMstepSiteDetail"]["area"]["address1"];
						$__area.=!empty($v["TblMstepSiteDetail"]["address"])?$v["TblMstepSiteDetail"]["address"]:"";
						$__csv[]=$__area;

						$__trucks=array();
						foreach($trucks as $_k=>$_v) $__trucks[]=!empty($_v["truck"]["name"])?$_v["truck"]["name"]:"";
						$__csv[]=implode(" ",$__trucks);

						$__csv[]=!empty($v["TblMstepSiteDetail"]["customer"]["name"])?$v["TblMstepSiteDetail"]["customer"]["name"]:"";
						$__csv[]=$v["TblMstepSiteDetail"]["remarks"];
						$__csv[]=isset($v["TblMstepSiteSchedule"]["remarks1"])?$v["TblMstepSiteSchedule"]["remarks1"]:"";
						$__csv[]=isset($v["TblMstepSiteSchedule"]["remarks2"])?$v["TblMstepSiteSchedule"]["remarks2"]:"";
						$__csv[]=isset($v["TblMstepSiteSchedule"]["remarks3"])?$v["TblMstepSiteSchedule"]["remarks3"]:"";
						$csv[]=$__csv;
				}

				$csv=$this->__replace($csv);
				$csv=implode("\n",$csv);
				return $csv;
		}

		function csvDl(){

				$post=$_POST;
				$date=$post["date"];
				//$date="20170427";

				if(!is_numeric($date)) exit;
				$schedules=$this->__getScheduleCombine($date);
				//$data="\xef\xbb\xbf";
				//$data=pack('C*',0xFE,0xFF);
				//$data=pack('C*',0xEF,0xBB,0xBF);
				$data=$this->__createCSV($schedules);

				//header("Content-Type: application/octet-stream");
				//header("Content-Disposition: attachment; filename={$date}.csv"); 
				//header("Content-Type:text/csv;charset=UTF-8"); 
				//header("Content-Transfer-Encoding: binary");
				//header("Content-Length: ".strlen($csv));

				/*
				ob_start();
				$fp=fopen('php://output','w');
				fwrite($fp,"\xef\xbb\xbf");
				//foreach($csv as $output) fputcsv($fp,explode(",",$output),',','"');
				foreach($csv as $output) fputcsv($fp,explode(",",$output));
				fclose($fp);
				$data=ob_get_clean();
				 */

				$filename=CLIENT."_".$date.".csv";
				$file=WWW_ROOT."csv".DS.$filename;
				file_put_contents($file,$data);

				$output=array();
				$output["filename"]=$filename;
				Output::__outputYes($output);
		}
}
