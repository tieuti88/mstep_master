<?php

class CheckDateSamePositioningsController extends AppController {

		public $all_clients;
		private $isClient;

        function beforeFilter(){

				$this->__init();
		}

		function __init(){

				$this->loadModel("TblMasterClientProfile");
				$this->loadModel("TblMasterProfile");
				$this->loadModel("TblMstepSiteSchedule");
				$this->loadModel("TblMstepSiteDetail");

				$this->isClient=(PHP_SAPI=="cli");
				if(!$this->isClient) $this->Auth->allow("samePositioningText");
				$this->all_clients=$this->TblMasterProfile->findAllByDelFlg(0);
		}

		function samePositioningConsole(){

				if(!$this->isClient) exit;
				$same_positions=$this->samePositioning();
				return ((empty($same_positions))?"0":"1");
		}

		function samePositioningText(){

				if($this->isClient) exit;
				$same_positions=$this->samePositioning();
				$text=$this->__text($same_positions);
				header("content-type:text/plain;charset=utf8");
            	echo $text;
				exit;
		}

		function samePositioning(){

				set_time_limit(0);

				$all_clients=$this->all_clients;
				if(empty($all_clients)) exit;

				$all_clients=Set::extract($all_clients,"{}.TblMasterProfile");
				$results=$this->__sameAllPositioning($all_clients);
				$same_positions=$this->__filter($results);
				return $same_positions;
		}

		function __filter($data){

				$same_positions=array();
				foreach($data as $client_name=>$v){

						foreach($v as $date=>$position_ids){

								$c=count($position_ids);
								$u=count(array_unique($position_ids));
								if($c==$u) continue;
								$unique=array_count_values($position_ids);
								$error_positions=array();
								foreach($unique as $position_num=>$count){
								
										if(2>$count) continue;
										$error_positions[]=$position_num;
								}

								$same_positions[$client_name][$date]=$error_positions;
						}
				}

				return $same_positions;
		}

		function __text($data){

				if(empty($data)) return "CORRECT";

				$all_titles=$this->__siteAllTitles($data);

				$text="";
				foreach($data as $client_name=>$v){
				
						$client_text="";
						$client_text.="【{$client_name}】\n\n";
						foreach($v as $date=>$_v){

								$text_date=date("Y/m/d",strtotime($date));
								$client_text.="[{$text_date}]------\n";
								foreach($_v as $site_id=>$schedule_ids){
								
										$site_name=$all_titles[$client_name][$site_id];
										$count=count($schedule_ids);
										$text_schedule_ids=implode(",",$schedule_ids);
										$client_text.="SiteName:{$site_name}\n";
										$client_text.="MissCount:{$count}count({$text_schedule_ids})\n";
								}
						}

						$client_text.="\n\n";
				}

				return $client_text;
		}

		function __siteAllTitles($same_positions){

				$all_clients=$this->all_clients;
				$db_configs=Set::combine($all_clients,"{n}.TblMasterProfile.short_name","{n}.TblMasterProfile");

				$all_titles=array();
				foreach($same_positions as $client_name=>$v){

						$site_ids=array();
						foreach($v as $date=>$_v) $site_ids=array_merge(array_keys($_v),$site_ids);
						$db_config=$db_configs[$client_name];

						$titles=$this->__siteTitle(array(

								"db_host"=>$db_config["db_host"],
								"db_user"=>$db_config["db_user"],
								"db_password"=>$db_config["db_password"],
								"db_name"=>$db_config["db_name"]

						),$site_ids);

						$all_titles[$client_name]=$titles;
				}

				return $all_titles;
		}

		function __siteTitle($config,$site_ids=array()){

				$host=$config["db_host"];
				$user=$config["db_user"];
				$pass=$config["db_password"];
				$db  =$config["db_name"];

				$this->TblMstepSiteDetail->unbindFully();
				$this->TblMstepSiteDetail->changeConnection($host,$user,$pass,$db);
				$this->TblMstepSiteDetail->setDataSource($db);
				$result=$this->TblMstepSiteDetail->findAllByIdAndDelFlg($site_ids,0);
				$this->TblMstepSiteDetail->dropChangeDataSource($db);
				$titles=Set::combine($result,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail.name");
				return $titles;
		}

		function __sameAllPositioning($all_clients=array(),$results=array()){
		
				if(empty($all_clients)) return $results;
				$clients=array_shift($all_clients);
				$result=$this->__samePositioning($clients);
				$results[$clients["short_name"]]=$result;
				return $this->__sameAllPositioning($all_clients,$results);
		}

		function __findSchedules($clients){

				$host=$clients["db_host"];
				$user=$clients["db_user"];
				$pass=$clients["db_password"];
				$db  =$clients["db_name"];

				$this->TblMstepSiteSchedule->unbindFully();
				$this->TblMstepSiteSchedule->changeConnection($host,$user,$pass,$db);
				$this->TblMstepSiteSchedule->setDataSource($db);
				$result=$this->TblMstepSiteSchedule->findAllByDelFlg(0);
				$this->TblMstepSiteSchedule->dropChangeDataSource($db);
				return $result;
		}

		function __makeSamePositioningDateAry($result){

				$days=array();
				foreach($result as $k=>$v){

						$id       =$v["TblMstepSiteSchedule"]["id"];
						$site_id  =$v["TblMstepSiteSchedule"]["site_id"];
						$start_day=sprintf("%02d",$v["TblMstepSiteSchedule"]["start_day"]);
						$position_num=$v["TblMstepSiteSchedule"]["position_num"];
						$start_month_prefix=$v["TblMstepSiteSchedule"]["start_month_prefix"];
						$day=$start_month_prefix.$start_day;
						if(!isset($days[$day])) $days[$day]=array();
						$days[$day][]=$position_num;
				}

				return $days;
		}

		function __samePositioning($clients){

				$result=$this->__findSchedules($clients);
				if(empty($result)) return array();
				return $this->__makeSamePositioningDateAry($result);
		}

}
