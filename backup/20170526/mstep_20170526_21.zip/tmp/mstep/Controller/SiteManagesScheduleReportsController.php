<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */
require_once "MstepCakeEmail.php";
//require_once(dirname(ROOT).DS."sendgrid-php".DS."sendgrid-php.php");

class SiteManagesScheduleReportsController extends AppController{

        var $name = "SiteManagesScheduleReports";
        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepCustomer",
				"TblMstepSiteSchedule",
				"TblMstepSiteRemarkTitle",
				"TblMstepWorker",
				"TblMstepCustomer",
				"TblMstepTruck",
				"TblMstepSiteWorker",
				"TblMstepSiteScheduleRemark",
				"TblMstepAreaInformation",
				"TblMasterClientProfile"
        ];

		var $titles=array();
		var $informations=array();
		var $emptySpace=" ";
		private $tpl="";

        function beforeFilter(){

                parent::beforeFilter();

				$this->__init();
				$this->__setTpl();
        }

		function __setTpl(){
		
				$this->tpl="Information Report(%y/%m/%d)\n\n%url";
		}

		function __getTpl($url,$dates=array()){

				$tpl=$this->tpl;
				$tpl=str_replace("%y",(isset($dates["y"])?$dates["y"]:""),$tpl);
				$tpl=str_replace("%m",(isset($dates["m"])?$dates["m"]:""),$tpl);
				$tpl=str_replace("%d",(isset($dates["d"])?$dates["d"]:""),$tpl);
				$tpl=str_replace("%url",$url,$tpl);
				return $tpl;
		}

		function __init(){
				
				define("SITE_NAME","siteName");
				define("CUSTOMER_NAME","customerName");
				define("SITE_SCHEDULE","siteSchedule");
				define("SITE_ADDRESS","siteAddress");
				define("SITE_ADDRESS_MAP_URL","siteAddressMapUrl");
				define("SCHEDULE_WORKER","scheduleWorker");
				define("SCHEDULE_TRUCK","scheduleTruck");
				define("SITE_REMARK","siteRemark");
				define("SCHEDULE_REMARK1","scheduleRemark1");
				define("SCHEDULE_REMARK2","scheduleRemark2");
				define("SCHEDULE_REMARK3","scheduleRemark3");

				$this->titles[SITE_NAME]         ="現場名";
				$this->titles[CUSTOMER_NAME]     ="顧客名";
				$this->titles[SITE_SCHEDULE]     ="日程";
				$this->titles[SITE_ADDRESS]      ="場所";
				$this->titles[SITE_ADDRESS_MAP_URL]="現地詳細";
				$this->titles[SCHEDULE_WORKER]   ="作業員";
				$this->titles[SCHEDULE_TRUCK]    ="配車";
				$this->titles[SITE_REMARK]       ="現場詳細";
				$this->titles[SCHEDULE_REMARK1]  ="備考1";
				$this->titles[SCHEDULE_REMARK2]  ="備考2";
				$this->titles[SCHEDULE_REMARK3]  ="備考3";
		}

		function __setInformations($schedule_id){

				if(!$schedules=$this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_id,0)) return false;

				$worker_ids=array();
				$truck_ids=array();
				$customer_ids=array();
				foreach($schedules as $k=>$schedule){

						$site=$schedule["TblMstepSiteDetail"];
						$site_worker=$schedule["TblMstepSiteWorker"];
						$schedule_trucks=$schedule["TblMstepScheduleTruck"];
						$schedule=$schedule["TblMstepSiteSchedule"];

						if(!empty($site["customer_id"])) $customer_ids[]=$site["customer_id"];
						if(!empty($site_worker))     $worker_ids=array_merge($worker_ids,Set::extract($site_worker,"{}.worker_id"));
						if(!empty($schedule_trucks)) $truck_ids =array_merge($truck_ids,Set::extract($schedule_trucks,"{}.truck_id"));
				}

				$customer_ids=array_unique($customer_ids);
				$worker_ids=array_unique($worker_ids);
				$truck_ids =array_unique($truck_ids);

				$customers=array();
				if(!empty($customer_ids)){

						$customers=$this->TblMstepCustomer->getCustomerInfomration($customer_ids);
						$customers=Set::combine($customers,"{n}.TblMstepCustomer.id","{n}.TblMstepCustomer");
				}

				$worker_informations=array();
				if(!empty($worker_ids)){

						$workers=$this->TblMstepWorker->getWorkers($worker_ids);
						$worker_informations=Set::combine($workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker");
				}

				$truck_informations=array();
				if(!empty($truck_ids)){

						$trucks=$this->TblMstepTruck->getTrucks($truck_ids);
						$truck_informations=Set::combine($trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck");
				}

				//■remark
				$remark_titles=array();
				if($titles=$this->TblMstepSiteRemarkTitle->find('first')) $remark_titles=$titles["TblMstepSiteRemarkTitle"];
				if(empty($remark_titles)) $remark_titles=tsv("remark_titles.tsv");

				$schedule_remark_informations=array();
				if($schedule_remarks=$this->TblMstepSiteScheduleRemark->findAllByScheduleId($schedule_id)){
				
						$schedule_remark_informations=Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");
				}

				foreach($schedules as $k=>$v){

						$schedule_id=$v["TblMstepSiteSchedule"]["id"];
						$customer_id=$v["TblMstepSiteDetail"]["customer_id"];
						$customer=(empty($customer_id) OR !isset($customers[$customer_id]))?array():$customers[$customer_id];
						$schedule_remark=(isset($schedule_remark_informations[$schedule_id]))?$schedule_remark_informations[$schedule_id]:array();

						$this->informations[$schedule_id]["site"]    =$v["TblMstepSiteDetail"];
						$this->informations[$schedule_id]["schedule"]=$v["TblMstepSiteSchedule"];
						$this->informations[$schedule_id]["customer"]=$customer;
						$this->informations[$schedule_id]["remark_titles"]=$remark_titles;
						$this->informations[$schedule_id]["schedule_remarks"]=$schedule_remark;
						$this->informations[$schedule_id]["workers"]=array();
						$this->informations[$schedule_id]["trucks"] =array();

						if(!empty($v["TblMstepSiteWorker"])){

								$site_workers=$v["TblMstepSiteWorker"];
								foreach($site_workers as $_k=>$site_worker){

										$worker_id=$site_worker["worker_id"];
										if(!isset($worker_informations[$worker_id])) continue;
										$this->informations[$schedule_id]["workers"][$worker_id]=$worker_informations[$worker_id];
								}
						}

						if(!empty($v["TblMstepScheduleTruck"])){

								$site_trucks=$v["TblMstepScheduleTruck"];
								foreach($site_trucks as $_k=>$site_truck){

										$truck_id=$site_truck["truck_id"];
										if(!isset($truck_informations[$truck_id])) continue;
										$this->informations[$schedule_id]["trucks"][$truck_id]=$truck_informations[$truck_id];
								}
						}
				}
				return true;
		}

		function __makeParams($values){

				$schedule_values=$values[SITE_SCHEDULE]["value"];
				$schedule_value="{$schedule_values["y"]}年{$schedule_values["m"]}月{$schedule_values["d"]}日({$schedule_values["w"]})";

				$schedule_worker_value="";
				$schedule_worker_values=$values[SCHEDULE_WORKER]["value"];
				foreach($schedule_worker_values as $k=>$v){
				
						$schedule_worker_value.=(!empty($v["nickname"])?$v["nickname"]:$v["first_name"]);
						$schedule_worker_value.=" ";
				}

				$schedule_truck_value="";
				$schedule_truck_values=$values[SCHEDULE_TRUCK]["value"];
				foreach($schedule_truck_values as $k=>$v){
				
						$schedule_truck_value.="{$v["name"]}";
						$schedule_truck_value.=" ";
				}

				$params=array(

				        SITE_NAME."_title"=>$values[SITE_NAME]["title"],
			            SITE_NAME."_value"=>$values[SITE_NAME]["value"],
			            CUSTOMER_NAME."_title"=>$values[CUSTOMER_NAME]["title"],
			            CUSTOMER_NAME."_value"=>$values[CUSTOMER_NAME]["value"],
			            SITE_SCHEDULE."_title"=>$values[SITE_SCHEDULE]["title"],
			            SITE_SCHEDULE."_value"=>$schedule_value,
			            SITE_ADDRESS."_title"=>$values[SITE_ADDRESS]["title"],
			            SITE_ADDRESS."_value"=>$values[SITE_ADDRESS]["value"],
			            SITE_ADDRESS_MAP_URL."_title"=>$values[SITE_ADDRESS_MAP_URL]["title"],
			            SITE_ADDRESS_MAP_URL."_value"=>$values[SITE_ADDRESS_MAP_URL]["value"],
			            SCHEDULE_WORKER."_title"=>$values[SCHEDULE_WORKER]["title"],
			            SCHEDULE_WORKER."_value"=>trim($schedule_worker_value),
			            SCHEDULE_TRUCK."_title"=>$values[SCHEDULE_TRUCK]["title"],
			            SCHEDULE_TRUCK."_value"=>trim($schedule_truck_value),
				        SITE_REMARK."_title"=>$values[SITE_REMARK]["title"],
			            SITE_REMARK."_value"=>$values[SITE_REMARK]["value"],
				        SCHEDULE_REMARK1."_title"=>$values[SCHEDULE_REMARK1]["title"],
			            SCHEDULE_REMARK1."_value"=>$values[SCHEDULE_REMARK1]["value"],
					    SCHEDULE_REMARK2."_title"=>$values[SCHEDULE_REMARK2]["title"],
			            SCHEDULE_REMARK2."_value"=>$values[SCHEDULE_REMARK2]["value"],
					    SCHEDULE_REMARK3."_title"=>$values[SCHEDULE_REMARK3]["title"],
			            SCHEDULE_REMARK3."_value"=>$values[SCHEDULE_REMARK3]["value"],
				);

				return $params;
		}

		function __getSubject($value,$send_count=1){

				if(2>$send_count){

						$m=sprintf("%d",$value[SITE_SCHEDULE]["value"]["m"]);
						$d=sprintf("%d",$value[SITE_SCHEDULE]["value"]["d"]);
						$subject="【{$value[SITE_NAME]["value"]}】"."({$m}月{$d}日)";
						return $subject;
				}

				$ymd=$value[SITE_SCHEDULE]["value"];
				$m=sprintf("%d",$ymd["m"]);
				$d=sprintf("%d",$ymd["d"]);
				$subject="{$m}月{$d}({$ymd["w"]})";
				return $subject;
		}

		/*
		 * from       : クライアント企業メールアドレス
		 * returnPath : エラーはサーバへ届ける(info@error.dandori-taro.com)
		 * replyTo    : クライアント企業メールアドレス(返信先メールアドレス)
		 * https://sendgrid.kke.co.jp/docs/User_Manual_JP/email_activity.html
		 * */
		function __sendMail($emails,$message,$params,$headers=array()){

				if(empty($emails)){

						$res["headers"]=$headers;
						return $res;
				}
				
				$subject=$params["subject"];
				$from   =$params["from"];
				$replyTo=$params["replyTo"];
				$to     =array_shift($emails);
				if(empty(trim($to))) return $this->__sendMail($emails,$message,$params,$headers);

		        $Email=new MstepCakeEmail("scheduleReport");
				//$message=quoted_printable_encode($message);
				
				$Email->returnPath(EMAIL_RETURN_PATH);
				$Email->subject($subject);
				$Email->sender($from,SITE_TITLE);
				$Email->from($from,SITE_TITLE);
		        $Email->to($to);
		        if(!empty($replyTo)) $Email->replyTo($replyTo);

			    //$Email->template("schedule_report",null);
			    $Email->emailFormat('text');
			    //$Email->viewVars($values);

				$res=$Email->send($message);
				$count=count($headers);
				$headers[$count][$to]["header"]=$res["headers"];
				$headers[$count][$to]["message"]=$res["message"];
				return $this->__sendMail($emails,$message,$params,$headers);
		} 

		function sendScheduleReportUrl(){
		
				$post=$_POST;

				$schedule_id=$post["schedule_id"];
				$send_black_list=(isset($post["black_list"])?$post["black_list"]:array());
				$map_url=(isset($post["map_url"])?$post["map_url"]:array());
				if(!is_array($schedule_id)) $schedule_id=array($schedule_id);
				$this->__setInformations($schedule_id);
				$url=$this->__sendScheduleReportUrl($schedule_id,$send_black_list,$map_url);

				$information_values=$this->__getReportInformations($schedule_id);
				$__information=$information_values[current($schedule_id)];
				$dates=$__information["siteSchedule"]["value"];

				$res=array();
				$res["data"]["tpl"]=$this->tpl;
				$res["data"]["url"]=$url;
				$res["data"]["date"]["y"]=$dates["y"];
				$res["data"]["date"]["m"]=$dates["m"];
				$res["data"]["date"]["d"]=$dates["d"];
				Output::__outputYes($res);
		}

		function sendScheduleReport(){

				$post=$this->data;

				$schedule_id=$post["schedule_id"];
				$send_black_list=(isset($post["black_list"])?$post["black_list"]:array());
				$map_url=(isset($post["map_url"])?$post["map_url"]:array());
				if(!is_array($schedule_id)) $schedule_id=array($schedule_id);
				$this->__setInformations($schedule_id);
				$message=$this->__sendScheduleReportUrl($schedule_id,$send_black_list,$map_url);

				$information_values=$this->__getReportInformations($schedule_id);
				$__information=$information_values[current($schedule_id)];
				$dates=$__information["siteSchedule"]["value"];
				$message=$this->__getTpl($message,$dates);

				$client_id=CLIENT_DATA_SESSION["id"];
				$profile=$this->TblMasterClientProfile->findById($client_id);

				$subject=$this->__getSubject($__information,count($schedule_id));

				$emails=$this->__getTargetEmails($schedule_id);
				if(in_array(DEVELOP_MODE,array("local","dev"))) $emails=TEST_EMAIL_TO;

				set_time_limit(EMAIL_TIMEOUT*count($emails));
				$res=$this->__sendMail($emails,$message,array(

						"subject"=>$subject,
						"from"   =>EMAIL_FROM,
						"replyTo"=>$profile["TblMasterClientProfile"]["client_email"]
				));

				Output::__outputYes();
		}

		function __getTargetEmails($schedule_id=array()){

				if(!$site_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_id,0)) return array();
				$worker_ids=array_unique(Set::extract($site_workers,"{}.TblMstepSiteWorker.worker_id"));
				if(!$workers=$this->TblMstepWorker->getWorkers($worker_ids)) return array();
				$emails=Set::extract($workers,"{}.TblMstepWorker.email");
				$emails=array_filter($emails,function($a){
				
						return !empty($a);
				});

				return $emails;
		}

		function __sendScheduleReportUrl($schedule_id,$send_black_list=array(),$map_url=array()){
			
		        /** @var $send_all check if shcedule_id when send email to all - Editting for function send email all by Edward*/
				//$send_all = (is_array($schedule_id) and sizeof($schedule_id)>1);

				$information_values=$this->__getReportInformations($schedule_id);

				# okay to check only first value.
				//$__value=$information_values[current($schedule_id)];
				//$subject=$this->__getSubject($__value,count($schedule_id));

				$message="";
				$site_information_values=array();
				foreach($schedule_id as $k=>$__schedule_id){

						$__values=$information_values[$__schedule_id];
						$__values[SITE_ADDRESS_MAP_URL]["title"]=$this->titles[SITE_ADDRESS_MAP_URL];
						$__values[SITE_ADDRESS_MAP_URL]["value"]=(isset($map_url[$__schedule_id])?$map_url[$__schedule_id]:"");
						if(empty($__values[SCHEDULE_WORKER]["value"])) continue;
						$params=$this->__makeParams($__values);

						#against to same sitename.
						$site_information_values[$params[SITE_NAME."_value"]."_".$k]=$params;
				}

				$messages=array();
				$remark_values=array();
				$crlf="\r\n";
				foreach($site_information_values as $siteName=>$v){

						$siteName=explode("_",$siteName)[0];

						$main_value=array();
						$remark_value=array();
						$siteNameValue="【{$v[SITE_NAME."_value"]}】";
						$main_value[]=$siteNameValue;
						if(!in_array(CUSTOMER_NAME,$send_black_list) AND !empty($v[CUSTOMER_NAME."_value"]))     $main_value[]=$v[CUSTOMER_NAME."_value"];
						if(!in_array(SCHEDULE_WORKER,$send_black_list) AND !empty($v[SCHEDULE_WORKER."_value"])) $main_value[]=$v[SCHEDULE_WORKER."_value"];
						if(!in_array(SCHEDULE_TRUCK,$send_black_list) AND !empty($v[SCHEDULE_TRUCK."_value"]))   $main_value[]=$v[SCHEDULE_TRUCK."_value"];
						if(!in_array(SITE_SCHEDULE,$send_black_list) AND !empty($v[SITE_SCHEDULE."_value"]))     $main_value[]=$v[SITE_SCHEDULE."_value"];
						if(!in_array(SITE_ADDRESS,$send_black_list) AND !empty($v[SITE_ADDRESS."_value"]))       $main_value[]=$v[SITE_ADDRESS."_value"];
                    // make gmap as a link
						if(!in_array(SITE_ADDRESS_MAP_URL,$send_black_list) AND !empty($v[SITE_ADDRESS_MAP_URL."_value"])) $main_value[]='<a href="'.$v[SITE_ADDRESS_MAP_URL."_value"].'" target="_blank">'.$v[SITE_ADDRESS_MAP_URL."_value"].'</a>';
//						if(!in_array(SITE_ADDRESS_MAP_URL,$send_black_list) AND !empty($v[SITE_ADDRESS_MAP_URL."_value"])) $main_value[]=$v[SITE_ADDRESS_MAP_URL."_value"];

						if(!in_array(SITE_REMARK,$send_black_list)){

								$siteRemark="{$v[SITE_REMARK."_title"]}{$crlf}{$v[SITE_REMARK."_value"]}";
								$remark_value[]=$siteRemark;
						}

						if(!in_array(SCHEDULE_REMARK1,$send_black_list)){

								$scheduleRemark1="{$v[SCHEDULE_REMARK1."_title"]}{$crlf}{$v[SCHEDULE_REMARK1."_value"]}";
								$remark_value[]=$scheduleRemark1;
						}

						if(!in_array(SCHEDULE_REMARK2,$send_black_list)){

								$scheduleRemark2="{$v[SCHEDULE_REMARK2."_title"]}{$crlf}{$v[SCHEDULE_REMARK2."_value"]}";
								$remark_value[]=$scheduleRemark2;
						}

						if(!in_array(SCHEDULE_REMARK3,$send_black_list)){

								$scheduleRemark3="{$v[SCHEDULE_REMARK3."_title"]}{$crlf}{$v[SCHEDULE_REMARK3."_value"]}";
								$remark_value[]=$scheduleRemark3;
						}

						$categories=array();
						$main_value=implode($crlf,$main_value);
						$remark_value=implode($crlf,$remark_value);
						$categories[]=$main_value;
						$categories[]=$remark_value;
						$messages[]=implode($crlf,$categories);
				}

				$message=implode($crlf.$crlf,$messages);

				/*
				//$message="清沢\r\n\r\n直樹です\nあいうえお";
				//$message=quoted_printable_decode($message);
				$message=mb_convert_encoding($message,"ISO-2022-JP",mb_detect_encoding($message));
				$sg=new SendGrid(SEND_GIRD_APIKEY,array("turn_off_ssl_verification" => true));
				$from = new SendGrid\Email(null,"test@example.com");
				$subject="Hello World from the SendGrid PHP Library!";
				$to=new SendGrid\Email(null,"hayahide4561@gmail.com");
				$content=new SendGrid\Content("text/plain",$message);
				$mail=new SendGrid\Mail($from,$subject,$to,$content);
				$response=$sg->client->mail()->send()->post($mail);
				v($response);
				 */
            
            	/**
            	 * Make link to content file when send report of all schedule to worker
            	 *
            	 * @author Edward (ducnguyen1504@gmail.com)
            	 * @date 2017-05-12
            	 *
            	 */
				if (!file_exists(SCHEDULE_REPORT_CONTENT_PATH)) {

						mkdir(SCHEDULE_REPORT_CONTENT_PATH);
						chmod(SCHEDULE_REPORT_CONTENT_PATH, '0777');
				}
				
				$file_name=CLIENT."_".time();
				$rp_file_path=SCHEDULE_REPORT_CONTENT_PATH.DS.$file_name;
				file_put_contents($rp_file_path, $message);
                $message=Router::url(array('controller'=>'ScheduleReport', 'action'=>'viewReport', 'file'=>$file_name), true);
				return $message;
		}

		function __getReportInformations($schedule_ids=array()){

				$values=array();
				foreach($schedule_ids as $k=>$schedule_id){

						$values[$schedule_id]=array();
						foreach($this->titles as $method=>$title){

								$__method="__{$method}";
								if(!method_exists($this,$__method)) continue;
								$value=$this->$__method($title,$schedule_id);

								$val=$value["value"];
								if(is_string($val)) $val=addcslashes($val,"\\");
								$values[$schedule_id][$method]["value"]=$val;
								$values[$schedule_id][$method]["title"]=$value["title"];
						}
				}

				return $values;
		}

		function __replaceViewValues($tpl,$viewValues=array()){

				foreach($viewValues as $k=>$v){
				
						$viewValues["##{$k}##"]=trim($v,"\n\s\t");
						unset($viewValues[$k]);
				}

				$tpl=str_replace(array_keys($viewValues),array_values($viewValues),$tpl);
				return $tpl;
		}

		function scheduleReport(){

				$post=$this->data;
				$schedule_id=$post["schedule_id"];

				if(!is_array($schedule_id)) $schedule_id=array($schedule_id);
				if(!$this->__setInformations($schedule_id)) Output::__outputNo();
				$client_id=CLIENT_DATA_SESSION["id"];
				$profile=$this->TblMasterClientProfile->findById($client_id);
				$values=$this->__getReportInformations($schedule_id);
				$output["data"]["informations"]=$values;
				$output["data"]["customer"]["client_email"]=$profile["TblMasterClientProfile"]["client_email"];
				Output::__outputYes($output);
		}

		function __getScheduleRemarks($title,$num,$schedule_id){

				$information=$this->informations[$schedule_id];
				$schedule_remarks=$information["schedule_remarks"];
				$remark_titles=$information["remark_titles"];
				$remark_title=empty($remark_titles["schedule_remark{$num}"])?$title:$remark_titles["schedule_remark{$num}"];
				$value=(isset($schedule_remarks["remarks{$num}"])?$schedule_remarks["remarks{$num}"]:"");
				$res["value"]=$value;
				$res["title"]=$remark_title;
				return $res;
		}

		function __scheduleRemark1($title,$schedule_id){

				return $this->__getScheduleRemarks($title,1,$schedule_id);
		}

		function __scheduleRemark2($title,$schedule_id){

				return $this->__getScheduleRemarks($title,2,$schedule_id);
		}

		function __scheduleRemark3($title,$schedule_id){

				return $this->__getScheduleRemarks($title,3,$schedule_id);
		}

		function __scheduleTruck($title,$schedule_id){

				$names=array();
				$counter=0;

				$information=$this->informations[$schedule_id];
				$trucks=$information["trucks"];
				foreach($trucks as $truck_id=>$truck){

						$names[$counter]["name"]=$truck["name"];
						$counter++;
				}

				$res["value"]=$names;
				$res["title"]=$title;
				return $res;
		}

		function __scheduleWorker($title,$schedule_id){
		
				$names=array();
				$counter=0;

				$information=$this->informations[$schedule_id];
				$workers=$information["workers"];
				foreach($workers as $worker_id=>$worker){

						$name="{$worker["first_name"]}{$worker["last_name"]}";
						$nickname=$worker["nickname"];
						$names[$counter]["first_name"]=$worker["first_name"];
						$names[$counter]["last_name"]=$worker["last_name"];
						$names[$counter]["nickname"]=$worker["nickname"];
						$names[$counter]["email"]=$worker["email"];
						$counter++;
				}

				$res["value"]=$names;
				$res["title"]=$title;
				return $res;
		}

		function __siteRemark($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$remark_title=$information["remark_titles"];
				$remark_title=$remark_title["site_remark1"];
				if(empty($remark_title)) $remark_title=$title;

				$remark=$information["site"]["remarks"];
				$res["value"]=$remark;
				$res["title"]=$remark_title;
				return $res;
		}

		function __siteSchedule($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$ym=$information["schedule"]["start_month_prefix"];
				$day=$information["schedule"]["start_day"];
				$time=strtotime($ym.sprintf("%02d",$day));
				$date=date("Y年m月d日",$time);
				$youbi=youbi(date("w",$time));
				$date.="({$youbi})";
				$res["value"]["y"]=date("Y",$time);
				$res["value"]["m"]=date("m",$time);
				$res["value"]["d"]=date("d",$time);
				$res["value"]["w"]=$youbi;
				$res["title"]=$title;
				return $res;
		}

		function __siteAddress($title,$schedule_id){
		
				$this->TblMstepAreaInformation->unbindFully();
				$information=$this->informations[$schedule_id];
				$area_id=$information["site"]["area_id"];

				$address="";
				if(!empty($area_id)){

						$area=$this->TblMstepAreaInformation->findById($area_id);
						$address=$area["TblMstepAreaInformation"]["pref"].$area["TblMstepAreaInformation"]["address1"];
						$address.=$information["site"]["address"];
				}

				$res["value"]=$address;
				$res["title"]=$title;
				return $res;
		}

		function __customerName($title,$schedule_id){
		
				$information=$this->informations[$schedule_id];
				$name=((isset($information["customer"]["name"]))?$information["customer"]["name"]:"");
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

		function __siteName($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$name=$information["site"]["name"];
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

}//END class

?>
