Number.prototype.currencyFormat=function(fixed){
	var fixed=fixed||0;
	var str=this.toFixed(fixed);
	return str.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
}

$(document).ready(function() {
	$(document).on('keypress', '.data-numeric', function (event) { 
		if(event.which != 8 && isNaN(String.fromCharCode(event.which))){
	           event.preventDefault(); //stop character from entering input
	       }
	});
	$(document).scroll(function(event) {
		$('.navbar-inverse').css('left', '-'+$(document).scrollLeft()+'px');
	});
});
