<?php

echo "<pre>";
print_r($_SERVER);
echo "</pre>";

file_put_contents("./agent.txt",print_r($_SERVER,1)."\n\n");

?>
