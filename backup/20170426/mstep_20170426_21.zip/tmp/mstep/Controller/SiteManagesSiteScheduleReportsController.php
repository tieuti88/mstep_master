<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleLog.php";

class SiteManagesSiteScheduleReportsController extends AppController{

        var $name = "SiteManagesSiteScheduleReports";
        var $uses = [

				"TblMstepSiteScheduleReport",
				"TblMstepMasterUser"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				$this->unbindFully();
		}

		public function isAuthorized($user){
		
				return true;
		}

		function getSiteReport(){

				$post        =$this->data;
				$schedule_id =$post["schedule_id"];
				$user_id     =$post["user_id"];

				if(!$user=$this->TblMstepMasterUser->findByIdAndDelFlg($user_id,0)) Output::__outputStatus(1);
				if(!$user["TblMstepMasterUser"]["worker_id"]) Output::__outputStatus(1);

				$report="";
				$worker_id=$user["TblMstepMasterUser"]["worker_id"];
				if($data=$this->TblMstepSiteScheduleReport->findByWorkerIdAndScheduleIdAndDelFlg($worker_id,$schedule_id,0)){

						$report=$data["TblMstepSiteScheduleReport"]["report"];
				}

				$res["message"]=$report;
				Output::__outputYes($res);
		}

		function saveSiteReport(){

				$post        =$this->data;
				$site_id     =$post["site_id"];
				$schedule_id =$post["schedule_id"];
				$user_id     =$post["user_id"];
				$message     =$post["message"];

				if(!$user=$this->TblMstepMasterUser->findByIdAndDelFlg($user_id,0)) Output::__outputStatus(1);
				if(!$user["TblMstepMasterUser"]["worker_id"]) Output::__outputStatus(1);

				$report_id="";
				$worker_id=$user["TblMstepMasterUser"]["worker_id"];
				if($report=$this->TblMstepSiteScheduleReport->findByWorkerIdAndScheduleIdAndDelFlg($worker_id,$schedule_id,0)){

						$report_id=$report["TblMstepSiteScheduleReport"]["id"];
				}

				if(!empty($report_id)) $save["id"]=$report_id;
				$save["worker_id"]  =$worker_id;
				$save["schedule_id"]=$schedule_id;
				$save["report"]     =trim($message);
				if(!$this->TblMstepSiteScheduleReport->save($save)){
				
						Output::__outputStatus(1);
				}

				Output::__outputYes();
		}

}//END class

?>
