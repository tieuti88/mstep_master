<?php

//namespace Cake\Controller\Component;
//use Cake\Controller\Component;

/**
 * Files Component
 *
 * @author Dinh Van Huong
 */
class SendGirdBaseComponent extends Component
{
		protected $sg="";
		protected $send="";

		public function initialize(Controller $controller) {

				if(!defined("SEND_GIRD_APIKEY")) return;
				$this->sg=new \SendGrid(SEND_GIRD_APIKEY);
    	}

		public function startup(Controller $controller) {

    	}

		public function send($tos=array(),$from,$subject,$content){

				if(method_exists($this,"__beforeSend")) $this->__beforeSend();
				return $this->__send($tos,$content);
		}

		protected function __send($tos=array(),$content,$res=array()){

				if(1>count($tos)) return $res;

				$to=array_shift($tos);
				$label=(isset($to["label"])?$to["label"]:"");
				$email=$to["email"];

				$__content=$content;
				if(method_exists($this,"__changeCodeReplace")) $__content=$this->__changeCodeReplace($__content,$email);
				$__content=$this->__sendGirdContent($__content);

				$to=new SendGrid\Email($label,$email);
				$mail=new SendGrid\Mail($this->from,$this->subject,$to,$__content);
				$sgr=$this->send->post($mail);

				$count=count($res);
				$res["email"][$email]=$sgr;
				return $this->__send($tos,$content,$res);
		}

		protected function __setFrom($from){
		
				if($this->from) return;

				$label=null;
				$from_mail=$from;
				if(is_array($from_mail)){

						$label=isset($from_mail["label"])?$from_mail["label"]:$label;
						$from_mail=$from_mail["from"];
				}

				$this->from=new SendGrid\Email($label,$from_mail);
		}

		protected function __setSubject($subject){

				if($this->subject) return;
				$this->subject=$subject;
		}

		protected function __sendObject(){

				$this->send=$this->sg->client->mail()->send();
		}

}
