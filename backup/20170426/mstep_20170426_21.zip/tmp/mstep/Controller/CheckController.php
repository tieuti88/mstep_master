<?php

class CheckController extends AppController {

		public $all_clients;

        function beforeFilter(){

        		parent::beforeFilter();
				$this->__init();
		}

		function __init(){

				$this->loadModel("TblMasterClientProfile");
				$this->loadModel("TblMasterProfile");
				$this->loadModel("TblMstepSiteSchedule");
				$this->loadModel("TblMstepSiteDetail");
				$this->all_clients=$this->TblMasterProfile->findAllByDelFlg(0);
		}

		function __filter($data){

				$same_positions=array();
				foreach($data as $client_name=>$v){

						foreach($v as $site_id=>$_v){
						
								foreach($_v as $date=>$schedule_ids){
								
										if(2>count($schedule_ids)) continue;
										$same_positions[$client_name][$date][$site_id]=$schedule_ids;
								}
						}
				}

				return $same_positions;
		}

		function samePositioning(){

				$all_clients=$this->all_clients;
				if(empty($all_clients)) exit;

				$all_clients=Set::extract($all_clients,"{}.TblMasterProfile");
				$results=$this->__sameAllPositioning($all_clients);
				$same_positions=$this->__filter($results);
				if(empty($same_positions)){

						header("content-type:text/plain;charset=utf8");
						echo "CORRECT";
						exit;
				}

				$all_titles=$this->__siteAllTitles($same_positions);

				$text="";
				foreach($same_positions as $client_name=>$v){
				
						$client_text="";
						$client_text.="【{$client_name}】\n\n";
						foreach($v as $date=>$_v){

								$text_date=date("Y/m/d",strtotime($date));
								$client_text.="[{$text_date}]------\n";
								foreach($_v as $site_id=>$schedule_ids){
								
										$site_name=$all_titles[$client_name][$site_id];
										$count=count($schedule_ids);
										$text_schedule_ids=implode(",",$schedule_ids);
										$client_text.="SiteName:{$site_name}\n";
										$client_text.="MissCount:{$count}count({$text_schedule_ids})\n";
								}
						}

						$client_text.="\n\n";
				}

				header("content-type:text/plain;charset=utf8");
				echo $client_text;
				exit;
		}

		function __siteAllTitles($same_positions){

				$all_clients=$this->all_clients;
				$db_configs=Set::combine($all_clients,"{n}.TblMasterProfile.short_name","{n}.TblMasterProfile");

				$all_titles=array();
				foreach($same_positions as $client_name=>$v){

						$site_ids=array();
						foreach($v as $date=>$_v) $site_ids=array_merge(array_keys($_v),$site_ids);
						$db_config=$db_configs[$client_name];

						$titles=$this->__siteTitle(array(

								"db_host"=>$db_config["db_host"],
								"db_user"=>$db_config["db_user"],
								"db_password"=>$db_config["db_password"],
								"db_name"=>$db_config["db_name"]

						),$site_ids);

						$all_titles[$client_name]=$titles;
				}

				return $all_titles;
		}

		function __siteTitle($config,$site_ids=array()){

				$host=$config["db_host"];
				$user=$config["db_user"];
				$pass=$config["db_password"];
				$db  =$config["db_name"];

				$db_config=$this->TblMstepSiteSchedule->useDbConfig;
				$this->TblMstepSiteDetail->unbindFully();
				$this->TblMstepSiteDetail->changeConnection($host,$user,$pass,$db);
				$this->TblMstepSiteDetail->setDataSource($db);
				$result=$this->TblMstepSiteDetail->findAllByIdAndDelFlg($site_ids,0);
				$this->TblMstepSiteDetail->dropChangeDataSource($db);
				$this->TblMstepSiteDetail->setDataSource($db_config);
				$titles=Set::combine($result,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail.name");
				return $titles;
		}

		function __sameAllPositioning($all_clients=array(),$results=array()){
		
				if(empty($all_clients)) return $results;
				$clients=array_shift($all_clients);
				$result=$this->__samePositioning($clients);
				$results[$clients["short_name"]]=$result;
				return $this->__sameAllPositioning($all_clients,$results);
		}

		function __samePositioning($clients){

				$host=$clients["db_host"];
				$user=$clients["db_user"];
				$pass=$clients["db_password"];
				$db  =$clients["db_name"];

				$db_config=$this->TblMstepSiteSchedule->useDbConfig;
				$this->TblMstepSiteSchedule->unbindFully();
				$this->TblMstepSiteSchedule->changeConnection($host,$user,$pass,$db);
				$this->TblMstepSiteSchedule->setDataSource($db);
				$result=$this->TblMstepSiteSchedule->findAllByDelFlg(0);
				$this->TblMstepSiteSchedule->dropChangeDataSource($db);
				$this->TblMstepSiteSchedule->setDataSource($db_config);

				if(empty($result)) return array();

				$data=array();
				foreach($result as $k=>$v){

						$id       =$v["TblMstepSiteSchedule"]["id"];
						$site_id  =$v["TblMstepSiteSchedule"]["site_id"];
						$start_day=sprintf("%02d",$v["TblMstepSiteSchedule"]["start_day"]);
						$start_month_prefix=$v["TblMstepSiteSchedule"]["start_month_prefix"];
						$day=$start_month_prefix.$start_day;
						if(!isset($data[$site_id][$day])) $data[$site_id][$day]=array();
						$data[$site_id][$day][]=$id;
				}
				return $data;
		}

}
