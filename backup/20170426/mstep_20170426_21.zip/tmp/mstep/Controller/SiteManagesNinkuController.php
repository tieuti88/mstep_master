<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteManagesNinkuController extends AppController{

        var $name = "SiteManagesNinku";
        var $uses = [

				"TblMstepSiteWorker",
				"TblMstepSiteSchedule"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		public function isAuthorized($user){
		
				return true;
		}

		function __init(){}

		function getSiteNinkuSituations(){

				$post=$this->data;

				$site_id=$post["site_id"];
				$site_id=is_array($site_id)?$site_id:array($site_id);
				$ninku_situations=$this->__getSiteNinkuSituations($site_id);

				$output["ninku_situations"]=$ninku_situations;
				Output::__outputYes($output);
		}

    	function __getSiteNinkuSituations($site_ids=array()){

                $current_recuresive=$this->TblMstepSiteWorker->recursive;
                $this->TblMstepSiteWorker->recursive=1;
                $this->TblMstepSiteWorker->belongsTo=array(

                        'TblMstepSiteSchedule'=>array(

                                        'className' => 'TblMstepSiteSchedule',
                                        'foreignKey' => 'schedule_id',
                        ),
                );

                $site_ninku=array();
                $order="TblMstepSiteSchedule.start_month_prefix ASC,TblMstepSiteSchedule.start_day ASC";
                $site_workers=$this->TblMstepSiteWorker->findAllBySiteIdAndDelFlg($site_ids,0,null,$order);
                $this->TblMstepSiteWorker->recursive=$current_recuresive;
                foreach($site_ids as $k=>$site_id) $site_ninku[$site_id]=array();

                if(empty($site_workers)) return $site_ninku;
                foreach($site_workers as $k=>$v){

                        $site_worker=$v["TblMstepSiteWorker"];
                        $site_schedule=$v["TblMstepSiteSchedule"];
                        $site_id=$site_schedule["site_id"];
                        $ymd=$site_schedule["start_month_prefix"].sprintf("%02d",$site_schedule["start_day"]);
                        if(!isset($site_ninku[$site_id][$ymd])){

                                        $site_ninku[$site_id][$ymd]["schedule_id"]=$site_schedule["id"];
                                        $site_ninku[$site_id][$ymd]["count"]=0;
                        }

                        $site_ninku[$site_id][$ymd]["count"]+=$site_worker["man_hour"];
                }

                return $site_ninku;
        }

}//END class

?>
