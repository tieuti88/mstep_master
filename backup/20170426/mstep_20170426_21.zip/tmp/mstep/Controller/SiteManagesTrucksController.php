<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

class SiteManagesTrucksController extends AppController{

        var $name = "SiteManagesTrucks";
        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepSiteSchedule",
				"TblMstepScheduleTruck",
				"TblMstepTruck"
        ];

        function beforeFilter(){

                parent::beforeFilter();

				$this->isAuthorized();
				$this->__init();
		}

		function __init(){
		}

		function __truckInserts($truck_data=array(),$params=array()){

				$registed_ids=$params["registed_ids"];
				$site_id     =$params["site_id"];

				$count=0;
				$inserts=array();
				foreach($truck_data as $schedule_id=>$truck_ids){

						foreach($truck_ids as $k=>$truck_id){

								// def.
								$id=(isset($registed_ids[$schedule_id][$truck_id])?$registed_ids[$schedule_id][$truck_id]["id"]:"");

								$inserts[$count]["id"]         =$id;
								$inserts[$count]["del_flg"]    =0;
								$inserts[$count]["schedule_id"]=$schedule_id;
								$inserts[$count]["site_id"]    =$site_id;
								$inserts[$count++]["truck_id"] =$truck_id;
						}
				}

				return $this->__multiInsert($this->TblMstepScheduleTruck,$inserts);
		}

		function __removeTrucks($schedule_ids=array()){

				$table=$this->TblMstepScheduleTruck->useTable;
				$query="update {$table} set del_flg=1 where schedule_id IN(".implode(",",$schedule_ids).");";

				try{
						$this->TblMstepScheduleTruck->query($query);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __getRegistedTruck($site_id,$all_schedule_ids,$truck_informations){

				//multiple index siteid_truckid todo.
				if(!$all_truck_situations=$this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($all_schedule_ids,0)) return array();
				$all_truck_ids=array_unique(Set::extract($all_truck_situations,"{}.TblMstepScheduleTruck.truck_id"));

				$res=array();
				foreach($all_truck_situations as $k=>$v){

						$schedule_id=$v["TblMstepScheduleTruck"]["schedule_id"];
						if(!isset($res[$schedule_id])) $res[$schedule_id]=array();
						$count=count($res[$schedule_id]);
						$res[$schedule_id][$count]["truck_id"]=$v["TblMstepScheduleTruck"]["truck_id"];
						$res[$schedule_id][$count]["remarks"]=$v["TblMstepScheduleTruck"]["remarks"];
						if(!isset($truck_informations[$v["TblMstepScheduleTruck"]["truck_id"]])) continue;
						$res[$schedule_id][$count]["truck"]["name"]=$truck_informations[$v["TblMstepScheduleTruck"]["truck_id"]]["name"];
						$res[$schedule_id][$count]["truck"]["remarks"]=$truck_informations[$v["TblMstepScheduleTruck"]["truck_id"]]["remarks"];
				}

				return $res;
		}

		function __getAllTruckInformations(){

				if(!$trucks=$this->TblMstepTruck->findAllByDelFlg(0)) return array();

				$res=array();
				foreach($trucks as $k=>$v){

						$res[$v["TblMstepTruck"]["id"]]["name"]   =$v["TblMstepTruck"]["name"];
						$res[$v["TblMstepTruck"]["id"]]["remarks"]=$v["TblMstepTruck"]["remarks"];
				}

				return $res;
		}

		function __getTruckInformationsBySiteIdAndScheduleId($site_id, $schedule_id){

				if(!$schedule_trucks=$this->TblMstepScheduleTruck->findAllBySiteIdAndScheduleIdAndDelFlg($site_id, $schedule_id, 0)) return array();
				if(!$schedule_ids=Set::combine($schedule_trucks,"{n}.TblMstepScheduleTruck.id","{n}.TblMstepScheduleTruck.truck_id")) return array();
				if(!empty($schedule_ids)) $truck_ids=array_values($schedule_ids);
				if(!$trucks=$this->TblMstepTruck->findAllByIdAndDelFlg($truck_ids, 0)) return array();

				$res=array();
				foreach($trucks as $k=>$v){

						$res[$v["TblMstepTruck"]["id"]]["name"]   =$v["TblMstepTruck"]["name"];
						$res[$v["TblMstepTruck"]["id"]]["remarks"]=$v["TblMstepTruck"]["remarks"];
				}

				return $res;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();

				$is_worker_senior=$this->__isWorkerSenior();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id,
						"is_worker_senior"=>$is_worker_senior
				));
				return $res;
		}

}//END class

?>
