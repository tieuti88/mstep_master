<?php

App::uses('CakeEmail', 'Network/Email');
class MstepCakeEmail extends CakeEmail{

	protected function _getContentTransferEncoding() {

			return "Quoted-Printable";

			/*
			$charset = strtoupper($this->charset);
			if (in_array($charset, $this->_charset8bit)) {

					return '8bit';
			}
			return '7bit';
			 */
	}


}

?>
