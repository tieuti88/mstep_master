<?php

/**
 * Created by PhpStorm.
 * User: Edward
 * Date: 2/19/17
 * Time: 9:50 AM
 */
class TblMstepClientRequestLog extends AppModel {
	var $name="TblMstepClientRequestLog";
	
}