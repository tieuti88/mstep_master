<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-23 15:27:42
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-11-01 11:54:17
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepGroupWorker extends AppModel {

	var $name = "TblMstepGroupWorker";
	var $useTable = "tbl_mstep_group_workers";
	var $primaryKey = "id";

	public $hasMany = array(
		'TblMstepWorker' => array(
			'className' => 'TblMstepWorker',
			'foreignKey' => 'group_id',
			'conditions' => array('TblMstepWorker.del_flg' => '0'),
			'dependent' => true,
		),
	);
}
