$(document).ready(function() {
	$(document).on('input', '.data-numeric', function (event) { 
	    //this.value = this.value.replace(/[^0-9]/g, '');
		var pattern = /[0-9]/;
	    if(!pattern.test(this.value)){
	    	return false;
	    }else{
	    	return this.value;
	    }
	});
	$(document).scroll(function(event) {
		$('.navbar-inverse').css('left', '-'+$(document).scrollLeft()+'px');
	});
});