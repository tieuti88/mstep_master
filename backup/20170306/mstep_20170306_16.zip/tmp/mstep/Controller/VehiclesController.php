<?php
class VehiclesController extends AppController {
	public function index() {

	}
	public function add() {

	}
	public function edit() {

	}
}