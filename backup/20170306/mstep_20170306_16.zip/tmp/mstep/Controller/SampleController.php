<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Debug".DS."ScheduleSamePosition.php";

class SampleController extends AppController{

    var $name = "Sample";
    var $uses = [];

    function beforeFilter(){

        parent::beforeFilter();
        //$this->isAuthorized();
    }

    #
    # @author Akabane
    # @date 2011/05/07 14:44:59
    function beforeRender(){

    }

    function index(){

		$x=new ScheduleSamePosition($this);
		v($x->getNgScheduleIds());

        #■前後１ヶ月のデータ
        $informations=$this->__getInformations();
        $informations=json_encode($informations);

        #■直近１週間
        $week=$this->__getWeekFromToday();
        $week=json_encode($week);

        $this->set(compact("informations","week"));
    }

    function __makeDatePeriod($start,$end){

        $diff=(strtotime($end)-strtotime($start))/(60*60*24);
        for($i=0;$i<=$diff;$i++) $period[date("Ymd",strtotime($start."+".$i."days"))]=array();
        return $period;
    }

    function __getInformations(){

        $start=date("Y-m-d",strtotime("-1 month",time()));
        $end=date("Y-m-d",strtotime("+1 month",time()));
        $informations=$this->__makeDatePeriod($start,$end);

        $informations["20160806"][0]["title"]="ほげほげ";
        $informations["20160806"][0]["color"]="green";
        $informations["20160806"][0]["place"]="横須賀市";
        $informations["20160806"][0]["users"]=array("清沢","田中","山崎");
        $informations["20160806"][1]["title"]="ほげほげ";
        $informations["20160806"][1]["color"]="orange";
        $informations["20160806"][1]["place"]="横須賀市";
        $informations["20160806"][1]["users"]=array("清沢","田中","山崎");

        $informations["20160807"]=array();
        $informations["20160807"][0]["title"]="ほげほげ";
        $informations["20160807"][0]["color"]="red";
        $informations["20160807"][0]["place"]="横須賀市";
        $informations["20160807"][0]["users"]=array("清沢","田中","山崎");
        $informations["20160807"][1]["title"]="ほげほげ";
        $informations["20160807"][1]["color"]="blue";
        $informations["20160807"][1]["place"]="横須賀市";
        $informations["20160807"][1]["users"]=array("清沢","田中","山崎");

        $informations["20160808"][0]["title"]="ほげほげ";
        $informations["20160808"][0]["color"]="green";
        $informations["20160808"][0]["place"]="横須賀市";
        $informations["20160808"][0]["users"]=array("清沢","田中","山崎");
        $informations["20160808"][1]["title"]="ほげほげ";
        $informations["20160808"][1]["color"]="orange";
        $informations["20160808"][1]["place"]="横須賀市";
        $informations["20160808"][1]["users"]=array("清沢","田中","山崎");

        $informations["20160810"][0]["title"]="ほげほげ";
        $informations["20160810"][0]["color"]="green";
        $informations["20160810"][0]["place"]="横須賀市";
        $informations["20160810"][0]["users"]=array("清沢","田中","山崎");
        $informations["20160810"][1]["title"]="ほげほげ";
        $informations["20160810"][1]["color"]="orange";
        $informations["20160810"][1]["place"]="横須賀市";
        $informations["20160810"][1]["users"]=array("清沢","田中","山崎");

        return $informations;
    }

    function __getWeekFromToday(){

        $start=date("Y-m-d");
        $end=date("Y-m-d",strtotime("+6 day",time()));
        $period=$this->__makeDatePeriod($start,$end);
        return array_keys($period);
    }

    function getAddDateApi(){

        //■基準日,何ヶ月分
        $post=$_POST;
        $date =isset($post["date"]) ?$post["date"] :date("Ymd");
        $month=isset($post["month"])?$post["month"]:"1";

        $start=date("Y-m-d",strtotime($date));
        $end=date("Y-m-d",strtotime("+ {$month} month",strtotime($date)));
        $period=$this->__makeDatePeriod($start,$end);

        $res["data"]["informations"]=$period;
        $res["data"]["week"]        =array_keys($period);
        $res["status"]="YES";
        $this->__output($res);
    }

    function getSubDateApi(){

        //■基準日,何ヶ月分
        $post=$_POST;
        $date =isset($post["date"]) ?$post["date"] :date("Ymd");
        $month=isset($post["month"])?$post["month"]:"1";

        $end=date("Y-m-d",strtotime($date));
        $start=date("Y-m-d",strtotime("- {$month} month",strtotime($date)));
        $period=$this->__makeDatePeriod($start,$end);

        $res["data"]["informations"]=$period;
        $res["data"]["week"]        =array_keys($period);
        $res["status"]="YES";
        $this->__output($res);
    }

    function sample3(){

        #■前後１ヶ月のデータ
        $informations=$this->__getInformations();
        $informations=json_encode($informations);

        #■直近１週間
        $week=$this->__getWeekFromToday();
        $week=json_encode($week);

        $this->set(compact("informations","week"));
    }

    public function contact(){

    }


}//END class

?>
