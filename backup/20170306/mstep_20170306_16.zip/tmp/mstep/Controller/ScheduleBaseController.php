<?php

/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

class ScheduleBaseController extends AppController{

		function beforeFilter() {
	
				parent::beforeFilter();
		}

		#
		# @author Kiyosawa
		# @date 2011/05/07 14:44:59
		function beforeRender() {
	
				parent::beforeRender();
		}

		function __checkDateFormat($value){
		
				if(empty($value))       return false;
				if(!is_numeric($value)) return false;
				if(strlen($value)!=8)   return false;
				return true;
		}

		function __isEditAuthority($user_id,$last_edit_time,$local_time_key){

             	$instance_s=ScheduleLog::getInstance($this);
                $current_last_edit_time=$instance_s->getLastEditTime();
				if($last_edit_time!=$current_last_edit_time) throw new Exception(2);

				$instance_t=new TimeoutInvestigationExec($this,$this->Session);
				$check_result=$instance_t->checkLastEditTimeSesKey(UNIQUE_KEY,$user_id);

				if(empty($check_result)){

						if(empty($local_time_key)) throw new Exception(1);
						$bin_key=$instance_s->getBinKey();
						$dec=TimeoutInvestigationKeys::decBinKey($bin_key,$local_time_key);
						if($user_id!=$dec["user_id"] OR $dec["time_key"]=!$local_time_key) throw new Exception(3);
				}

				return true;
		}

		function __parseDateHistory($values=array()){
		
				$dates=array();
				foreach($values as $y=>$v){

						foreach($v as $m=>$_v){
						
								foreach($_v as $k=>$d){
								
										$dates[]=$y.sprintf("%02d",$m).sprintf("%02d",$d);
								}
						}
				}

				sort($dates);
				return $dates;
		}

		function __isEditAuthorityOutput(...$args){

				try{

						$this->__isEditAuthority($args[0],$args[1],$args[2]);

				}catch(Exception $e){

						$error=$e->getMessage();

						switch($error){
								case(1):
								Output::__outputStatus(1);
						break;
								case(2):
								$instance=ScheduleLog::getInstance($this);
								$last_edit_user_id=$instance->getLastEditUser();
			                    $this->TblMstepMasterUser->unbindFully();
		                        $login_user=$this->TblMstepMasterUser->findById($last_edit_user_id);
		                        $login_user=$login_user["TblMstepMasterUser"];
		                        $user_informations["name"]="{$login_user["first_name"]} {$login_user["last_name"]}";
		                        Output::__outputStatus(2,array(

		                                "user_informations"=>$user_informations

		                        ),array(

		                                "##USER##"=>$user_informations["name"]
		                        ));
						break;
								case(3):
								Output::__outputStatus(3);
						break;
						}
				}

				return true;
		}

		function __getRefreshLastEditTime(){
		
				$instance=ScheduleLog::getInstance($this);
				$res=$instance->updateEditCurrentTime();
				return strtotime($res["TblMstepScheduleLog"]["edit_time"])*1000;
		}

		function __checkPostDataEmpty($post){

				$errors=array();

				foreach($this->requiredParams as $k=>$v){

						if(isset($post[$k]) AND !empty($post[$k])) continue;
						$errors[$k]=$v;
				}

				return $errors;
		}
}

?>

