<?php

//namespace Cake\Controller\Component;
//use Cake\Controller\Component;

/**
 * Files Component
 *
 * @author Dinh Van Huong
 */

App::uses('SendGirdBaseComponent','Controller/Component');
class SendGirdPlainTextComponent extends SendGirdBaseComponent
{
		protected $subject="";
		protected $from="";
		public $changeCodes=array();

		public function initialize(Controller $controller) {

				parent::initialize($controller);
    	}

		public function send($tos=array(),$from,$subject,$content){

				parent::__setFrom($from);
				parent::__setSubject($subject);
				parent::__sendObject();
				return parent::send($tos,$from,$subject,$content);
		}

		protected function __sendGirdContent($content){

				$content=new SendGrid\Content("text/plain",$content);
				return $content;
		}

		protected function __changeCodeReplace($content,$email){

				$changeCodes=$this->changeCodes;
				if(empty($changeCodes)) return $content;
				if(!isset($changeCodes[$email])) return $content;
				$keys=array_keys($this->changeCodes[$email]);
				$values=array_values($this->changeCodes[$email]);
				$content=str_replace($keys,$values,$content);
				return $content;
		}
}
