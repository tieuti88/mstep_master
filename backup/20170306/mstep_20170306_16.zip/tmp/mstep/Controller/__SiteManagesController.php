<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteManagesController extends AppController{

        var $name = "SiteManages";
		var $clientManagesSitesIds=array();
        var $uses = [

                "TblMstepSiteDetail",
                "TblMstepSiteSchedule",
                "TblMstepSiteWorker",
				"TblMstepScheduleLog",
				"TblMstepCustomer"
        ];

        function beforeFilter(){

                parent::beforeFilter();
        }

        #
        # @author Akabane
        # @date 2011/05/07 14:44:59
        function beforeRender(){
        }

		function __setSiteId($client_id){

				if(!$customers=$this->TblMstepCustomer->findAllByClientIdAndDelFlg($client_id,0)){

						$this->clientManagesSitesIds=array();
						return;
				}

				$customer_ids=Set::extract($customers,"{}.TblMstepCustomer.id");
				if(!$site_details=$this->TblMstepSiteDetail->findAllByCustomerIdAndDelFlg($customer_ids,0)){

						$this->clientManagesSitesIds=array();
						return;
				}

				$this->clientManagesSitesIds=Set::extract($site_details,"{}.TblMstepSiteDetail.id");
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getInformations($start,$end);
				return $res;
		}

		function __checkWorkerSchedule($data,$params){

				//$data["1474596710349_2"]["day"]="20160925";
				//$data["1474596710349_6"]["day"]="20160925";
				
				$all_schedule_start_dates=$params["all_schedule_start_dates"];
				$all_schedule_end_dates=$params["all_schedule_end_dates"];

				$errors=array();
				$worker_schedules=array();
				foreach($data as $object_id=>$v){

						$schedule_id=$v["schedule_id"];
						foreach($v["workers"] as $_k=>$worker_id){

								if(!isset($worker_schedules[$worker_id])) $worker_schedules[$worker_id]=array();

								// diff.
								$start_date=strtotime($all_schedule_start_dates[$schedule_id]);
								$end_date  =strtotime($all_schedule_end_dates[$schedule_id]);
								$diff=$end_date-$start_date;

								$new_start_date=date("Y-m-d",strtotime($v["day"]))." ".date("H:i:s",strtotime($start_date));
								$new_end_date=date("Y-m-d H:i:s",strtotime($new_start_date)+$diff);

								$current_start_schedule_m=strtotime($new_start_date);
								$current_end_schedule_m  =strtotime($new_end_date);
	
								//check.
								foreach($worker_schedules[$worker_id] as $__k=>$schedules){

										$_s=strtotime($schedules["start"]);
										if($current_end_schedule_m > $_s AND $_s >= $current_start_schedule_m){
										
												$errors[]=$schedules["object_id"];
												$errors[]=$object_id;
												continue;
										}

										$_e=strtotime($schedules["end"]);
										if($current_end_schedule_m > $_e AND $_e >= $current_start_schedule_m){

												$errors[]=$schedules["object_id"];
												$errors[]=$object_id;
												continue;
										}
								}

								$__count=count($worker_schedules[$worker_id]);
								$worker_schedules[$worker_id][$__count]["object_id"]=$object_id;
								$worker_schedules[$worker_id][$__count]["start"]=$new_start_date;
								$worker_schedules[$worker_id][$__count]["end"]  =$new_end_date;
						}
				}

				return array_unique($errors);
		}

		function saveSchedule(){

		        $post=$_POST;
				//file_put_contents("./post.txt",serialize($post));
				//exit;

				//$post=unserialize(file_get_contents("./post.txt"));
				//$last_modified_ms=$post["last_modified_ms"];

				$data      =isset($post["data"])?$post["data"]:array();
				$client_id =$post["client_id"];
				$user_id   =$post["user_id"];
				$start_date=$post["start_date"];
				$end_date  =$post["end_date"];
				$date_action_history=$post["date_history"];

				// edit limited time.
				$schedule_log=$this->TblMstepScheduleLog->findByClientId($client_id);
				if($schedule_log["TblMstepScheduleLog"]["user_id"]!=$user_id){

						$output["status"]="NO";
						$output["message"]="Out of Expired";
						$this->__output($output);
						return;
				}

				$this->__setSiteId($client_id);

				$all_schedule_ids=array();
				if(!empty($data)) $all_schedule_ids=Set::extract($data,"{}.schedule_id");

				$all_schedules=array();
				if(!empty($all_schedule_ids)) $all_schedules=$this->TblMstepSiteSchedule->findAllByIdAndDelFlg(array_unique($all_schedule_ids),0);

				$all_site_workers=array();
				if(!empty($all_site_ids)) $all_site_workers=$this->TblMstepSiteWorker->findAllBySiteId(array_values($all_site_ids));

				$all_schedule_start_dates=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_date");
				$all_schedule_end_dates  =Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.end_date");

				// schedule unique check.
				$errors=$this->__checkWorkerSchedule($data,array(
				
						"all_schedule_start_dates"=>$all_schedule_start_dates,
						"all_schedule_end_dates"  =>$all_schedule_end_dates,
				));

				if(!empty($errors)){

						$output["status"]="NO";
						$output["message"]=json_encode($errors);
						$this->__output($output);
				}

				//transaction
				$datasource  =$this->TblMstepSiteWorker->getDataSource();
				$datasource->begin();

				//delete schedule
				$res=$this->__deleteSchedule(array(

						"target_delete_days"=>$date_action_history,
						"site_ids"          =>$this->clientManagesSitesIds,
				));

				if(empty($res["status"])){

						$output["status"]="NO";
						$output["message"]=$res["message"];
						$this->__output($output);
				}

				//delete workers
				$res=$this->__deleteWorkers(array(
				
						"schedule_ids"=>$res["schedule_ids"],
						"site_ids"    =>$res["site_ids"]
				));

				if(empty($res["status"])){

						$output["status"]="NO";
						$output["message"]=$res["message"];
						$this->__output($output);
				}

				// save schedules.
				$res=$schedule_insert_ids=$this->__saveSiteSchedule($data,array(
				
						"all_schedule_start_dates"=>$all_schedule_start_dates,
						"all_schedule_end_dates"  =>$all_schedule_end_dates
				));

				if(empty($res)){

						$output["status"]="NO";
						$output["message"]=$res["message"];
						$this->__output($output);
				}

				// save workers.
				$schedule_insert_ids=$res["schedule_insert_ids"];
				$res=$this->__saveWorkers($data,array(
				
						"site_ids"    =>$this->clientManagesSitesIds,
						"schedule_ids"=>$schedule_insert_ids
				));

				if(empty($res["status"])){

						$output["status"]="NO";
						$output["message"]=$res["message"];
						$this->__output($output);
				}

				// commit.
				$datasource->commit();
				
				// new informations.
				$start_date=date("Y-m-d",strtotime($start_date));
				$end_date  =date("Y-m-d",strtotime($end_date));
				$informations=$this->__getInformations($start_date,$end_date);

				// edit limited time.
				$this->TblMstepScheduleLog->timeInitialize($client_id);

				$output["status"]="YES";
				//$output["last_modified"]       =$informations["last_modified"]["ms"];
				//$output["last_modified_user"]  =$informations["last_modified"]["user_id"];
				$output["data"]["schedule_ids"]=$schedule_insert_ids;
				$output["data"]["informations"]=$informations["informations"];
				$this->__output($output);
		}

		function __saveWorkers($datas=array(),$params=array(),$insert_ids=array()){

				if(empty($datas)){

						$res["status"]=true;
						return $res;
				}

				$site_ids    =$params["site_ids"];
				$schedule_ids=$params["schedule_ids"];
				$current_workers=$this->TblMstepSiteWorker->findAllBySiteId($site_ids);

				$man_hours=array();
				foreach($current_workers as $k=>$v){

						$_v=$v["TblMstepSiteWorker"];
						$man_hours[$_v["site_id"]][$_v["worker_id"]]=$_v["man_hour"];
				}

				$insert=array();
				$counter=0;
				foreach($datas as $object_id=>$v){
				
						$workers=$v["workers"];
						foreach($workers as $_k=>$worker_id){

								$schedule_id=$schedule_ids[$object_id];
								$site_id=$v["site_id"];

								$insert[$counter]["schedule_id"]=$schedule_id;
								$insert[$counter]["worker_id"]  =$worker_id;
								$insert[$counter]["man_hour"]   =$man_hours[$site_id][$worker_id];
								$insert[$counter++]["site_id"]    =$site_id;
						}
				}

				try{

						$this->TblMstepSiteWorker->multiInsert($insert);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __saveSiteSchedule($datas=array(),$params=array(),$insert_ids=array()){

				if(1>count($datas)){

						$res["status"]=true;
						$res["schedule_insert_ids"]=$insert_ids;
						return $res;
				}

				$object_id=array_keys($datas)[0];
				$data=array_shift($datas);
				$schedule_id=$data["schedule_id"];
				$all_schedule_start_dates=$params["all_schedule_start_dates"];
				$all_schedule_end_dates  =$params["all_schedule_end_dates"];

				// diff.
				$start_date=strtotime($all_schedule_start_dates[$schedule_id]);
				$end_date  =strtotime($all_schedule_end_dates[$schedule_id]);
				$diff=$end_date-$start_date;

				// new date.
				$new_start_date=date("Y-m-d",strtotime($data["day"]))." ".date("H:i:s",strtotime($start_date));
				$new_end_date=date("Y-m-d H:i:s",strtotime($new_start_date)+$diff);

				$insert["position_num"]=$data["position_num"];
				$insert["start_date"]  =$new_start_date;
				$insert["end_date"]    =$new_end_date;
				$insert["site_id"]     =$data["site_id"];
				$insert["start_date_prefix"]=date("Ymd",strtotime($new_start_date));

				try{
				
						$this->TblMstepSiteSchedule->id=null;
						$this->TblMstepSiteSchedule->save($insert);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$insert_ids[$object_id]=$this->TblMstepSiteSchedule->getLastInsertID();
				return $this->__saveSiteSchedule($datas,$params,$insert_ids);
		}

		function __deleteWorkers($params){

				$site_ids=$params["site_ids"];
				$schedule_ids=$params["schedule_ids"];

				$w=null;
				$w["and"]["TblMstepSiteWorker.site_id"]=$site_ids;
				$w["and"]["TblMstepSiteWorker.schedule_id"]=$schedule_ids;
				$w["and"]["TblMstepSiteWorker.del_flg"]=0;
				if(!$update_targets=$this->TblMstepSiteWorker->findAll($w)){

						$res["schedule_ids"]=array();
						$res["site_ids"]=array();
						$res["status"]=true;
						return $res;
				}

				try{

						$w=null;
						$w["TblMstepSiteWorker.id"]=Set::extract($update_targets,"{}.TblMstepSiteWorker.id");
						$this->TblMstepSiteWorker->updateAll(array("del_flg"=>1),$w);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		// del_flg : 1
		function __deleteSchedule($params){

				$site_ids =$params["site_ids"];
				$target_delete_days=$params["target_delete_days"];

				$w=null;
				$w["and"]["TblMstepSiteSchedule.site_id"]=$site_ids;
				$w["and"]["TblMstepSiteSchedule.start_date_prefix"]=$target_delete_days;
				$w["and"]["TblMstepSiteSchedule.del_flg"]=0;
				if(!$update_targets=$this->TblMstepSiteSchedule->findAll($w)){

						$res["schedule_ids"]=array();
						$res["site_ids"]=array();
						$res["status"]=true;
						return $res;
				}

				try{

						$w=null;
						$w["TblMstepSiteSchedule.id"]=Set::extract($update_targets,"{}.TblMstepSiteSchedule.id");
						$this->TblMstepSiteSchedule->updateAll(array("del_flg"=>1),$w);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["schedule_ids"]=array_unique(Set::extract($update_targets,"{}.TblMstepSiteSchedule.id"));
				$res["site_ids"]    =array_unique(Set::extract($update_targets,"{}.TblMstepSiteSchedule.site_id"));
				$res["status"]=true;
				return $res;
		}

		function editStart(){

	            $post=$_POST;
                //$post_last_modified_ms=$post["last_modified_ms"];
				$client_id       =$post["client_id"];
				$user_id         =$post["user_id"];

				$effective_minutes_ms=(EDIT_EFFECTIVE_SECOND*1000);
				$current_time_ms=time()*1000;
				$last_modified=$this->TblMstepScheduleLog->findByClientId($client_id);
				$is_edit=empty($last_modified);

				// same ms.
				///if(!$is_edit) $is_edit=($last_modified["TblMstepScheduleLog"]["edit_time_ms"]==$post_last_modified_ms);

				// out of effective time.
				if(!$is_edit) $is_edit=($current_time_ms>($last_modified["TblMstepScheduleLog"]["edit_time_ms"]+$effective_minutes_ms));

				// same user.
				if(!$is_edit) $is_edit=($user_id==$last_modified["TblMstepScheduleLog"]["user_id"]);

				if($is_edit){

						$save=$this->TblMstepScheduleLog->editTime(array(
						
								"user_id"  =>$user_id,
								"edit_time"=>$current_time_ms,
								"client_id"=>$client_id
						));

						$output["status"]="YES";
						$output["last_modified_ms"]=$current_time_ms;
						$this->__output($output);
				}

				$output["status"]="NO";
				//$output["last_modified_ms"]=$last_modified["TblMstepScheduleLog"]["edit_time_ms"];
				$output["user_id"]=$last_modified["TblMstepScheduleLog"]["user_id"];
				$this->__output($output);
		}

}//END class

?>
