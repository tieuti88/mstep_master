    <?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-08 17:38:35
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-12-07 15:42:52
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepSiteScheduleReport extends AppModel{

        var $name = "TblMstepSiteScheduleReport";
        var $useTable = "tbl_mstep_site_schedule_reports";
        var $primaryKey = "id";

        public $belongsTo = array(
            'TblMstepWorker' => array(
            'className' => 'TblMstepWorker',
            'foreignKey' => 'worker_id',
            'conditions' => array('TblMstepWorker.del_flg' => '0'),
        	),
    	);

		function getScheduleReport($worker_ids=array(),$schedule_ids=array(),$del_flg=0,$f=array()){
		
				$current_recursive=$this->recursive;
				$this->recursive=-1;

				$w=null;
				$w["and"]["worker_id"]=$worker_ids;
				$w["and"]["schedule_id"]=$schedule_ids;
				if(is_numeric($del_flg)) $w["and"]["del_flg"]=$del_flg;
				$reports=$this->findAll($w,$f);
				$this->recursive=$current_recursive;
				return $reports;
		}

}
