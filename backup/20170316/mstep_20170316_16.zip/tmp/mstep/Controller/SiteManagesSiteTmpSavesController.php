<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."SchedulePosition.php";
require_once "Schedule".DS."ScheduleNinku.php";
require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

App::uses('ScheduleBaseController','Controller');
class SiteManagesSiteTmpSavesController extends ScheduleBaseController{

        var $name="SiteManagesSiteTmpSaves";

		var $requiredParams=[

				"site_name"      =>"現場名",
				"site_name_kana" =>"現場名(かな)",
				"site_customer"  =>"顧客名",
				"site_pref"      =>"都道府県",
				"site_area"      =>"市区町村",
				"site_address"   =>"住所",
				"site_power_num" =>"総人工",
				"site_color_id"  =>"背景色",
				"site_schedules" =>"日程"
		];

        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepSiteSchedule",
				"TblMstepCustomer",
				"TblMstepMasterUser"
        ];

        function beforeFilter(){

        		parent::beforeFilter();
				$this->__init();
		}

		function __init(){
		}

		function __saveSiteInformation($site_id,$user_id,$customer_id,$post){

				$site_name    =$post["site_name"];
				$site_name_kana=$post["site_name_kana"];
				$site_customer=$post["site_customer"];
				$site_pref    =$post["site_pref"];
				$site_area    =$post["site_area"];
				$site_address =$post["site_address"];
				$site_ninku   =$post["site_power_num"];
				$site_remarks =$post["site_remarks"];
				$site_color_id=$post["site_color_id"];

				$save["name"]=$site_name;
				$save["name_kana"]=$site_name_kana;
				$save["customer_id"]=$customer_id;
				$save["area_id"]=$site_area;
				$save["address"]=$site_address;
				$save["remarks"]=$site_remarks;
				$save["power_num"]=min((Int)$site_ninku,9999);
				$save["color_id"]=$site_color_id;
				$save["edit_user_id"]=$user_id;
				if(!empty($site_id)) $save["id"]=$site_id;
				if(!$res=$this->TblMstepSiteDetail->save($save)) return false;
				if(empty($site_id)) $site_id=$this->TblMstepSiteDetail->getLastInsertID();
				return $site_id;
		}

		function __getRegistedIdHistories($all_site_schedules) {

				$registed_site_ids=array();
				foreach($all_site_schedules as $k=>$v){

						$data=$v["TblMstepSiteSchedule"];
						$registed_site_ids[$data["start_month_prefix"].sprintf("%02d",$data["start_day"])]=$data["id"];
				}
				return $registed_site_ids;
		}

		function __getSeparatorRegistDays($schedule_enable_days, $current_days) {

				$res["new"]=array();
				$res["current"]=array();
				foreach($schedule_enable_days as $k => $date) {

						if(in_array($date,$current_days)){

								$res["current"][]=$date;
								continue;
						}

						$res["new"][]=$date;
				}
				return $res;
		}

		function __updateScheduleColorBySiteId($site_id,$color_id){

				try{

						$v=array("color_id"=>$color_id);
						$c=array("site_id"=>$site_id);
						$this->TblMstepSiteSchedule->unbindFully();
						$this->TblMstepSiteSchedule->updateAll($v,$c);

				}catch(Exception $e){

						$res["error"]=5;
						$res["status"]=false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __tmpAddSite($post){

				$site_color_id=$post["site_color_id"];
				$position_num =isset($post["position_num"])?$post["position_num"]:null;
				$user_id      =$post["user_id"];
				$site_id      =(isset($post["site_id"]) AND !empty($post["site_id"]))?$post["site_id"]:"";
				$customer_id  =empty($post["site_customer_id"])?false:$post["site_customer_id"];
				$is_edit      =!empty($site_id);

				//■カレンダーに設定されている日(削除は含まれない)
				$schedule_enable_days=isset($post["schedule_dates"])?$post["schedule_dates"]:array();

				//■可視化されている情報のみ送信される
				//$schedule_options=isset($post["schedule_options"])?$post["schedule_options"]:array();

	            $datasource=$this->TblMstepSiteDetail->getDataSource();
	            $datasource->begin();

				if($is_edit){

						$site_detail=$this->TblMstepSiteDetail->getWorkDetail(array($site_id));
						$site_detail=$site_detail[0];
						$customer_id=(!empty($customer_id)?$customer_id:$site_detail["TblMstepSiteDetail"]["customer_id"]);
				}
	
				$current_days=array();
				$registed_site_id_histories=array();
				if($is_edit){

						$this->TblMstepSiteSchedule->unbindFully();
						$all_site_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);
						$registed_site_id_histories=$this->__getRegistedIdHistories($all_site_schedules);
						$current_days=array_keys($registed_site_id_histories);

						$delete_schedule_ids=array();
						foreach($registed_site_id_histories as $date=>$schedule_id){
						
								if(in_array($date,$schedule_enable_days)) continue;
								$delete_schedule_ids[]=$schedule_id;
						}

						if(!empty($delete_schedule_ids)) $this->__deleteSchedule($delete_schedule_ids);
				}

				$regist_days=$this->__getSeparatorRegistDays($schedule_enable_days,$current_days);
				$all_position_ids=$this->__getAllPositionNums($schedule_enable_days);

				//customer.
				if(!empty($post["site_customer"])){

						$customer_id=$this->__saveCustomer(array(

								"name"       =>$post["site_customer"],
								"customer_id"=>$customer_id,
						));

						if(empty($customer_id)){

								throw new Exception(5);
								return;
						}
				}

				if(!$site_id=$this->__saveSiteInformation($site_id,$user_id,$customer_id,$post)){

						throw new Exception(5);
						return;
				}

				//new regist.(更新は処理する必要が無い)
				if(!empty($regist_days["new"])){

						$new_regist_dates=$regist_days["new"];
						$insert_result=$this->__registNewSiteSchedule($new_regist_dates,array(

								"site_id"         =>$site_id,
								"position_num"    =>$position_num,
								"all_position_ids"=>$all_position_ids,
						));

						if(empty($insert_result["status"])){

								throw new Exception($insert_result["error"]);
								return;
						}
				}

				if($is_edit AND $site_detail["TblMstepSiteDetail"]["color_id"]!=$site_color_id){

						$update_result=$this->__updateScheduleColorBySiteId($site_id,$site_color_id);
						if(empty($update_result["status"])) throw new Exception($update_result["error"]);
				}

				$datasource->commit();

				$res["status"]=true;
				$res["data"]["site_id"]=$site_id;
				return $res;
		}

		function __registNewSiteSchedule($dates=array(),$params,$insert_datas=array()){

				if(empty($dates)){

						$res["status"]=true;
						$res["insert_datas"]=$insert_datas;
						return $res;
				}

				$site_id =$params["site_id"];
				$position_num=$params["position_num"];
				$all_position_ids=$params["all_position_ids"];
				$date=array_shift($dates);

				$current_position_ids=isset($all_position_ids[$date])?$all_position_ids[$date]:array();
				$position=SchedulePosition::checkIFSamePosition($current_position_ids,$position_num);

				if(!is_numeric($position)){

						$res["error"]=4;
						$res["status"]=false;
						return $res;
				}

				$s=strtotime($date);
				$date=date("Y/m/d 00:00:00",$s);
				$save["position_num"]=$position;
				$save["start_month_prefix"]=date("Ym",$s);
				$save["start_day"]=date("j",$s);
				$save["site_id"]=$site_id;
				$save["start_date"]=$date;
				$save["end_date"]  =$date;
				$this->TblMstepSiteSchedule->id=null;
				if(!$this->TblMstepSiteSchedule->save($save)){

						$res["status"]=false;
						$res["error"]=5;
						return $res;
				}

				if(Configure::read("debug")>1){

						$query=$this->TblMstepSiteSchedule->getLastQuery();
						$last_query=$query["query"];
						$insert_datas[]=$last_query;
				}

				$schedule_id=$this->TblMstepSiteSchedule->getLastInsertID();
				$save["schedule_id"]=$schedule_id;
				$save["date"]=$date;
				return $this->__registNewSiteSchedule($dates,$params,$insert_datas);
		}

		function __refreshNinku($dates=array()){

				$res["status"]=true;
				$res["site_ids"]=array();

				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($dates);
				if(empty($inserts)) return $res;
				$res=$this->__multiInsert($this->TblMstepSiteWorker,$inserts);
				if(empty($res["status"])) return $res;
				$res["site_ids"]=array_unique(Set::extract($inserts,"{}.site_id"));
				return $res;
		}

		function __checkPostScheduleInformation($values){

				if(empty($values) OR (!$this->__checkDateFormat($values["start_date"]) OR !$this->__checkDateFormat($values["end_date"]))) return false;
				return true;
		}

		function tmpAddSite(){

				if(!$this->isPostRequest()) exit;

				$post=$this->data;
				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				//if($res=$this->__checkPostDataEmpty($post)) Output::__outputStatus(1);
				$user_id=$post["user_id"];
				$local_time_key=isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;
				//v(date("Y/m/d H:i:s",$last_edit_time/1000));
				
				$schedule_info=!isset($post["schedule_info"])?false:$post["schedule_info"];
				if(!$this->__checkPostScheduleInformation($schedule_info)) Output::__outputStatus(1);

				if(!isset($schedule_info["start_date"])) $schedule_info["start_date"]=date("Ym01");
				if(!isset($schedule_info["end_date"]))   $schedule_info["end_date"]=date("Ymt");
	
				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				try{
						$res=$this->__tmpAddSite($post);

				}catch(Exception $e){ Output::__outputStatus($e->getMessage()); }

				$schedule_enable_days=isset($post["schedule_dates"])?$post["schedule_dates"]:array();
				$res_ninku=$this->__refreshNinku($schedule_enable_days);
				$refresh_ninku_siteids=$res_ninku["site_ids"];

				$site_id=$res["data"]["site_id"];
				$this->TblMstepSiteSchedule->unbindFully();
				$schedules = $this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);
				$schedule_ids = Set::extract($schedules, "{}.TblMstepSiteSchedule.id");

				// edit information.
				$edit_detail[$site_id]=array("edit_user_id"=>$user_id,"modified"=>date("Y/m/d H:i:s"));
				$instance=new ScheduleGetLastEditSiteUser($this);
				$instance->setSiteInformations($edit_detail);
				$edit_informations=$instance->getEditUsersInformations();

				// new informations.
				//if(!isset($schedule_info["start_date"])) $schedule_info["start_date"]=date("Ym01");
				//if(!isset($schedule_info["end_date"]))   $schedule_info["end_date"]=date("Ymt");
				$min_start_dates=(empty($schedules)?array():min(Set::extract($schedules,"{}.TblMstepSiteSchedule.start_date")));
				$max_end_dates  =(empty($schedules)?array():max(Set::extract($schedules,"{}.TblMstepSiteSchedule.end_date")));

				$information_start_date=(empty($min_start_dates)?$schedule_info["start_date"]:min(array(date("Ymd",strtotime($min_start_dates)),$schedule_info["start_date"])));
				$information_end_date  =(empty($max_end_dates)?$schedule_info["end_date"]:max(array(date("Ymd",strtotime($max_end_dates)),$schedule_info["end_date"])));
				$start_date=date("Y-m-d",strtotime($information_start_date));
				$end_date=date("Y-m-d",strtotime($information_end_date));

				$informations=$this->__getInformations($start_date,$end_date);
				$ninku_situations=$this->__getSiteNinkuSituations($refresh_ninku_siteids);
				$customer_informations=$this->__getCustomerInformations();

				$last_edit_time=$this->__getRefreshLastEditTime();

				$output["customer_informations"]=$customer_informations;
				$output["informations"]=$informations["informations"];
				$output["edit_information"]=$edit_informations;
				$output["schedule_ids"]=$schedule_ids;
				$output["ninku_situations"]=$ninku_situations;
				$output["site_id"]=$site_id;
				$output["last_edit_time"]=$last_edit_time;
				Output::__outputYes($output);
		}

		function __saveCustomer($params){

				$customer_id=$params["customer_id"];
				$name       =$params["name"];
				$is_edit    =!empty($customer_id);

				$save=array();
				if($is_edit) $save["id"]=$customer_id;
				$save["name"]=$name;
				if(!$res=$this->TblMstepCustomer->save($save)) return false;
				$customer_id=($is_edit)?$customer_id:$this->TblMstepCustomer->getLastInsertID();
				return $customer_id;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));
				return $res;
		}

		function __getAllPositionNums($dates=array()){

				$this->TblMstepSiteSchedule->unbindFully();
				$schedules=$this->TblMstepSiteSchedule->getSiteScheduleByDate($dates);
				$position_nums=array();
				foreach($schedules as $k=>$v) {

						$start_date=date("Ymd",strtotime($v["TblMstepSiteSchedule"]["start_date"]));
						$position_nums[$start_date][]=$v["TblMstepSiteSchedule"]["position_num"];
				}

				return $position_nums;
		}

		function __getSiteNinkuSituations($site_ids=array()) {

				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __getCustomerInformations($customer_ids=array()){

				App::uses("SiteManagesCustomersController", "Controller");
				$controller = new SiteManagesCustomersController();
				$res = $controller->__getCustomerInformations($customer_ids);
				return $res;
		}

		function __deleteSchedule($schedule_ids=array()){

				App::uses("SiteManagesController","Controller");
				$controller=new SiteManagesController();

				try{
						$controller->__deleteSchedule($schedule_ids);

				}catch(Exception $e){
				
						$error_code=$e->getMessage();
						$res["status"]=false;
						$res["error"]=$error_code;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

}//END class

?>
