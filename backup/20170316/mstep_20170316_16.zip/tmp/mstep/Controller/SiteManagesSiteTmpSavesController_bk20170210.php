<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."SchedulePosition.php";
require_once "Schedule".DS."ScheduleNinku.php";
require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

class SiteManagesSiteTmpSavesController extends AppController{

        var $name="SiteManagesSiteTmpSaves";

		var $requiredParams=[

				"site_name"      =>"現場名",
				"site_name_kana" =>"現場名(かな)",
				"site_customer"  =>"顧客名",
				"site_pref"      =>"都道府県",
				"site_area"      =>"市区町村",
				"site_address"   =>"住所",
				"site_power_num" =>"総人工",
				"site_color_id"  =>"背景色",
				"site_schedules" =>"日程"
		];

        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepSiteSchedule",
				"TblMstepCustomer"
        ];

        function beforeFilter(){

        		parent::beforeFilter();
				$this->__init();
		}

		function __init() {
		}

		function __makeScheduleDays($schedules=array()){

				$schedule_days=array();

				if(empty($schedules)) return $schedule_days;

				foreach($schedules as $k=>$v){

						$_s=($v["start_time_ms"]/1000);
						$_e=($v["end_time_ms"]/1000);

						$_start=date("Y-m-d 00:00:00",$_s);
						$_end  =date("Y-m-d 00:00:00",$_e);

						$diff=day_diff($_start,$_end)+1;

						for($i=0;$i<$diff;$i++){

								$count=count($schedule_days);

								$s_h=date("H",$_s);
								$s_i=date("i",$_s);
								$s_s=date("s",$_s);
								$schedule_days[$count]["start"]=date("Y-m-d {$s_h}:{$s_i}:{$s_s}",strtotime("+ {$i} day",$_s));
								$schedule_days[$count]["start_month_prefix"]=date("Ym",strtotime($schedule_days[$count]["start"]));
								$schedule_days[$count]["start_day"]=date("j",strtotime($schedule_days[$count]["start"]));

								$e_h=date("H",$_e);
								$e_i=date("i",$_e);
								$e_s=date("s",$_e);

								//$add=$i;
								//$add=$i+$add_date;
								$add=$i;
								$schedule_days[$count]["end"]=date("Y-m-d {$e_h}:{$e_i}:{$e_s}",strtotime("+ {$add} day",$_s));
								$schedule_days[$count]["end_month_prefix"]=date("Ym",strtotime($schedule_days[$count]["end"]));
						}
				}

				return $schedule_days;
		}

		function __checkPostDataEmpty($post){

				$errors=array();

				foreach($this->requiredParams as $k=>$v){

						if(isset($post[$k]) AND !empty($post[$k])) continue;
						$errors[$k]=$v;
				}

				return $errors;
		}

		function __saveSiteInformation($site_id,$user_id,$customer_id,$post){

				$site_name    =$post["site_name"];
				$site_name_kana=$post["site_name_kana"];
				$site_customer=$post["site_customer"];
				$site_pref    =$post["site_pref"];
				$site_area    =$post["site_area"];
				$site_address =$post["site_address"];
				$site_ninku   =$post["site_power_num"];
				$site_remarks =$post["site_remarks"];
				$site_color_id=$post["site_color_id"];

				$save["name"]=$site_name;
				$save["name_kana"]=$site_name_kana;
				$save["customer_id"]=$customer_id;
				$save["area_id"]=$site_area;
				$save["address"]=$site_address;
				$save["remarks"]=$site_remarks;
				$save["power_num"]=min((Int)$site_ninku,9999);
				$save["color_id"]=$site_color_id;
				$save["edit_user_id"]=$user_id;
				if(!empty($site_id)) $save["id"]=$site_id;
				if(!$res=$this->TblMstepSiteDetail->save($save)) return false;
				return $res["TblMstepSiteDetail"];
		}

	function __getRegistedIdHistories($all_site_schedules) {

				$registed_site_ids=array();
				foreach($all_site_schedules as $k=>$v){

						$data=$v["TblMstepSiteSchedule"];
						$registed_site_ids[$data["start_month_prefix"].sprintf("%02d",$data["start_day"])]=$data["id"];
				}
				return $registed_site_ids;
		}

	function __getSeparatorRegistDays($schedule_enable_days, $current_days) {

			$res["new"]=array();
			$res["current"]=array();
			foreach($schedule_enable_days as $k => $date) {

					if(in_array($date,$current_days)){

							$res["current"][]=$date;
							continue;
					}

					$res["new"][]=$date;
			}
			return $res;
	}

		function __getNewRegistDays($schedule_enable_days, $visible_schedule_date_range) {

				sort($visible_schedule_date_range);
				$visible_start_date = $visible_schedule_date_range[0];
				$visible_end_date = $visible_schedule_date_range[count($visible_schedule_date_range) - 1];

				$new_regist_dates = array();
				$target_dates = array_diff($schedule_enable_days, $visible_schedule_date_range);
				foreach ($target_dates as $k => $date) {

						if ($visible_start_date >= $date OR $date >= $visible_end_date) {

								continue;
						}

						$new_regist_dates[] = $date;
				}

				return $new_regist_dates;
		}

		function __refreshScheduleTrucks($schedule_options=array()){

				$trucks=array();
				foreach($schedule_options as $schedule_id=>$v) $trucks[$schedule_id]=(isset($v["trucks"])?$v["trucks"]:array());
				$schedule_ids=array_keys($trucks);

				App::uses("SiteManagesController", "Controller");
				$controller = new SiteManagesController();
				$truck_history=$controller->__siteTruckIdHistories($schedule_ids);
				$res=$controller->__deleteSiteTrucks($schedule_ids);
				if(empty($res["status"])) return false;

				$counter=0;
				$insert=array();
				foreach($trucks as $schedule_id=>$trucks){
				
						if(empty($trucks)) continue;
						foreach($trucks as $_k=>$truck_id){
						
								if(!isset($truck_history[$schedule_id][$truck_id])) continue;
								$insert[$counter]["id"]=$truck_history[$schedule_id][$truck_id];
								$insert[$counter++]["del_flg"]=0;
						}
				}

				if(empty($insert)) return true;
				$res=$controller->__insertSiteTrucks($insert);
				if(empty($res["status"])) return false;
				return true;
		}

		function __refreshSiteWorkers($schedule_options=array()){

				$workers=array();
				foreach($schedule_options as $schedule_id=>$v) $workers[$schedule_id]=(isset($v["workers"])?$v["workers"]:array());
				$schedule_ids=array_keys($workers);

				App::uses("SiteManagesController", "Controller");
				$controller = new SiteManagesController();
				$worker_history=$controller->__siteWorkerIdHistories($schedule_ids);
				$res=$controller->__deleteSiteWorkersByScheduleId($schedule_ids);
				if(empty($res["status"])) return false;

				$counter=0;
				$insert=array();
				foreach($workers as $schedule_id=>$workers){
				
						if(empty($workers)) continue;
						foreach($workers as $_k=>$worker_id){
						
								if(!isset($worker_history[$schedule_id][$worker_id])) continue;
								$insert[$counter]["id"]=$worker_history[$schedule_id][$worker_id];
								$insert[$counter++]["del_flg"]=0;
						}
				}

				if(empty($insert)) return true;
				$res=$controller->__insertSiteWorkers($insert);
				if(empty($res["status"])) return false;
				return true;
		}

		function __tmpAddSite($post){

				$position_num =isset($post["position_num"])?$post["position_num"]:null;
				$user_id      =$post["user_id"];
				$around_values=isset($post["around_values"])?$post["around_values"]:array();
				$site_id=(isset($post["site_id"]) AND !empty($post["site_id"]))?$post["site_id"]:"";
				$customer_id=empty($post["site_customer_id"])?false:$post["site_customer_id"];
				$is_edit=!empty($site_id);

				//■カレンダーに設定されている日(削除は含まれない)
				$schedule_enable_days=isset($post["schedule_dates"])?$post["schedule_dates"]:array();
				$schedule_position   =isset($post["schedule_positions"])?$post["schedule_positions"]:array();
				//■可視化されている情報のみ送信される
				$schedule_options=isset($post["schedule_options"])?$post["schedule_options"]:array();

	            $datasource=$this->TblMstepSiteDetail->getDataSource();
	            $datasource->begin();

				//around values.
				if(!empty($around_values)){

						$res=$this->TblMstepSiteDetail->updateAroundValues($around_values);
						if(empty($res["status"])){

								throw new Exception(1);
								return;
						} 
				}

				$position_result["status"]=true;
				if(!empty($schedule_position)) $position_result=$this->__updateSchedulePosition($schedule_position);
				if(empty($position_result["status"])){

						throw new Exception(5);
						return;
				}

				if(empty($customer_id) AND $is_edit){

						$site_detail=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0);
						$customer_id=$site_detail["TblMstepSiteDetail"]["customer_id"];
				}

				$registed_site_id_histories=$current_days=array();
				if($is_edit){

						$this->TblMstepSiteSchedule->unbindFully();
						$all_site_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);
						$registed_site_id_histories=$this->__getRegistedIdHistories($all_site_schedules);
						$current_days = array_keys($registed_site_id_histories);
				}

				$regist_days=$this->__getSeparatorRegistDays($schedule_enable_days,$current_days);
				$all_position_ids=$this->__getAllPositionNums($schedule_enable_days);
				if(!$tmp_schedule_position=Set::classicExtract($schedule_position, "{[a-zA-Z0-9-_.]}.{n}.position_num")) $tmp_schedule_position = array();
				$all_position_ids=$tmp_schedule_position+$all_position_ids;

				$visible_dates=array();
				$visible_range_new_regist_schedule=array();
				if(!empty($schedule_options)) {

						if(!$this->__refreshSiteWorkers($schedule_options)){

								throw new Exception(5);
								return;
						}

						if(!$this->__refreshScheduleTrucks($schedule_options)){

								throw new Exception(5);
								return;
						}

						$visible_schedule_date_range = Set::extract($schedule_options, "{}.day");
						$visible_range_new_regist_schedule = $this->__getNewRegistDays($schedule_enable_days, $visible_schedule_date_range);
						$visible_dates=Set::extract($schedule_options,"{}.day");
				}

				//v(array_diff(array("a","b","c"),array("b")));
				//v($regist_days);
				//v($visible_schedule_date_range,1);
				//v($visible_range_new_regist_schedule);
				//v($schedule_options);
				$new_regist_dates=array_unique(array_merge($regist_days["new"],$visible_range_new_regist_schedule));
				//v($new_regist_dates,1);
				//v($visible_dates);
				//$new_regist_dates=array_values(array_diff($new_regist_dates,$visible_dates));
				//v($new_regist_dates);
				$current_regist_dates=array_values(array_diff($regist_days["current"], $new_regist_dates));
				//v($new_regist_dates);

				//customer.
				$customer_id="";
				if(!empty($post["site_customer"])){

						$customer_id=$this->__saveCustomer(array(

								"name"       =>$post["site_customer"],
								"customer_id"=>$customer_id,
						));
				}

				if(!$site_information=$this->__saveSiteInformation($site_id,$user_id,$customer_id,$post)){

						throw new Exception(5);
						return;
				}

				//schedules.
				if(!$is_edit) $site_id=$this->TblMstepSiteDetail->getLastInsertID();

				//v($new_regist_dates,1);
				//v($current_regist_dates);

				//edit.
				$update_result["status"]=true;
				if(!empty($current_regist_dates) AND !empty($schedule_options)){

						$update_result=$this->__updateSiteSchedule($current_regist_dates,$schedule_options,array(

							    "site_color_id"             =>$post["site_color_id"],
								"registed_site_id_histories"=>$registed_site_id_histories
						));

						if(empty($update_result["status"])){

								throw new Exception(5);
								return;
						}
				}

				//new regist.
				if(!empty($new_regist_dates)){

						$insert_result=$this->__registNewSiteSchedule($new_regist_dates, array(

								"site_id"         =>$site_id,
								"position_num"    =>$post["position_num"],
								"color_id"        =>$post["site_color_id"],
								"all_position_ids"=>$all_position_ids,
						));

						if(empty($insert_result["status"])){

								throw new Exception($insert_result["error"]);
								return;
						}
				}

				$datasource->commit();

				$res["status"]=true;
				$res["data"]["site_id"]=$site_information["id"];
				return $res;
		}

		function __updateSchedulePosition($schedule_positions = array()) {

				$insert = array();
				$counter = 0;
				foreach ($schedule_positions as $date => $v) {

						$s=strtotime($date);
						foreach ($v as $k => $_v) {

								$schedule_id=$_v["schedule_id"];
								if(is_numeric(strpos($schedule_id,"TMP_"))) continue;
								$insert[$counter]["id"]=$schedule_id;
								$insert[$counter]["start_month_prefix"]=date("Ym",$s);
								$insert[$counter]["start_day"]=date("j",$s);
								$insert[$counter]["start_date"]=date("Y/m/d 00:00:00",$s);
								$insert[$counter]["end_date"]=$insert[$counter]["start_date"];
								$insert[$counter]["position_num"] = $_v["position_num"];
								$counter++;
						}
				}

				return $this->__multiInsert($this->TblMstepSiteSchedule, $insert);
		}

		function __updateSiteSchedule($schedule_dates,$schedule_options,$params){

				$counter=0;
				$insert=array();
				$color_id=$params["site_color_id"];
				$registed_site_ids=$params["registed_site_id_histories"];
				foreach($schedule_options as $schedule_id=>$v){

						if(is_numeric(strpos($schedule_id,"TMP_"))) continue;
						$index=array_search($v["day"],$schedule_dates);
						if(is_numeric($index)) unset($schedule_dates[$index]);

						$s=strtotime($v["day"]);
						$date=date("Y/m/d 00:00:00",$s);
						$insert[$counter]["position_num"]=$v["position_num"];
						$insert[$counter]["start_month_prefix"]=date("Ym",$s);
						$insert[$counter]["start_day"]=date("j",$s);
						$insert[$counter]["start_date"]=$date;
						$insert[$counter]["end_date"]=$date;
						$insert[$counter]["color_id"]=$color_id;
						$insert[$counter]["del_flg"] =0;
						$insert[$counter]["id"]=$schedule_id;
						$counter++;
				}

				$res=$this->__multiInsert($this->TblMstepSiteSchedule,$insert);
				if(empty($res["status"])) return $res;

				if(!empty($schedule_dates)){

						$counter=0;
						$insert=array();
						foreach($schedule_dates as $k=>$date){

								$schedule_id=$registed_site_ids[$date];
								$insert[$counter]["id"]=$schedule_id;
								$insert[$counter]["del_flg"]=0;
								$counter++;
						}

						$res=$this->__multiInsert($this->TblMstepSiteSchedule,$insert);
						if(empty($res["status"])) return $res;
				}

				$res=array();
				$res["status"]=true;
				return $res;
		}

		function __registNewSiteSchedule($dates=array(),$params,$insert_datas=array()){

				if(empty($dates)){

						$res["status"]=true;
						$res["insert_datas"]=$insert_datas;
						return $res;
				}

				$color_id=$params["color_id"];
				$site_id =$params["site_id"];
				$position_num=$params["position_num"];
				$all_position_ids=$params["all_position_ids"];
				$date=array_shift($dates);

				$current_position_ids=isset($all_position_ids[$date])?$all_position_ids[$date]:array();
				$position=SchedulePosition::checkIFSamePosition($current_position_ids,$position_num);

				if(!is_numeric($position)){

						$res["error"]=4;
						$res["status"]=false;
						return $res;
				}

				$s=strtotime($date);
				$date=date("Y/m/d 00:00:00",$s);
				$save["color_id"]=$color_id;
				$save["position_num"]=$position;
				$save["start_month_prefix"]=date("Ym",$s);
				$save["start_day"]=date("j",$s);
				$save["site_id"]=$site_id;
				$save["start_date"]=$date;
				$save["end_date"]  =$date;
				$this->TblMstepSiteSchedule->id=null;
				if(!$this->TblMstepSiteSchedule->save($save)){

						$res["status"]=false;
						$res["error"]=5;
						return $res;
				}

				$schedule_id=$this->TblMstepSiteSchedule->getLastInsertID();
				$save["schedule_id"]=$schedule_id;
				$save["date"]=$date;
				$insert_datas[]=$save;
				return $this->__registNewSiteSchedule($dates,$params,$insert_datas);
		}

		function __refreshNinku($dates=array()){

				$res["status"]=true;
				$res["site_ids"]=array();

				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($dates);
				if(empty($inserts)) return $res;
				$res=$this->__multiInsert($this->TblMstepSiteWorker,$inserts);
				if(empty($res["status"])) return $res;
				$res["site_ids"]=array_unique(Set::extract($inserts,"{}.site_id"));
				return $res;
		}

		function tmpAddSite(){

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				//if($res=$this->__checkPostDataEmpty($post)) Output::__outputStatus(1);
				
				$user_id=$post["user_id"];
				$instance=new TimeoutInvestigationExec($this,$this->Session);
				if(!$instance->checkLastEditTimeSesKey(UNIQUE_KEY,$user_id)) Output::__outputStatus(3);

				try{

						$res=$this->__tmpAddSite($post);

				}catch(Exception $e){

						Output::__outputStatus($e->getMessage());
				}

				$schedule_enable_days=isset($post["schedule_dates"])?$post["schedule_dates"]:array();
				$res_ninku=$this->__refreshNinku($schedule_enable_days);
				$refresh_ninku_siteids=$res_ninku["site_ids"];

				$this->TblMstepSiteSchedule->unbindFully();
				$site_id = $res["data"]["site_id"];
				$schedules = $this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);
				$schedule_ids = Set::extract($schedules, "{}.TblMstepSiteSchedule.id");

				/*
				// edit limited time.
				$last_edit_time=time();
				$instance=ScheduleLog::getInstance($this);
				if(!$instance->timeInitialize($user_id,$last_edit_time)) Output::__outputNo();
				*/

				// edit information.
				$edit_detail[$site_id]=array("edit_user_id"=>$user_id,"modified"=>date("Y/m/d H:i:s"));
				$instance=new ScheduleGetLastEditSiteUser($this);
				$instance->setSiteInformations($edit_detail);
				$edit_informations=$instance->getEditUsersInformations();

				// new informations.
				$schedule_info=!isset($post["schedule_info"])?array():$post["schedule_info"];
				if(!isset($schedule_info["start_date"])) $schedule_info["start_date"]=date("Ym01");
				if(!isset($schedule_info["end_date"]))   $schedule_info["end_date"]=date("Ymt");
				$min_start_dates=(empty($schedules)?array():min(Set::extract($schedules,"{}.TblMstepSiteSchedule.start_date")));
				$max_end_dates  =(empty($schedules)?array():max(Set::extract($schedules,"{}.TblMstepSiteSchedule.end_date")));

				$information_start_date=(empty($min_start_dates)?$schedule_info["start_date"]:min(array(date("Ymd",strtotime($min_start_dates)),$schedule_info["start_date"])));
				$information_end_date  =(empty($max_end_dates)?$schedule_info["end_date"]:max(array(date("Ymd",strtotime($max_end_dates)),$schedule_info["end_date"])));
				$start_date=date("Y-m-d",strtotime($information_start_date));
				$end_date=date("Y-m-d",strtotime($information_end_date));

				$informations=$this->__getInformations($start_date,$end_date);
				$ninku_situations=$this->__getSiteNinkuSituations($refresh_ninku_siteids);
				$customer_informations=$this->__getCustomerInformations();

				$instance=ScheduleLog::getInstance($this);
				$last_edit_time=$instance->getLastEditTime();

				$output["customer_informations"]=$customer_informations;
				$output["informations"]=$informations["informations"];
				$output["edit_information"]=$edit_informations;
				$output["schedule_ids"]=$schedule_ids;
				$output["ninku_situations"]=$ninku_situations;
				$output["site_id"]=$site_id;
				$output["last_edit_time"]=$last_edit_time;
				Output::__outputYes($output);
		}

		function __saveCustomer($params){

				$customer_id=$params["customer_id"];
				$name       =$params["name"];
				$is_edit    =!empty($customer_id);

				$save=array();
				if($is_edit) $save["id"]=$customer_id;
				$save["name"]=$name;
				if(!$res=$this->TblMstepCustomer->save($save)) return false;
				$customer_id=($is_edit)?$customer_id:$this->TblMstepCustomer->getLastInsertID();
				return $customer_id;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));
				return $res;
		}

		function __getAllPositionNums($dates=array()){

				$this->TblMstepSiteSchedule->unbindFully();
				$schedules=$this->TblMstepSiteSchedule->getSiteScheduleByDate($dates);
				$position_nums=array();
				foreach($schedules as $k=>$v) {

						$start_date=date("Ymd",strtotime($v["TblMstepSiteSchedule"]["start_date"]));
						$position_nums[$start_date][]=$v["TblMstepSiteSchedule"]["position_num"];
				}

				return $position_nums;
		}

		function __getSiteNinkuSituations($site_ids=array()) {

				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __getCustomerInformations($customer_ids=array()){

				App::uses("SiteManagesCustomersController", "Controller");
				$controller = new SiteManagesCustomersController();
				$res = $controller->__getCustomerInformations($customer_ids);
				return $res;
		}

}//END class

?>
