<?php

/**
 * Created by PhpStorm.
 * User: Edward
 * Date: 2/13/17
 * Time: 9:51 AM
 */
App::import('Utility','Sanitize');
class ProfileController extends AppController {
	/** @var string $name is name of Controller */
	var $name="Profile";
	
	/** @var array $uses is databases will be using in this Controller */
	var $uses=array('TblMstepProfile');
	
	public function beforeFilter() {
		parent::beforeFilter();
	}
	
	public function index() {
		$profile = $this->TblMstepProfile->findById($this->Session->read('CLIENT_INFO.id'));
		$profile=$profile['TblMstepProfile'];
		$isMaster=($this->Auth->user('authority')==='master');
//		var_dump($profile);
		$this->set(compact('profile', 'isMaster'));
		/*if($this->Auth->user('authority')==='master'){
			$this->render('edit');
		}
		else {
			$this->render('view');
		}*/
	}
	
	public function update(){
		if($this->request->is('Ajax') and $this->isPostRequest()) {
			if(
				$this->Session->check('CLIENT_INFO.id')
				and isset($_POST['client_id'])
				and $this->Session->read('CLIENT_INFO.id')===$_POST['client_id']){
				$this->TblMstepProfile->id=$_POST['client_id'];
				array_shift($_POST);
				array_walk($_POST, function(&$value, $key){
					$value=htmlentities($value);
				});
				$this->TblMstepProfile->save($_POST);
				
				Output::__outputYes();
			}
		}
		
		Output::__outputNo();
	}
}