<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";
require_once "Schedule".DS."ScheduleLog.php";

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

//require_once(dirname(ROOT).DS."sendgrid-php".DS."sendgrid-php.php");

App::uses('Component','Controller');

//require_once(dirname(ROOT).DS."vendor".DS."autoload.php");
//use Japanese\Holiday\Repository as HolidayRepository;
App::uses('ScheduleBaseController','Controller');
class SiteController extends ScheduleBaseController {

	var $name = "Site";
	var $uses = [
		"TblMstepSiteDetail",
		"TblMstepSiteSchedule",
		"TblMstepSiteWorker",
		"TblMstepWorker",
		"TblMstepGroupWorker",
		"TblMstepAreaInformation",
		"TblMstepCustomer",
		"TblMstepTruck",
		"TblMstepScheduleTruck",
		"TblMstepCustomerInchargeUser",
		"TblMstepScheduleLog",
		"TblMstepMasterUser",
		"TblMstepSiteScheduleRemark",
		"TblMstepSiteRemarkTitle",
	];
	
	public function isAuthorized($user) {
	
	// All registered users can view index and search staff
//		return true;
		//if (in_array($this->action, array('index'))) {return true;}
		//return parent::isAuthorized($user);
		return true;
	}

	function beforeFilter() {

		parent::beforeFilter();
		$this->__init();

		// base informations.
		$firstname = $this->Auth->user("first_name");
		$this->set(compact("firstname"));
	}

		function __init(){

				$this->unbindFully();
		}

		function __startDateArgesValidate($start_date){

				if(!$start_date || strlen($start_date)!=8 || !is_numeric($start_date)) return false;
				$year =substr($start_date,0,4);
				$month=substr($start_date,4,2);
				$day=substr($start_date,6,2);
				if(!checkDate($month,$day,$year)) return false;
				return true;
		}

		function index($base_start_time=""){

				#■前後１ヶ月のデータ
				if(!$this->__startDateArgesValidate($base_start_time)) $base_start_time=date("Ymd");

				$base_start_time=strtotime($base_start_time);
				//$start = date("Y-m-d", strtotime("-1 month",$base_start_time));
				//$end = date("Y-m-d", strtotime("+1 month",$base_start_time));
				$start = date("Y-m-d", strtotime("-10 day",$base_start_time));
				$end = date("Y-m-d", strtotime("+10 day",$base_start_time));

				$worker_id=$this->Auth->user("worker_id");
				$data=$this->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));

				$informations=$data["informations"];
				$site_ids=$data["data"]["site_ids"];

				$site_ids=array();
				if(!empty($informations)) $site_ids=array_values(array_unique(array_filter(Set::classicExtract($informations,"{[a-zA-Z0-9-_.]}.0.site_detail.id"),"strlen")));
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$instance=ScheduleGetLastEditSiteUser::getInstance($this);
				$edit_informations=$instance->getEditUsersInformations();

				//■memo
				$memos=$this->__getMemoList();

				//■prefs
				$tsv=new TSV();
				$prefs=$tsv->getTSV("pref");

				//■schedule_remarks
				$remark_titles  =$this->__getRemarkTitles();
				$instance       =ScheduleLog::getInstance($this);
				$last_edit_time =$instance->getLastEditTime();
				$last_start_user=$instance->getLastStartUser();
				$last_edit_user_id=$instance->getLastEditUser();
				$edit_time_expired_ms=$instance->getLastEditTimeExpireMs();

				//■user edited last imformation.
				$last_modified_user=array();
				if(!empty($last_edit_user_id)){ 

						$last_modified_user=$this->__getLastModifiedInformations($last_edit_user_id);
						$last_modified_user["last_edit_ms"]=$last_edit_time;
						$last_modified_user["edit_time_expired"]=$edit_time_expired_ms;
				}

				//■weather
				$weather = $this->__getImageByWeatherDate($this->Auth->user('pref_id'));

				$user_id=$this->Auth->user("id");
				$is_authority=$this->__checkAuthorityToEdit($user_id)?1:0;

				//v($informations);
				$edit_informations =   mstepJsonEncode($edit_informations);
				$base_start_ms = ($base_start_time * 1000);
				$remark_titles =       mstepJsonEncode($remark_titles);
				$informations =        mstepJsonEncode($informations);
				$weather =             mstepJsonEncode($weather);
				$memos =               mstepJsonEncode($memos);
				$prefs =               mstepJsonEncode($prefs);
				$last_modified_user =  mstepJsonEncode($last_modified_user);
				$ninku_situations   =  mstepJsonEncode($ninku_situations);
				$client_data_sessions= mstepJsonEncode(CLIENT_DATA_SESSION);
				$worker_count=$this->TblMstepWorker->getRestWorkerCount();
				$server_time_ms=time()*1000;

				$this->set(compact("informations",
								   "last_edit_time",
								   "edit_time_expired_ms",
								   "last_start_user",
								   "last_modified_user",
								   "is_authority",
								   "weather",
								   "worker_count",
								   "remark_titles",
								   "base_start_ms",
								   "edit_informations",
								   "client_data_sessions",
								   "server_time_ms",
								   "ninku_situations",
								   "memos",
								   "prefs"));
		}

		function getAddDateApi(){

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				
				$date = isset($post["date"]) ? $post["date"] : date("Ymd");
		        $day = isset($post["day"]) ? $post["day"] : "14";
		        $start = date("Y-m-d", strtotime($date));
		        $end = date("Y-m-d", strtotime("+ {$day} day", strtotime($date)));

				$worker_id=$this->Auth->user("worker_id");
				$data=$this->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));

				$instance=ScheduleGetLastEditSiteUser::getInstance($this);
				$edit_informations=$instance->getEditUsersInformations();

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function getDateRange(){

				if(!$this->isPostRequest()) exit;

				$post=$_POST;
				$start=(!isset($post["start"]))?date("Ymd"):$post["start"];
				$end  =(!isset($post["end"]))?date("Ymd",strtotime("+14 day",strtotime($start))):$post["end"];

				$worker_id=$this->Auth->user("worker_id");
				$informations=$this->__getDateRange($start,$end,$worker_id);

				$res["data"]["informations"]=$informations;
				$res["status"] = "YES";
				Output::__output($res);
		}

		function __getDateRange($start,$end,$worker_id){

				$data=$this->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));

				$informations=$data["informations"];
				if(empty($informations)) $informations=$this->__makeDatePeriod($start,$end);
				return $informations;
		}

		function getSubDateApi(){

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				$log_path=$this->__getLogPath();
				$post=unserialize(file_get_contents($log_path));
   				$date = isset($post["date"]) ? $post["date"] : date("Ymd");
			    $day = isset($post["day"]) ? $post["day"] : "14";
				//$date="20170131";

			    $end = date("Y-m-d", strtotime($date));
			    $start = date("Y-m-d", strtotime("- {$day} day", strtotime($date)));

				$worker_id=$this->Auth->user("worker_id");
				$data=$this->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));

				$instance=ScheduleGetLastEditSiteUser::getInstance($this);
				$edit_informations=$instance->getEditUsersInformations();

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"] = "YES";
				Output::__output($res);
		}

		function __getMemoList() {

				App::uses("SiteManagesMemoController", "Controller");
				$controller = new SiteManagesMemoController();
				$res = $controller->__getMemoList();
				return $res;
		}

		// for class.
		function __getLastModifiedInformations($last_edit_user_id){

				//user edited last imformation.
				//$last_modified_user=array();
				//if(!$last_modified=$this->TblMstepScheduleLog->findOne()) return $last_modified_user;
				//if(empty($last_modified["TblMstepScheduleLog"]["edit_user_id"])) return $last_modified_user;

				//$user_id = $last_modified["TblMstepScheduleLog"]["edit_user_id"];
				$master_user = $this->TblMstepMasterUser->findById($last_edit_user_id);
				//$last_modified_user["last_edit_ms"] = strtotime($last_modified["TblMstepScheduleLog"]["edit_time"]) * 1000;
				//$last_modified_user["edit_time_expired"] = $last_modified["TblMstepScheduleLog"]["edit_time_expired_ms"] * 1000;
				$last_modified_user["user"]["first_name"] = stripslashes($master_user["TblMstepMasterUser"]["first_name"]);
				$last_modified_user["user"]["last_name"] = stripslashes($master_user["TblMstepMasterUser"]["last_name"]);
				return $last_modified_user;
		}

		function __makeDatePeriod($start, $end) {

				$diff = (strtotime($end) - strtotime($start)) / (60 * 60 * 24);
				for ($i = 0; $i <= $diff; $i++) {

						$period[date("Ymd", strtotime($start . "+" . $i . "days"))] = array();
				}

				return $period;
		}

		function __getWorkerSchedules($data) {

				$res = array();
				foreach ($data as $k => $v) {

						$__data=$v["TblMstepSiteWorker"];
						$res[$__data["site_id"]][$__data["schedule_id"]][$__data["worker_id"]]["man_hour"]  =$__data["man_hour"];
						$res[$__data["site_id"]][$__data["schedule_id"]][$__data["worker_id"]]["assign_flg"]=$__data["assign_flg"];
				}
				return $res;
		}

		function __getColorList($is_set=false){

				App::uses("SiteManagesColorController", "Controller");
				$controller=new SiteManagesColorController();
				$color_list=$controller->__getColorList();

				if($is_set){

						$json_color_list = mstepJsonEncode($color_list);
						$this->set(compact("json_color_list"));
				}

				return $color_list;
		}

		function __targetYm($start,$end){

                $res =array();
                $s   =strtotime($start);
                $s_ymd=date("Ym01",$s);
                $e_ymd=date("Ym01",strtotime($end));

                $res[]=date("Ym",$s);
                if($s_ymd==$e_ymd) return $res;

                while(1){
                                
                        if($s_ymd==$e_ymd) break;
                        $s=strtotime($s_ymd);
                        $s_ymd=date("Ym01",strtotime("+1 month",$s));
                        $res[]=date("Ym",strtotime($s_ymd));
                }

                return $res;
        }

		function __siteWorkerAssignflg($site_workers){

				return array_filter($site_workers,function($a){

						return !empty($a["TblMstepSiteWorker"]["assign_flg"]);
				});
		}

		// i'm sorry tooooo looooong!!!
		function __getInformations($start,$end,$params=array()) {

				$informations=$this->__makeDatePeriod($start, $end);

				//■color list
				$color_list=$this->__getColorList(true);

				//■initialize response data.
				$res=array();
				$res["informations"]=array();
				$res["last_modified_ms"]="";

				//■some schuedule by some day
				$worker_id=$params["worker_id"];
				$target_ym =$this->__targetYm($start,$end);
				$this->TblMstepSiteSchedule->unbindFully();
				$work_schedules=array();
				if(!empty($worker_id)) $work_schedules=$this->TblMstepSiteSchedule->getScheduleByYmAndSiteWorker($target_ym,$worker_id);
				if(empty($worker_id))  $work_schedules=$this->TblMstepSiteSchedule->findAllByStartMonthPrefixAndDelFlg($target_ym,0);
				if(empty($work_schedules)){

						$res["data"]["schedule_ids"]=array();
						$res["data"]["site_ids"]=array();
						$res["informations"]=$informations;
						return $res;
				}

				//■work details
				$all_site_start_dates=Set::combine($work_schedules,"{n}.TblMstepSiteSchedule.site_id","{n}.TblMstepSiteSchedule.start_date");
				$target_site_ids=array_keys($all_site_start_dates);
				$work_details=$this->TblMstepSiteDetail->getWorkDetail($target_site_ids);
				$work_details=Set::combine($work_details,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail");
				$instance=ScheduleGetLastEditSiteUser::getInstance($this);
				$instance->setSiteInformations($work_details);
	
				//■customer
				$customer_ids=Set::extract($work_details, "{}.customer_id");
				$customer_information=$this->TblMstepCustomer->getCustomerInfomration($customer_ids);
				$customer_information=$this->__arrangeAry($customer_information, $this->TblMstepCustomer->primaryKey);

				//■work area
				$area_ids=Set::extract($work_details,"{}.area_id");
				$area_ids=array_values(array_unique($area_ids));

				$work_areas=$this->TblMstepAreaInformation->getWorkArea($area_ids);
				$work_areas=$this->__arrangeAry($work_areas,$this->TblMstepAreaInformation->primaryKey);

				//■worker
				$schedule_ids=Set::extract($work_schedules, "{}.TblMstepSiteSchedule.id");
				$f=array("site_id","schedule_id","worker_id","man_hour","assign_flg");
				$site_workers=$this->TblMstepSiteWorker->getSiteWorkers($schedule_ids,$f);
				if(!empty($site_workers)) $site_workers=$this->__siteWorkerAssignflg($site_workers);

				$site_worker_ids = array();
				if(!empty($site_workers)) $site_worker_ids=array_unique(Set::extract($site_workers,"{}.TblMstepSiteWorker.worker_id"));

				$site_worker_schedules=$this->__getWorkerSchedules($site_workers);

				//■numbar of truck already reserved.
				$truck_schedules=$this->__truckInformations($schedule_ids);

				//■Truck information
				$trucks=$this->TblMstepTruck->findAllByDelFlg(0);
				$trucks=Set::combine($trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck.name");

				//■worker(parson)
				//■number of one is target too.
				$workers=$this->TblMstepWorker->getWorkers($site_worker_ids);
				$workers=$this->__arrangeAry($workers, $this->TblMstepWorker->primaryKey);

				//■ScheduleRemarks
				$schedule_remarks=$this->TblMstepSiteScheduleRemark->findAllByScheduleIdAndDelFlg($schedule_ids, 0);
				$schedule_remarks=Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");

				foreach ($work_schedules as $k => $v) {

						$site_id=$v["TblMstepSiteSchedule"]["site_id"];
						$schedule_id=$v["TblMstepSiteSchedule"]["id"];
						$date = date("Ymd", strtotime($v["TblMstepSiteSchedule"]["start_date"]));

						if(!isset($informations[$date])){

								$informations[$date]=array();
						}

						$count=count($informations[$date]);

						//■schedule
						$site_schedule=$v["TblMstepSiteSchedule"];
						$informations[$date][$count]["schedule"]["id"] = $schedule_id;
						$informations[$date][$count]["schedule"]["position_num"] = $site_schedule["position_num"];
						//$informations[$date][$count]["schedule"]["start_date_ms"] = (strtotime($v["TblMstepSiteSchedule"]["start_date"]) * 1000);

						$start_day=sprintf("%02d",$site_schedule["start_day"]);
						$s_time=strtotime($site_schedule["start_month_prefix"].$start_day);
						$informations[$date][$count]["schedule"]["start_date_ms"]=($s_time*1000);
						$informations[$date][$count]["schedule"]["start_month_prefix"]=$site_schedule["start_month_prefix"];
						$informations[$date][$count]["schedule"]["start_day"]=$start_day;

						$informations[$date][$count]["schedule"]["remarks"] = "";
						if (isset($schedule_remarks[$schedule_id])) {

								$informations[$date][$count]["schedule"]["remarks"] = changeToBr(stripslashes($schedule_remarks[$schedule_id]["remarks1"]));
						}

						$informations[$date][$count]["schedule"]["remarks2"] = "";
						if (isset($schedule_remarks[$schedule_id])) {
							$informations[$date][$count]["schedule"]["remarks2"] = changeToBr(stripslashes($schedule_remarks[$schedule_id]["remarks2"]));
						}

						$informations[$date][$count]["schedule"]["remarks3"] = "";
						if (isset($schedule_remarks[$schedule_id])) {
							$informations[$date][$count]["schedule"]["remarks3"] = changeToBr(stripslashes($schedule_remarks[$schedule_id]["remarks3"]));
						}

						$color_id = $v["TblMstepSiteSchedule"]["color_id"];
						$color = (!isset($color_list[$color_id])) ? $color_list[$work_details[$site_id]["color_id"]] : $color_list[$color_id];
						$informations[$date][$count]["schedule"]["color"] = $color;

						//■site
						$informations[$date][$count]["site_detail"]["name"] = stripslashes($work_details[$site_id]["name"]);
						$informations[$date][$count]["site_detail"]["power_num"] = $work_details[$site_id]["power_num"];
						$informations[$date][$count]["site_detail"]["remarks"] = changeToBr(stripslashes($work_details[$site_id]["remarks"]));
						$informations[$date][$count]["site_detail"]["id"] = $site_id;
						$informations[$date][$count]["site_detail"]["around_value"]=$work_details[$site_id]["around_value"];

						//■Ninku
						//v($site_worker_schedules);
						$ninku_values=isset($site_worker_schedules[$site_id][$schedule_id])?$site_worker_schedules[$site_id][$schedule_id]:array();
						$informations[$date][$count]["site_workers"]["ninku"]=$ninku_values;

						//■location
						$is_area = !empty($work_details[$site_id]["area_id"]);
						$informations[$date][$count]["location"]["pref"] = ($is_area) ? $work_areas[$work_details[$site_id]["area_id"]]["pref"] : "";
						$informations[$date][$count]["location"]["town"] = ($is_area) ? $work_areas[$work_details[$site_id]["area_id"]]["address1"] : "";
						$informations[$date][$count]["location"]["address"] = addcslashes((($is_area)?$work_details[$site_id]["address"]:""),"\\");

						//■customer
						$customer_id=$work_details[$site_id]["customer_id"];
						if(empty($customer_id) OR !isset($customer_information[$customer_id])){

								$customer=array();
								$informations[$date][$count]["customer"]["name"]   ="";
						}
						else{

								$customer=$customer_information[$customer_id];
								$informations[$date][$count]["customer"]["name"] =stripslashes($customer["name"]);
						}

						//■number of trucks
						$informations[$date][$count]["truck"]["needed_num"] =$work_details[$site_id]["delivery"];
						$informations[$date][$count]["truck"]["reserved"]   =array();
						if (isset($truck_schedules[$schedule_id])) {

								foreach ($truck_schedules[$schedule_id] as $id => $_v) {

										if(!isset($trucks[$_v["truck_id"]])) continue;
										$__count = count($informations[$date][$count]["truck"]["reserved"]);
										$informations[$date][$count]["truck"]["reserved"][$__count]["id"] = $id;
										$informations[$date][$count]["truck"]["reserved"][$__count]["truck_id"] = $_v["truck_id"];
										$informations[$date][$count]["truck"]["reserved"][$__count]["name"] = stripslashes($trucks[$_v["truck_id"]]);
								}
						}

						//■worker
						$informations[$date][$count]["worker"]=array();
						$worker_ids=isset($site_worker_schedules[$site_id][$schedule_id])?array_keys($site_worker_schedules[$site_id][$schedule_id]):array();
						if(1>count($worker_ids)) continue;

						$worker_count=0;
						foreach ($worker_ids as $k => $worker_id) {

								if(!isset($workers[$worker_id])) continue;
								$del_status=$workers[$worker_id]["del_flg"];
								if($del_status==1 AND $date>date("Ymd",strtotime($workers[$worker_id]["del_date"]))){

										continue;
								}

								$informations[$date][$count]["worker"][$worker_count]["id"]=$worker_id;
								$informations[$date][$count]["worker"][$worker_count]["first_name"]=stripslashes($workers[$worker_id]["first_name"]);
								$informations[$date][$count]["worker"][$worker_count]["last_name"] =stripslashes($workers[$worker_id]["last_name"]);
								$informations[$date][$count]["worker"][$worker_count]["nickname"]=stripslashes($workers[$worker_id]["nickname"]);
								$informations[$date][$count]["worker"][$worker_count]["del_flg"]=empty($workers[$worker_id]["del_flg"])?0:1;
								$del_date_ms=($workers[$worker_id]["del_flg"]==1?strtotime($workers[$worker_id]["del_date"])*1000:0);
								$informations[$date][$count]["worker"][$worker_count++]["del_date_ms"]=$del_date_ms;
						}
				}

				$res = array();
				$res["informations"]=$informations;
				$res["data"]["schedule_ids"]=Set::extract($work_schedules,"{}.TblMstepSiteSchedule.id");
				$res["data"]["site_ids"]=array_unique(Set::extract($work_schedules,"{}.TblMstepSiteSchedule.site_id"));
				return $res;
		}

	function __getRemarkTitles() {

			$res=array();
			$def="備考";
			$res["schedule"]=array("remarks1"=>$def,"remarks2"=>$def,"remarks3"=>$def);
			$res["site"]    =array("remarks1"=>$def);
			if(!$site_remark_titles=$this->TblMstepSiteRemarkTitle->findOne()) return $res;
			$res["schedule"]["remarks1"] = addcslashes($site_remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark1"],"\\");
			$res["schedule"]["remarks2"] = addcslashes($site_remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark2"],"\\");
			$res["schedule"]["remarks3"] = addcslashes($site_remark_titles["TblMstepSiteRemarkTitle"]["schedule_remark3"],"\\");
			$res["site"]["remarks1"] = addcslashes($site_remark_titles["TblMstepSiteRemarkTitle"]["site_remark1"],"\\");
			return $res;
	}

	function __truckInformations($schedule_ids = array()) {

		if (!$data = $this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($schedule_ids,0)) {

				return array();
		}

		$res = array();
		foreach ($data as $k => $v) {

			$_v = $v["TblMstepScheduleTruck"];
			$res[$_v["schedule_id"]][$_v["id"]]["truck_id"] = $_v["truck_id"];
			$res[$_v["schedule_id"]][$_v["id"]]["remarks"] = $_v["remarks"];
		}
		return $res;
	}

	function __getWeekFromToday() {

		$start = date("Y-m-d");
		$end = date("Y-m-d", strtotime("+6 day", time()));
		$period = $this->__makeDatePeriod($start, $end);
		return array_keys($period);
	}

	function __getImageByWeatherDate($user_pref_id) {

			App::uses("SiteManagesWeatherController", "Controller");
			$controller = new SiteManagesWeatherController();
			$res = $controller->__getImageByWeatherDate($user_pref_id);
			return $res;
	}

	function __getSiteNinkuSituations($site_ids=array()) {

			App::uses("SiteManagesNinkuController", "Controller");
			$controller = new SiteManagesNinkuController();
			$res = $controller->__getSiteNinkuSituations($site_ids);
			return $res;
	}

	function __checkAuthorityToEdit($user_id){

			$time_key=$this->Session->read(TimeoutInvestigationKeys::makeTimeSesKey(UNIQUE_KEY));

			App::uses("SiteManagesEditAuthoritiesController","Controller");
			$controller=new SiteManagesEditAuthoritiesController();
			$is_edit=$controller->__checkAuthorityToEditWithDeadline($user_id,$time_key);
			return $is_edit;
	}

} //END class

?>
