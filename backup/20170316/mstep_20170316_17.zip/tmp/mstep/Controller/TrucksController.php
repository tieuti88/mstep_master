<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Minh Hung
 * @Date:   2016-11-14
 */

class TrucksController extends AppController {
    var $name = 'Truck';
    var $uses = [
            'TblMstepTruck',
            'TblMstepScheduleTruck'
    ];

    function beforeFilter() {

        parent::beforeFilter();
    }

    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {

        // All registered users can logout
//         if ($this->action === 'index' || $this->action === 'searchTruckByConditions') {
//             return true;
//         }

        return parent::isAuthorized($user);
    }

	public function index() {
	    $this->paginate = array(
	            'limit' => 20,
	            'conditions' => array(
	                    'TblMstepTruck.del_flg' => '0'
	            ),
	            'fields' => array(
	                    'id',
	                    'name',
	                    'remarks'
	            )
	    );

	    $listTruck = $this->paginate("TblMstepTruck");

	    $this->set(compact('listTruck'));
	}

	/**
	 * search trucks
	 *
	 * @param null
	 *
	 * @return list trucks
	 */
	function searchTruckByConditions() {
	    if(!$this->isPostRequest()) exit;

	    $post = $_POST;
	    $res = array();
	    $res["title"] = "Truck";
	    $res["message"] = "NOT FOUND";

	    $conditions[] = "TblMstepTruck.del_flg = 0";

// 	    if (isset($post["search_name"]) && $post["search_name"] != null) {
// 	        array_push($conditions, " TblMstepTruck.name  LIKE '%" . $post['search_name'] . "%'");
// 	    }

// 	    if (isset($post["search_remarks"]) && $post["search_remarks"] != null) {
// 	        array_push($conditions, " TblMstepTruck.remarks  LIKE '%" . $post['search_remarks'] . "%'");
// 	    }

        if (isset($post["search_keyword"]) && $post["search_keyword"] != null) {
            $key_word = "(";
            $key_word .= "TblMstepTruck.name LIKE '%" . $post['search_keyword'] . "%'";
            $key_word .= "OR TblMstepTruck.remarks LIKE '%" . $post['search_keyword'] . "%'";
            $key_word .= ")";
            array_push($conditions, $key_word);
        }

	    if (!$trucks = $this->TblMstepTruck->findAll($conditions)) {

	        Output::__outputStatus(11);
	    }

	    Output::__outputYes($trucks);
	}

	/**
	 * delete truck
	 *
	 * @param null
	 *
	 * @return null
	 */
	function deleteTruck() {
	    if(!$this->isPostRequest()) exit;

	    $truck_id = $_POST["truck_id"];
	    if (!$this->TblMstepTruck->findByIdAndDelFlg($truck_id, 0)) {

	        Output::__outputStatus(1);
	    }

	    $datasource = $this->TblMstepTruck->getDataSource();
	    $datasource->begin();

	    // update del_flg
	    $save = array();
	    $save["id"] = $truck_id;
	    $save["del_flg"] = 1;
	    if (!$this->TblMstepTruck->save($save)) {

	        Output::__outputStatus(5);
	    }

	    // delete truck
	    $res = $this->__deleteScheduleTruckByTruckId($truck_id);
	    if (!$res["status"]) {

	        Output::__outputStatus(1);
	    }

	    $datasource->commit();
	    Output::__outputYes();
	}

	function __deleteScheduleTruckByTruckId($truck_id) {

	    try {

	        $this->TblMstepScheduleTruck->updateAll(array("del_flg" => 1), array("truck_id" => $truck_id));

	    } catch (Exception $e) {

	        $res["message"] = $e->getMessage();
	        $res["status"] = false;
	        return $res;
	    }

	    $res["status"] = true;
	    return $res;

	}

	/**
	 * Create new truck
	 *
	 * @param null;
	 * @return array();
	 */
	public function add() {

	}

	/**
	 * save data into database
	 */
	public function save() {

		if(!$this->isPostRequest()) exit;

	     $post = $_POST;
	     $data = [];
	     $data['name'] =   $post['truck_name'];
	     $data['remarks'] =    $post['truck_remarks'];

	     $this->TblMstepTruck->create();

	     if (!$this->TblMstepTruck->save($data)) {

				Output::__outputStatus(5);
	     }

		 Output::__outputYes();
	}

	/**
	 * Edit truck
	 *
	 * @param null;
	 * @return array();
	 */
	public function edit($id = null) {

	    $_truck = $this->TblMstepTruck->findAllByIdAndDelFlg($id, 0);

	    if (!is_numeric($id) || !$_truck) {
	        throw new NotFoundException();
	    }
	    $truck = $_truck[0];

	    $this->set(compact('truck'));
	}

	/**
	 * save data into database when edit truck
	 */
	public function saveEdit() {

		if(!$this->isPostRequest()) exit;

	     $post = $_POST;
	     $_truck = $this->TblMstepTruck->findAllByIdAndDelFlg($post["truck_id"], 0);
	     if(!$_truck){

		 		Output::__outputStatus(1);
	     }

	     $data = [];
	     $data['name'] =    $post['truck_name'];
	     $data['remarks'] = $post['truck_remarks'];

	     $this->TblMstepTruck->id = $post["truck_id"];

	     if (!$this->TblMstepTruck->save($data)) {

				Output::__outputStatus(5);
	     }

		 Output::__outputYes();
	}
}
