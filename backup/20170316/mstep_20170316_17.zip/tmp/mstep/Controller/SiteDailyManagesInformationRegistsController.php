<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";
require_once "Schedule".DS."ScheduleNinku.php";
require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";

App::uses('ScheduleBaseController','Controller');
class SiteDailyManagesInformationRegistsController extends ScheduleBaseController{

        var $name = "SiteDailyManagesInformationRegists";
		var $allScheduleDetails=array();
		var $sendInformations=array();
        var $uses = [

				"TblMstepGroupWorker",
				"TblMstepWorker",
				"TblMstepSiteSchedule",
				"TblMstepSiteWorker",
				"TblMstepScheduleTruck",
				"TblMstepSiteDetail",
				"TblMstepAreaInformation",
				"TblMstepScheduleTruck",
				"TblMstepSiteScheduleRemark",
				"TblMstepMasterUser"
        ];

        function beforeFilter(){

                parent::beforeFilter();

				$this->__init();
        }

		function __init(){

				if(!defined("SCHEDULE_TYPE_NORMAL"))  define("SCHEDULE_TYPE_NORMAL","NORMAL");
				if(!defined("SCHEDULE_TYPE_VISIBLE")) define("SCHEDULE_TYPE_VISIBLE","VISIBLE");
				if(!defined("SCHEDULE_TYPE_REMOVE"))  define("SCHEDULE_TYPE_REMOVE","REMOVE");
		}

		function __setInformations($informations=array()){

				$this->sendInformations=$informations;
		}

		function __setSchedules($schedule_ids=array()){

				$this->TblMstepSiteSchedule->unbindFully();
				$all_schedules=$this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_ids,0);
				$this->allScheduleDetails=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule");
		}

		function __deleteBySiteId(Model $model,$conditions=array()){

				$model->unbindFully();
				$conditions["del_flg"]=0;
				$model->updateAll(array("del_flg"=>1),$conditions);
		}

		function informationsRegist(){

				if(!$this->isPostRequest()) exit;

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
	
				$user_id     =$post["user_id"];
				$local_time_key=isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;

				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				$site_id     =$post["site_id"];
				$schedule_id =isset($post["schedule_id"])?$post["schedule_id"]:false;
				$informations=$post["informations"];
				$start_date  =$post["date"]["start_date"];
				$end_date    =$post["date"]["end_date"];
				$all_schedule_ids=array_keys($informations);

				//set schedules.
				$this->__setSchedules($all_schedule_ids);
				$this->__setInformations($informations);

				$worker_id_histories=$this->__workerRegistedIdHistory($all_schedule_ids);
				$truck_id_histories=$this->__truckRegistedIdHistory($all_schedule_ids);
	            $datasource=$this->TblMstepSiteWorker->getDataSource();
	            $datasource->begin();

				$res=$this->TblMstepSiteWorker->deleteSiteWorkerBySiteID($site_id);
				if(empty($res["status"])) Output::__outputNo(1);

				$site_worker_inserts=$this->__insertWorkerArray(array(
				
						"id_histories"=>$worker_id_histories,
						"site_id"     =>$site_id
				));

				// truck.
				$conditions=array("site_id"=>$site_id);
				if(!empty($schedule_id)) $conditions["schedule_id"]=$schedule_id;
				$this->__deleteBySiteId($this->TblMstepScheduleTruck,$conditions);
				$site_truck_inserts=$this->__insertTruckArray(array(
				
						"id_histories"=>$truck_id_histories,
						"site_id"     =>$site_id
				));

				//color. remarks. primary key is schedule_id.
				$site_color_inserts =$this->__insertColorArray();
				$site_remark_inserts=$this->__insertRemarkArray();

				$res["status"]=true;
				if(!empty($site_worker_inserts)) $res=$this->__multiInsert($this->TblMstepSiteWorker,$site_worker_inserts);
				if(empty($res["status"])) Output::__outputNo(1);

				$res["status"]=true;
				if(!empty($site_truck_inserts)) $res=$this->__multiInsert($this->TblMstepScheduleTruck,$site_truck_inserts);
				if(empty($res["status"])) Output::__outputNo(1);

				$res["status"]=true;
				if(!empty($site_color_inserts)) $res=$this->__multiInsert($this->TblMstepSiteSchedule,$site_color_inserts);
				if(empty($res["status"])) Output::__outputNo(1);

				$res["status"]=true;
				if(!empty($site_remark_inserts)) $res=$this->__updateRemarks($site_remark_inserts);
				if(empty($res["status"])) Output::__outputNo(1);

				//ninku
				$this->__refreshNinku();

				$datasource->commit();

				$ninku_situations=$this->__getSiteNinkuSituations(array($site_id));

				// edit information.
				$edit_detail[$site_id]=array("edit_user_id"=>$user_id,"modified"=>date("Y/m/d H:i:s"));
				$instance=new ScheduleGetLastEditSiteUser($this);
				$instance->setSiteInformations($edit_detail);
				$edit_informations=$instance->getEditUsersInformations();

				$last_edit_time=$this->__getRefreshLastEditTime();

				$informations=$this->__getDateRange($start_date,$end_date);
				$output["informations"]=$informations;
				$output["ninku_situations"]=$ninku_situations;
				$output["edit_information"]=$edit_informations;
				$output["last_edit_time"]  =$last_edit_time;
				Output::__outputYes($output);
		}

		function __insertRemarkArray(){

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["remarks"])) continue;
						$remarks=$values["remarks"];

						$inserts[$counter]["schedule_id"]=$schedule_id;
						if(isset($remarks["remarks1"])) $inserts[$counter]["remarks1"]=$remarks["remarks1"];
						if(isset($remarks["remarks2"])) $inserts[$counter]["remarks2"]=$remarks["remarks2"];
						if(isset($remarks["remarks3"])) $inserts[$counter]["remarks3"]=$remarks["remarks3"];
						$counter++;
				}

				return $inserts;
		}

		function __insertColorArray(){

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						$inserts[$counter]["id"]=$schedule_id;
						$inserts[$counter++]["color_id"]=$values["color"];
				}

				return $inserts;
		}

		function __insertTruckArray($params=array()){

				$site_id     =$params["site_id"];
				$id_histories=$params["id_histories"];

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["trucks"])) continue;
						$truck_ids=$values["trucks"];
						foreach($truck_ids as $k=>$truck_id){

								$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$truck_id])?$id_histories[$site_id][$schedule_id][$truck_id]:"");
								$inserts[$counter]["site_id"]=$site_id;
								$inserts[$counter]["schedule_id"]=$schedule_id;
								$inserts[$counter]["del_flg"]=0;
								$inserts[$counter++]["truck_id"]=$truck_id;
						}
				}

				return $inserts;
		}

		function __insertWorkerArray($params=array()){

				$site_id     =$params["site_id"];
				$id_histories=$params["id_histories"];

				$counter=0;
				$inserts=array();
				foreach($this->sendInformations as $schedule_id=>$values){

						if(!isset($values["workers"])) continue;
						$worker_ids=$values["workers"];
						foreach($worker_ids as $k=>$worker_id){

								$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$worker_id])?$id_histories[$site_id][$schedule_id][$worker_id]:"");
								$inserts[$counter]["site_id"]=$site_id;
								$inserts[$counter]["schedule_id"]=$schedule_id;
								$inserts[$counter]["del_flg"]=0;
								$inserts[$counter++]["worker_id"]=$worker_id;
						}
				}

				return $inserts;
		}

		function __truckRegistedIdHistory($schedule_ids=array()){

				App::uses("SiteManagesInformationRegistsController","Controller");
				$controller=new SiteManagesInformationRegistsController();
				$res=$controller->__truckRegistedIdHistory($schedule_ids);
				return $res;
		}

		function __workerRegistedIdHistory($schedule_ids=array()){

				App::uses("SiteManagesInformationRegistsController","Controller");
				$controller=new SiteManagesInformationRegistsController();
				$res=$controller->__workerRegistedIdHistory($schedule_ids);
				return $res;
		}

		function __getDateRange($start,$end){

				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getDateRange($start,$end,$worker_id);
				return $res;
		}

		function __refreshNinku(){

				$dates=array_map(function($a){

						$m=$a["start_month_prefix"];
						$d=sprintf("%02d",$a["start_day"]);
						
						return "{$m}{$d}";

				},$this->allScheduleDetails);

				$res["status"]=true;
				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($dates);
				if(empty($inserts)) return $res;
				return $this->__multiInsert($this->TblMstepSiteWorker,$inserts);
		}

		function __getSiteNinkuSituations($site_ids=array()) {

				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}


}//END class

?>
