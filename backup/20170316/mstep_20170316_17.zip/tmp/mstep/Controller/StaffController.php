<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-01 16:00:45
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2017-02-28 17:11:26
 */

require_once "Schedule".DS."ScheduleNinku.php";

class StaffController extends AppController {

	var $name = 'Staff';
	var $uses = [
			"TblMstepWorker",
			"TblMstepGroupWorker",
			"TblMstepSiteWorker",
			"TblMstepSiteDetail",
			"TblMstepSiteSchedule",
			"TblMstepAreaInformation",
			"TblMstepMasterUser"
	];

	function beforeFilter() {

			parent::beforeFilter();
	}

	/**
	 * Determines if authorized.
	 *
	 * @param      <type>   $user   The user
	 *
	 * @return     boolean  True if authorized, False otherwise.
	 */
	public function isAuthorized($user) {

			// All registered users can view index and search staff
			// if ($this->action === 'index' || $this->action === 'searchWorkerByConditions') return true;

			return parent::isAuthorized($user);
	}

	//show list workers
	public function index() {

			$this->TblMstepWorker->unbindModel(
			array(
					'belongsTo' => array('TblMstepAreaInformation'),
				)
			);

			$this->paginate = array(
					'limit' => 20,
					'conditions' => array('TblMstepWorker.del_flg' => '0'),
					'order' => array(
	            'TblMstepWorker.created' => 'desc'
	        )
			);

			$workers = $this->paginate("TblMstepWorker");
			$groups = $this->getGroupList();

			$this->set(compact('workers', 'groups'));
	}

	//get list workers
	public function getGroupList() {

			$_groups = $this->TblMstepGroupWorker->findAllByDelFlg(0);
			$groups = Set::combine($_groups, "{n}.TblMstepGroupWorker.id", "{n}.TblMstepGroupWorker.name");

			return $groups;
	}

	public function add($worker_id = null) {

			$worker = [];
			if (!empty($worker_id)) {

					if ($_worker = $this->TblMstepWorker->findAllByIdAndDelFlg($worker_id, 0)) $worker = $_worker[0];

					if (!$worker || !is_numeric($worker_id)) throw new NotFoundException();
			}
			$groups = json_encode($this->getGroupList());
			$prefs = json_encode($this->TblMstepAreaInformation->getPref());
			$sexs = json_encode($this->__getSexs());

			$this->set(compact('groups', 'prefs', 'worker', 'sexs'));
	}

	//search worker
	function searchWorkerByConditions() {

			if(!$this->isPostRequest()) exit;

			$post = $_POST;

			$key_word = "(";
			$key_word .= "TblMstepWorker.del_flg = 0";

			if (!empty($post["searchbyfirst_name"])) $key_word .= " AND TblMstepWorker.first_name LIKE '%" . $post['searchbyfirst_name'] . "%'";

			if (!empty($post["searchbylast_name"])) $key_word .= " AND TblMstepWorker.last_name LIKE '%" . $post['searchbylast_name'] . "%'";

			if (!empty($post["searchbygroup_id"])) $key_word .= " AND TblMstepWorker.group_id = " . intval($post['searchbygroup_id']);

			if (!empty($post["searchbynick_name"])) $key_word .= " AND TblMstepWorker.nickname LIKE '%" . $post['searchbynick_name'] . "%'";

			if (!empty($post["searchby_tel"])) $key_word .= " AND TblMstepWorker.tel LIKE '%" . $post['searchby_tel'] . "%'";

			if (!empty($post["searchby_email"])) $key_word .= " AND TblMstepWorker.email LIKE '%" . $post['searchby_email'] . "%'";

			if (!empty($post["searchby_price"])) $key_word .= " AND TblMstepWorker.price = " . floatval($post['searchby_price']);

			$key_word .= ")";

			if (!$workers = $this->TblMstepWorker->findAll($key_word)) Output::__outputStatus(1);

			Output::__outputYes($workers);
	}

	//delete worker
	function deleteWorker() {

			//$log_path=$this->__getLogPath();
			//$post=unserialize(file_get_contents($log_path));
			//$worker_id=$post["worker_id"];

			if(!$this->isPostRequest()) exit;

			$worker_id = $_POST["worker_id"];
			if (!$this->TblMstepWorker->findByIdAndDelFlg($worker_id, 0)) Output::__outputStatus(1);

			$datasource = $this->TblMstepWorker->getDataSource();
			$datasource->begin();

			// delete worker information.
			$currentDate = date("Y-m-d H:i:s");
			$save = array();
			$save["id"] = $worker_id;
			$save["del_date"] = $currentDate;
			$save["del_flg"] = 1;
			if (!$this->TblMstepWorker->save($save)) Output::__outputStatus(5);

			// delete workers.
			if($schedules=$this->__getSiteByWorkerId($worker_id, $currentDate)){

					$schedule_ids=Set::extract($schedules,"{}.TblMstepSiteSchedule.id");
					$res=$this->__deleteSiteWorkersByScheduleID($schedule_ids,$worker_id);
					if(!$res["status"]) Output::__outputStatus(5);

					$refresh_dates=array();
					foreach($schedules as $k=>$v){

							if(1>count($v["TblMstepSiteWorker"])) continue;
							$d=$v["TblMstepSiteSchedule"];
							$ymd=$d["start_month_prefix"].sprintf("%02d",$d["start_day"]);
							if(in_array($ymd,$refresh_dates)) continue;
							$refresh_dates[]=$ymd;
					}

					if(!$this->__refreshNinku($refresh_dates)) Output::__outputStatus(5);
			}

			// delete account.
			$res = $this->__deleteAccount($worker_id);
			if (!$res["status"]) Output::__outputStatus(5);

			$datasource->commit();
			Output::__outputYes();
	}

	//Adds a staff.
	function addStaff() {

			if(!$this->isPostRequest()) exit;

			$post = $_POST;

			//begin transaction
			$datasource = $this->TblMstepWorker->getDataSource();
			$datasource->begin();

			//add worker informations
			$resWorker = array();
			$resWorker['first_name'] = $post['first_name'];
			$resWorker['last_name'] = $post['last_name'];
			$resWorker['nickname'] = ($post['nick_name']) ? $post['nick_name'] : $post['first_name'];
			$resWorker['tel'] = $post['tel'];
			$resWorker['rest_count_flg'] = $post['rest_count_flg'];
			$resWorker['sex'] = $post['staff_sex'];
			$resWorker['email'] = $post['email'];
			$resWorker['price'] = $post['price'];
			$resWorker['group_id'] = $post['group'];
			$resWorker['address'] = $post['staff_address'];
			$resWorker['area_id'] = $post['staff_area'];
			$resWorker['del_flg'] = 0;


			if (empty($post["worker_id"])) {

					//check exists first name and last name
					$resStaff=$this->__checkNameForStaff($post['first_name'], $post['last_name']);
					if(!$resStaff) {

							$res=array();
							$res["name"]=$resStaff;
							Output::__outputYes($res);
					}

					//check exists user_id and email
					$resAcc=$this->__checkUserID($post['login_id'], $post['email']);
					if($resAcc["account"] != true || $resAcc["email"] != true) Output::__outputYes($resAcc);
			}

			if (!empty($post["worker_id"])) {

					//update worker
					$this->TblMstepWorker->id = $post["worker_id"];
			} else {

					//add new worker
					$this->TblMstepWorker->create();
			}

			if(!$this->TblMstepWorker->save($resWorker)) Output::__outputStatus(5);

			$worker_id=$this->TblMstepWorker->getLastInsertID();

			//add user informations
			if (empty($post["worker_id"])) {

					if(!$this->__addUserInformations($post, $worker_id)) Output::__outputStatus(5);
			}else{
			    // Update price for site worker in the future
			    $currentDate = date("Y-m-d H:i:s");
			    $this->__updatePriceByWorkerAndDate($post["worker_id"], $post['price'], $currentDate);
			}

			// end transaction
			$datasource->commit();

			Output::__outputYes();
	}

	function __checkUserID($user_id, $email=null) {

			$res=array();
			$res["account"]=true;
			$res["email"]=true;

			//check account
			if($account = $this->TblMstepMasterUser->findByLoginIdAndDelFlg($user_id, 0)) $res["account"]=false;

			//check email
			if(!empty($email)) {

					if($email = $this->TblMstepMasterUser->findByEmailAndDelFlg($email, 0)) $res["email"]=false;
			}

			return $res;
	}

	function __checkNameForStaff($first_name, $last_name) {

			$res=true;

			//check name for staff
			if($staff = $this->TblMstepWorker->findByFirstNameAndLastNameAndDelFlg($first_name, $last_name, 0)) $res=false;

			return $res;
	}

	//Gets the site by worker identifier.
	function getSiteByWorkerId() {

			if(!$this->isPostRequest()) exit;

			$log_path=$this->__getLogPath();
			$post=unserialize(file_get_contents($log_path));

			//$post=$_POST;
			$worker_id = $post["worker_id"];
			$date=date("Y-m-d H:i:s");
			if(!$schedules=$this->__getSiteByWorkerId($worker_id, $date)) Output::__outputNo();
			Output::__outputYes($schedules);
	}

	function __addStaffInformations($data=array()) {

			try {

					if (!empty($data["worker_id"])) {

							//update worker
							$this->TblMstepWorker->id = $data["worker_id"];
					} else {

							//add new worker
							$this->TblMstepWorker->create();
					}

					$this->TblMstepWorker->save($data);

			} catch (Exception $e) {

					$res["message"] = $e->getMessage();
					$res["status"] = false;
					return $res;
			}

			$res["status"] = true;
			return $res;
	}

	function __addUserInformations($data=array(), $worker_id) {

			$resUser = array();
			$resUser['worker_id'] = $worker_id;
			$resUser['first_name'] = $data['first_name'];
			$resUser['last_name'] = $data['last_name'];
			$resUser['login_id'] = $data['login_id'];
			$resUser['login_pass'] = $data['password'];
			$resUser['email'] = $data['email'];
			$resUser['area_id'] = $data['staff_area'];
			$resUser['address'] = $data['staff_address'];
			$resUser['authority'] = "normal";
			$resUser['group_id'] = $data['group'];
			$resUser['del_flg'] = 0;

			try {

					$this->TblMstepMasterUser->create();
					$this->TblMstepMasterUser->save($resUser);
			} catch (Exception $e) {

					$res["message"] = $e->getMessage();
					$res["status"] = false;
					return $res;
			}

			$res["status"] = true;
			return $res;
	}

	function __deleteSiteWorkersByScheduleID($schedule_ids,$worker_id){

			try {

					$update=array("TblMstepSiteWorker.del_flg"=>1);
					$conditions=array("TblMstepSiteWorker.worker_id"=>$worker_id,"TblMstepSiteWorker.schedule_id"=>$schedule_ids);
					$this->TblMstepSiteWorker->updateAll($update,$conditions);

			}catch(Exception $e){

					$res["message"]=$e->getMessage();
					$res["status"] =false;
			}

			$res["status"]=true;
			return $res;
	}

	function __deleteSiteWorkersByWorkerId($worker_id=null,$currentDate) {

			if(!$schedules=$this->__getSiteByWorkerId($worker_id,$currentDate)){

					$res["status"]=true;
					return $res;
			}

			$schedule_ids=Set::extract($schedules,"{}.TblMstepSiteSchedule.id");
			return $this->__deleteSiteWorkersByScheduleID($schedule_ids,$worker_id);
	}

	function __deleteAccount($worker_id=null) {

		try{

				$this->TblMstepMasterUser->updateAll(array("del_flg" => 1), array("TblMstepMasterUser.worker_id" => $worker_id));

		}catch(Exception $e){

				$res["message"]=$e->getMessage();
				$res["status"] =false;
				return $res;
		}

		$res["status"]=true;
		return $res;
	}

	function __getSiteByWorkerId($worker_id=array(), $currentDay=array()) {

			$schedules=array();

			$schedule_sites = $this->TblMstepSiteWorker->findAllByWorkerIdAndDelFlg($worker_id, 0);

			if(!empty($schedule_sites)) {

				$schedule_ids = Set::combine($schedule_sites, "{n}.TblMstepSiteWorker.id", "{n}.TblMstepSiteWorker.schedule_id");
				$schedule_ids = array_unique($schedule_ids);
				$conditions[] = "TblMstepSiteSchedule.start_date >= " . "'" . $currentDay . "'" . " AND TblMstepSiteSchedule.del_flg = 0 ";
				array_push($conditions, "TblMstepSiteSchedule.id IN ( " . implode(", ", array_values($schedule_ids)) . " )");
				$schedules = $this->TblMstepSiteSchedule->findAll($conditions);
			}

			return $schedules;
	}

	function __getSexs() {

	    $sexs = [];
	    $table = 'tbl_mstep_workers';
	    $field = 'sex';
	    $_type = $this->TblMstepWorker->query( "SHOW COLUMNS FROM {$table} WHERE Field = '{$field}'" );
	    $type = $_type[0]['COLUMNS']['Type'];
	    preg_match("/^enum\(\'(.*)\'\)$/", $type, $matches);
	    $__sexs = explode("','", $matches[1]);

	    foreach($__sexs as $sex){
	        $sexs[$sex] = __($sex);
	    }

	    return $sexs;
	}

	function __refreshNinku($dates){

			$res["status"]=true;
			$instance=new ScheduleNinku($this);
			$inserts=$instance->getNinkInsertAry($dates);
			if(empty($inserts)) return $res;
			return $this->__multiInsert($this->TblMstepSiteWorker,$inserts);
	}
	
	function __updatePriceByWorkerAndDate($worker_id, $price, $date){
	    $this->TblMstepSiteWorker->unbindModel(
			array(
				'belongsTo' => array(
					'TblMstepSiteScheduleRemark',
			        'TblMstepWorker',
			        'TblMstepSiteDetail'
				)
		));
	    
	    $site_workers = $this->TblMstepSiteWorker->find('all', array(
	            'conditions' => array(
	                    'TblMstepSiteWorker.worker_id' => $worker_id,
	                    'TblMstepSiteSchedule.start_date >=' => $date
	            ),
	            'fields' => array(
	                    'TblMstepSiteWorker.id'
	            )
	    ));
	    if($site_workers){
	        $site_worker_ids = Set::classicExtract($site_workers, '{n}.TblMstepSiteWorker.id');
	        $this->TblMstepSiteWorker->updateAll(array('price' => $price), array("TblMstepSiteWorker.id IN" => $site_worker_ids));
	    }
	}
}
