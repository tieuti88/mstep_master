/***********API送信************/
var apiGeoRequests=function(){

		this.basePhpExecFile='';
}

apiGeoRequests.prototype.setBaseURL=function(url){

		this.basePhpExecFile=url;
}

apiGeoRequests.prototype.setURL=function(url){

		this.requestURL=(this.basePhpExecFile+url);
}

apiGeoRequests.prototype.request=function(data,params,callback){

		var __params = {

				url     :this.requestURL,
				async   :true,
				data    :data,
				type    :"POST",
				cache   :false,
				dataType:"json",
				error   :function(){

						var ary = Array.prototype.slice.call(arguments);
console.log(ary);
						ary.unshift(false);
						callback.apply(this,ary);
				},
				success :function(){

						var ary = Array.prototype.slice.call(arguments);
console.log(ary);
						ary.unshift(true);
						callback.apply(this, ary);
						return false;
				}
		};

		$.extend(__params,(!params?{}:params));
console.log(__params);
		return $.ajax(__params);
}
