<?php
/**
 * Application model for CakePHP.
 *
 * This file is application-wide model file. You can put all
 * application-wide model-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Model
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepCustomer extends AppModel {

	var $name = "TblMstepCustomer";
	var $useTable = "tbl_mstep_customers";
	var $primaryKey = "id";

	public $hasMany = array(
		'TblMstepSiteDetail' => array(
			'className' => 'TblMstepSiteDetail',
			'foreignKey' => 'customer_id',
			'conditions' => array('TblMstepSiteDetail.del_flg' => '0'),
			'order' => 'TblMstepSiteDetail.id DESC',
			'dependent' => true,
		),
        'TblMstepCustomerInchargeUser' => array(
                'className' => 'TblMstepCustomerInchargeUser',
                'foreignKey' => 'customer_id',
                'conditions' => array('TblMstepCustomerInchargeUser.del_flg' => '0'),
        )
	);

	// Update 2016.11.22 Hung Nguyen start
	public $belongsTo = array(
	        'TblMstepMasterUser' => array(
	                'className' => 'TblMstepMasterUser',
	                'foreignKey' => 'inchage_office_userid',
	                'conditions' => array('TblMstepMasterUser.del_flg' => '0'),
	        ),
// 	        'TblMstepCustomerInchargeUser' => array(
// 	                'className' => 'TblMstepCustomerInchargeUser',
// 	                'foreignKey' => 'incharge_customer_userid',
// 	                'conditions' => array('TblMstepCustomerInchargeUser.del_flg' => '0'),
// 	        )
	);

	function getCustomers($customer_ids=array(),$f=array()){

			$w=null;
			if(!empty($customer_ids)) $w["and"]["{$this->name}.id"]=$customer_ids;
			$w["and"]["{$this->name}.del_flg"]=0;
			return $this->findAll($w,$f);
	}

		function getCustomerInfomration($customer_ids=array(),$f=array()){

				$current_recursive=$this->recursive;
				$this->recursive=-1;
				$customer_information=$this->findAllByIdAndDelFlg($customer_ids,0,$f);
				$this->recursive=$current_recursive;
				return $customer_information;
		}


}
