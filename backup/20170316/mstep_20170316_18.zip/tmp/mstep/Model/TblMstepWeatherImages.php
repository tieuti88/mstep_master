<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-08-24 15:10:59
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-09-19 11:12:13
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepWeatherImages extends AppModel{

    var $name = "TblMstepWeatherImages";
    var $useTable = "tbl_mstep_weather_images";
    var $primaryKey = "id";
	var $useDbConfig="master";

    public $hasMany = array(
        'TblMstepWeatherInformations' => array(
            'className' => 'TblMstepWeatherInformations',
            'foreignKey' => 'img_id',
            'conditions' => array('TblMstepWeatherInformations.del_flg' => '0'),
            'order' => 'TblMstepWeatherInformations.id DESC',
            'dependent' => true
        )
    );

    /**
     * Gets weather images
     *
     * @param      null
     * @return     Images list.
     */
    function getWeatherImages(){

        $datas = $this->findAll();
        $result=array();
        foreach ($datas as $k => $v) {
            $result[$v["TblMstepWeatherImages"]["id"]]=$v["TblMstepWeatherImages"]["name"];
        }

        return $result;
    }

    /**
     * Gets weather image name
     *
     * @param      null
     * @return     image name.
     */
    function getWeatherImagesName($img_id){

        $w=null;
        $w["and"]["id"] = $img_id;
        $data = $this->findOne($w, 'image');

        return $data["TblMstepWeatherImages"]["image"];
    }
}
