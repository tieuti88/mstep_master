<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

class SiteManagesWorkerController extends AppController{

        var $name = "SiteManagesWorker";
        var $uses = [

				"TblMstepSiteDetail",
            	"TblMstepWorker",
            	"TblMstepGroupWorker",
				"TblMstepSiteSchedule",
				"TblMstepSiteWorker",
				"TblMstepWorker",
				"TblMstepGroupWorker"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->isAuthorized();
				$this->__init();
        }

		function __init(){

		}

		function __findAllSiteWorkers($params=array()){

				$w=null;
				$this->TblMstepSiteWorker->unbindFully();
				if(!empty($params["schedule_id"])) $w["and"]["TblMstepSiteWorker.schedule_id"]=$params["schedule_id"];
				$w["and"]["TblMstepSiteWorker.site_id"]=$params["site_id"];
				$w["and"]["TblMstepSiteWorker.del_flg"]=0;
				return $this->TblMstepSiteWorker->findAll($w);
		}

		function __workerInserts($workers=array(),$params=array()){

				$registed_ids=$params["registed_ids"];
				$site_id=$params["site_id"];

				$count=0;
				$inserts=array();
				foreach($workers as $schedule_id=>$worker_ids){

						foreach($worker_ids as $k=>$worker_id){

								// def.
								$id=(isset($registed_ids[$schedule_id][$worker_id])?$registed_ids[$schedule_id][$worker_id]["id"]:"");

								$inserts[$count]["id"]         =$id;
								$inserts[$count]["del_flg"]    =0;
								$inserts[$count]["site_id"]    =$site_id;
								$inserts[$count]["schedule_id"]=$schedule_id;
								$inserts[$count++]["worker_id"]  =$worker_id;
						}
				}

				try{

						$this->TblMstepSiteWorker->multiInsert($inserts);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __removeWorkers($params=array()){

				$site_id     =$params["site_id"];
				$schedule_ids=$params["schedule_id"];
				$table=$this->TblMstepSiteWorker->useTable;
				$query="update {$table} set del_flg=1 where site_id=\"{$site_id}\"";
				if(!empty($schedule_ids)) $query.=" AND schedule_id IN(".implode(",",$schedule_ids).")";
				$query.=";";

				try{
						$this->TblMstepSiteWorker->query($query);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getInformations($start,$end);
				return $res;
		}

}//END class

?>
