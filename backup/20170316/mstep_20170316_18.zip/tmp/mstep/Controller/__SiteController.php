<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteController extends AppController{
        var $name = "Site";
        var $uses = [
                "TblMstepSiteDetail",
                "TblMstepSiteSchedule",
                "TblMstepSiteWorker",
                "TblMstepWorker",
                "TblMstepAreaInformation",
                "TblMstepCustomer",
                "TblMstepTruck",
                "TblMstepScheduleTruck",
                "TblMstepCustomerInchargeUser",
                "TblMstepWeatherWeeklyReports",
                "TblMstepWeatherInformations",
                "TblMstepWeatherImages",
                "User"
        ];

        function beforeFilter(){

                parent::beforeFilter();

        }

        #
        # @author Akabane
        # @date 2011/05/07 14:44:59
        function beforeRender(){

        }

        function index(){

                #■前後１ヶ月のデータ
                $start=date("Y-m-d",strtotime("-1 month",time()));
                $end=date("Y-m-d",strtotime("+1 month",time()));

                $data=$this->__getInformations($start,$end);
                $informations=$data["informations"];
                $weather=$data["weather"];
                $last_modified_ms=$data["last_modified_ms"];

                $informations=json_encode($informations);
                $weather=json_encode($weather);
                $this->set(compact("informations","last_modified_ms"));
        }

        function __makeDatePeriod($start,$end){

                $diff=(strtotime($end)-strtotime($start))/(60*60*24);
                for($i=0;$i<=$diff;$i++) $period[date("Ymd",strtotime($start."+".$i."days"))]=array();
                return $period;
        }

        function __getWorkerSchedules($data){

                $res=array();
                foreach($data as $k=>$v){

                        $__data=$v["TblMstepSiteWorker"];
                        $res[$__data["site_id"]][$__data["schedule_id"]][]=$__data["worker_id"];
                }

                return $res;
        }

        // i'm sorry tooooo looooong!!!
        function __getInformations($start,$end){

                $informations=$this->__makeDatePeriod($start,$end);

                //■initialize response data.
                $res["informations"]=array();
                $res["weather"] = array();
                $res["last_modified_ms"]="";

                //■some schuedule by some day
                $all_target_days=array_keys($informations);
                if(!$work_schedules=$this->TblMstepSiteSchedule->getTargetByDate($all_target_days)) return $res;

                //■work details
                $all_site_start_dates=Set::combine($work_schedules,"{n}.TblMstepSiteSchedule.site_id","{n}.TblMstepSiteSchedule.start_date");
                $site_ids=array_keys($all_site_start_dates);
                $work_details=$this->TblMstepSiteDetail->findAllByIdAndDelFlg($site_ids,0);
                $work_details=$this->__arrangeAry($work_details,$this->TblMstepSiteDetail->primaryKey);

                //■customer
                $customer_ids=Set::extract($work_details,"{}.customer_id");
                $customer_information=$this->TblMstepCustomer->findAllByIdAndDelFlg($customer_ids,0);
                $customer_information=$this->__arrangeAry($customer_information,$this->TblMstepCustomer->primaryKey);

                //■in charge from customer
                $incharge_customer_userids=Set::extract($customer_information,"{}.incharge_customer_userid");
                $incharge_customer_users=$this->TblMstepCustomerInchargeUser->findAllByIdAndDelFlg($incharge_customer_userids,0);
                $incharge_customer_users=$this->__arrangeAry($incharge_customer_users,$this->TblMstepCustomerInchargeUser->primaryKey);

                //■work area
                $area_ids=Set::extract($work_details,"{}.area_id");
                $work_areas=$this->TblMstepAreaInformation->findAllById($area_ids);
                $work_areas=$this->__arrangeAry($work_areas,$this->TblMstepAreaInformation->primaryKey);

                //■worker
                $schedule_ids=Set::extract($work_schedules,"{}.TblMstepSiteSchedule.id");
                $site_workers=$this->TblMstepSiteWorker->findAllBySiteIdAndScheduleIdAndDelFlg($site_ids,$schedule_ids,0);
                $site_worker_ids=array_unique(Set::extract($site_workers,"{}.TblMstepSiteWorker.worker_id"));
                $site_worker_schedules=$this->__getWorkerSchedules($site_workers);

                //■numbar of truck already reserved.
                $truck_schedules=$this->__truckInformations($schedule_ids);
                // $trucks=$this->TblMstepScheduleTruck->getTrucksNum($schedule_ids);

                //■Truck information
                $trucks=$this->TblMstepTruck->findAllByDelFlg(0);
                $trucks=Set::combine($trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck.name");

                //■worker(parson)
                $workers=$this->TblMstepWorker->findAllByIdAndDelFlg($site_worker_ids,0);
                $workers=$this->__arrangeAry($workers,$this->TblMstepWorker->primaryKey);

                //■get last modified in thise data.
                //■when the schedule will be saved,this server receive this data to check if another parson is saved the schedule before.
                $last_modified="";

                foreach($work_schedules as $k=>$v){

                        $site_id=$v["TblMstepSiteSchedule"]["site_id"];
                        $schedule_id=$v["TblMstepSiteSchedule"]["id"];
                        $date=date("Ymd",strtotime($v["TblMstepSiteSchedule"]["start_date"]));
                        if(!isset($informations[$date])) $informations[$date]=array();

                        $count=count($informations[$date]);

                        //■edit last modified.
                        $last_modified=max($last_modified,$v["TblMstepSiteSchedule"]["modified"]);

                        //■schedule
                        $informations[$date][$count]["schedule"]["id"]           =$schedule_id;
                        $informations[$date][$count]["schedule"]["start_date_ms"]=(strtotime($v["TblMstepSiteSchedule"]["start_date"])*1000);
                        $informations[$date][$count]["schedule"]["end_date_ms"]  =(strtotime($v["TblMstepSiteSchedule"]["end_date"])*1000);

                        //■site
                        $informations[$date][$count]["site_detail"]["name"]     =$work_details[$site_id]["name"];
                        $informations[$date][$count]["site_detail"]["power_num"]=$work_details[$site_id]["power_num"];
                        $informations[$date][$count]["site_detail"]["color"]    =$work_details[$site_id]["color"];
                        $informations[$date][$count]["site_detail"]["remarks"]  =$work_details[$site_id]["remarks"];
                        $informations[$date][$count]["site_detail"]["id"]       =$site_id;

                        //■location
                        $informations[$date][$count]["location"]["pref"]   =$work_areas[$work_details[$site_id]["area_id"]]["pref"];
                        $informations[$date][$count]["location"]["town"]   =$work_areas[$work_details[$site_id]["area_id"]]["address1"];
                        $informations[$date][$count]["location"]["address"]=$work_details[$site_id]["address"];

                        //■customer
                        $customer=$customer_information[$work_details[$site_id]["customer_id"]];
                        $informations[$date][$count]["customer"]["name"]   =$customer["name"];
                        $informations[$date][$count]["customer"]["address"]=$customer["address"];
                        $informations[$date][$count]["customer"]["fax"]    =$customer["fax"];

                        //■parson in chage
                        $incharge=$incharge_customer_users[$customer["incharge_customer_userid"]];
                        $informations[$date][$count]["incharge"]["first_name"]=$incharge["first_name"];
                        $informations[$date][$count]["incharge"]["last_name"] =$incharge["last_name"];
                        $informations[$date][$count]["incharge"]["tel"]       =$incharge["tel"];
                        $informations[$date][$count]["incharge"]["email"]     =$incharge["email"];

                        //■number of trucks
                        $informations[$date][$count]["truck"]["needed_num"]  =$work_details[$site_id]["delivery"];
                        $informations[$date][$count]["truck"]["reserved"]=array();
                        if(isset($truck_schedules[$schedule_id])){

                                foreach($truck_schedules[$schedule_id] as $id=>$_v){
                                        $__count=count($informations[$date][$count]["truck"]["reserved"]);
                                        $informations[$date][$count]["truck"]["reserved"][$__count]["id"]=$id;
                                        $informations[$date][$count]["truck"]["reserved"][$__count]["truck_id"]=$_v["truck_id"];
                                        $informations[$date][$count]["truck"]["reserved"][$__count]["name"]=$trucks[$_v["truck_id"]];
                                }
                        }

                        //■worker
                        $informations[$date][$count]["worker"]   =array();
                        $worker_ids=$site_worker_schedules[$site_id][$v["TblMstepSiteSchedule"]["id"]];
                        if(1>count($worker_ids)) continue;
                        foreach($worker_ids as $k=>$worker_id){

                                $informations[$date][$count]["worker"][$k]["id"]        =$worker_id;
                                $informations[$date][$count]["worker"][$k]["first_name"]=$workers[$worker_id]["first_name"];
                                $informations[$date][$count]["worker"][$k]["last_name"] =$workers[$worker_id]["last_name"];
                                $informations[$date][$count]["worker"][$k]["sex"]       =$workers[$worker_id]["sex"];
                                $informations[$date][$count]["worker"][$k]["tel"]       =$workers[$worker_id]["tel"];
                                $informations[$date][$count]["worker"][$k]["email"]     =$workers[$worker_id]["email"];
                                $informations[$date][$count]["worker"][$k]["address"]   =$workers[$worker_id]["address"];
                                $informations[$date][$count]["worker"][$k]["price"]     =$workers[$worker_id]["price"];
                        }
                }

                $res=array();
                $res["informations"]=$informations;
                $res["last_modified_ms"]=(strtotime($last_modified)*1000);

                //■weather detail
                $res["weather"] = $this->getImageByWeatherDate($this->Auth->user('pref_id'));

                return $res;
        }

        function __truckInformations($schedule_ids=array()){

                if(!$data=$this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();

                $res=array();
                foreach($data as $k=>$v){

                        $_v=$v["TblMstepScheduleTruck"];
                        $res[$_v["schedule_id"]][$_v["id"]]["truck_id"]=$_v["truck_id"];
                        $res[$_v["schedule_id"]][$_v["id"]]["remarks"]=$_v["remarks"];
                }
                return $res;
        }

        function __getWeekFromToday(){

                $start=date("Y-m-d");
                $end=date("Y-m-d",strtotime("+6 day",time()));
                $period=$this->__makeDatePeriod($start,$end);
                return array_keys($period);
        }

        function getAddDateApi(){

                //■基準日,何ヶ月分
                $post=$_POST;
                //$post["date"]="2016-09-01";
                $date =isset($post["date"]) ?$post["date"] :date("Ymd");
                $month=isset($post["month"])?$post["month"]:"1";

                $start=date("Y-m-d",strtotime($date));
                $end=date("Y-m-d",strtotime("+ {$month} month",strtotime($date)));

                $data=$this->__getInformations($start,$end);
                $informations =$data["informations"];
                $last_modified_ms=$data["last_modified_ms"];

                if(empty($informations)) $informations=$this->__makeDatePeriod($start,$end);

                $res["data"]["informations"] =$informations;
                $res["data"]["last_modified"]=$last_modified_ms;
                $res["status"]="YES";
                $this->__output($res);
        }

        function getSubDateApi(){

                //■基準日,何ヶ月分
                $post=$_POST;
                $date =isset($post["date"]) ?$post["date"] :date("Ymd");
                $month=isset($post["month"])?$post["month"]:"1";

                $end=date("Y-m-d",strtotime($date));
                $start=date("Y-m-d",strtotime("- {$month} month",strtotime($date)));

                $data=$this->__getInformations($start,$end);
                $informations =$data["informations"];
                $last_modified_ms=$data["last_modified_ms"];
                if(empty($informations)) $informations=$this->__makeDatePeriod($start,$end);

                $res["data"]["informations"] =$informations;
                $res["data"]["last_modified_ms"]=$last_modified_ms;
                $res["status"]="YES";
                $this->__output($res);
        }

        function getImageByWeatherDate($user_pref_id) {

            $results = array();
            $weather_id = $this->TblMstepWeatherWeeklyReports->getWeatherIdByPrefId($user_pref_id);
            $weather_data = $this->TblMstepWeatherInformations->findAllByReportId($weather_id);
            $results = Set::combine($weather_data,"{n}.TblMstepWeatherInformations.date","{n}.TblMstepWeatherImages.image");

            return $results;
        }

}//END class

?>
