<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";
require_once "Schedule".DS."ScheduleLog.php";

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

class SiteDailyController extends AppController{

        var $name = "SiteDaily";
		var $uses = [
		
				"TblMstepAreaInformation",
				"TblMstepSiteDetail",
				"TblMstepWorker"
		];
	
	public function isAuthorized($user) {
		
		// All registered users can view index and search staff
//		return true;
		//if (in_array($this->action, array('index'))) {return true;}
		
		//return parent::isAuthorized($user);
		return true;
	}

        function beforeFilter(){

                parent::beforeFilter();

				// base informations.
				$firstname=$this->Auth->user("first_name");
				$this->set(compact("firstname"));
				$this->__init();
        }

		function __init(){

				$this->unbindFully();
		}

   		function __startDateArgesValidate($start_date){

                if(!$start_date || strlen($start_date)!=8 || !is_numeric($start_date)) return false;
                $year =substr($start_date,0,4);
                $month=substr($start_date,4,2);
                $day=substr($start_date,6,2);
                if(!checkDate($month,$day,$year)) return false;
                return true;
        }

		function index($start_date=""){

				if(!$this->__startDateArgesValidate($start_date)) $start_date=date("Ymd");

				$user_id  =$this->Auth->user("id");
				$pref_id  =$this->Auth->user('pref_id');

				$start_ym=date("Ym",strtotime($start_date));
				$period=$this->__getPeriod($start_ym,1);
				$start_date_first=$period[0]."01";
				$start_date_last=date("Ymt",strtotime($start_date_first));

				$data=$this->__getInformations($start_date_first,$start_date_last);
				$informations=$data["informations"];
				$site_ids=$data["data"]["site_ids"];

				$edit_informations=$this->getLastEditUsers();

				$site_ids=array();
				if(!empty($informations)) $site_ids=array_values(array_unique(array_filter(Set::classicExtract($informations,"{[a-zA-Z0-9-_.]}.0.site_detail.id"),"strlen")));
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$weather=$this->__getImageByWeatherDate($pref_id);

				//remark title
				$remark_titles=$this->__getRemarkTitles();

		        //prefs
				$tsv=new TSV();
				$prefs=$tsv->getTSV("pref");

				//color
				$color_list=$this->__getColorList(false);

				$instance=ScheduleLog::getInstance($this);
				$last_edit_time =$instance->getLastEditTime();
				$last_start_user=$instance->getLastStartUser();
				$edit_time_expired_ms=$instance->getLastEditTimeExpireMs();
				$last_edit_user_id=$instance->getLastEditUser();

				//■user edited last imformation.
				$last_modified_user=array();
				if(!empty($last_edit_user_id)){ 

						$last_modified_user=$this->__getLastModifiedInformations($last_edit_user_id);
						$last_modified_user["last_edit_ms"]=$last_edit_time;
						$last_modified_user["edit_time_expired"]=$edit_time_expired_ms;
				}

				//memo.
				$memos=$this->__getMemoList();

				//worker count
				$worker_count=$this->TblMstepWorker->getRestWorkerCount();

				$user_id=$this->Auth->user("id");
				$is_authority=$this->__checkAuthorityToEdit($user_id)?1:0;

				$memos        =mstepJsonEncode($memos);
				$weather      =mstepJsonEncode($weather);
				$remark_titles=mstepJsonEncode($remark_titles);
				$edit_informations=mstepJsonEncode($edit_informations);
				$informations =mstepJsonEncode($informations);
				$last_modified_user=mstepJsonEncode($last_modified_user);
				$prefs        =mstepJsonEncode($prefs);
				$color_list   =mstepJsonEncode($color_list);
				$ninku_situations=mstepJsonEncode($ninku_situations);

				$start_date_ms=strtotime($start_date)*1000;
				$this->set(compact("remark_titles",
								   "informations",
								   "start_date_ms",
								   "is_authority",
								   "edit_informations",
								   "ninku_situations",
								   "worker_count",
								   "last_modified_user",
								   "last_edit_time",
								   "edit_time_expired_ms",
								   "last_start_user",
								   "weather",
								   "prefs",
								   "memos",
								   "color_list",
								   "start_date",
								   "user_id"));
		}

		function getDateApi(){

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				$date=isset($post["date"])?$post["date"]:date("Ymd");
				$start=date("Ym01",strtotime($date));
				$end  =date("Ymt",strtotime($start));

				$worker_id=$this->Auth->user("worker_id");
				$data=$this->__getInformations($start,$end);

				$edit_informations=$this->getLastEditUsers();

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function getDateRange(){

				if(!$this->isPostRequest()) exit;

				$post=$_POST;
				$start=(!isset($post["start"]))?date("Ym01"):$post["start"];
				$end  =(!isset($post["end"]))?date("Ymt",strtotime($start)):$post["end"];
				$informations=$this->__getDateRange($start,$end);

				$res["data"]["informations"]=$informations;
				$res["status"] = "YES";
				Output::__output($res);
		}

        function __getLastModifiedInformations($last_edit_user_id){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getLastModifiedInformations($last_edit_user_id);
				return $res;
        }

		function __getColorList($is_set){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getColorList($is_set);
				return $res;
		}

		function __getRemarkTitles(){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				return $controller->__getRemarkTitles();
		}

        function __getImageByWeatherDate($user_pref_id) {

				App::uses("SiteManagesWeatherController","Controller");
				$controller=new SiteManagesWeatherController();
				$res=$controller->__getImageByWeatherDate($user_pref_id);
				return $res;
        }

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));
				return $res;
		}

		function __getPeriod($date,$range=4,$format="Ym") {

				App::uses("SiteMonthlyController", "Controller");
				$controller = new SiteMonthlyController();
				$res = $controller->__getPeriod($date,$range,$format);
				return $res;
		}

		function __getMemoList() {

				App::uses("SiteManagesMemoController", "Controller");
				$controller = new SiteManagesMemoController();
				$res = $controller->__getMemoList();
				return $res;
		}

		function __getSiteNinkuSituations($site_ids=array()) {

				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __checkAuthorityToEdit($user_id){
	
				$time_key=$this->Session->read(TimeoutInvestigationKeys::makeTimeSesKey(UNIQUE_KEY));
	
				App::uses("SiteManagesEditAuthoritiesController","Controller");
				$controller=new SiteManagesEditAuthoritiesController();
				$is_edit=$controller->__checkAuthorityToEditWithDeadline($user_id,$time_key);
				return $is_edit;
		}

		function __getDateRange($start,$end){

				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getDateRange($start,$end,$worker_id);
				return $res;
		}

		function getLastEditUsers(){
		
				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$instance=ScheduleGetLastEditSiteUser::getInstance($controller);
				$edit_informations=$instance->getEditUsersInformations();
				return $edit_informations;
		}


}//END class

?>
