<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-08-23 16:26:35
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-09-19 11:01:54
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepWeatherInformations extends AppModel{

    var $name = "TblMstepWeatherInformations";
    var $useTable = "tbl_mstep_weather_informations";
    var $primaryKey = "id";
	var $useDbConfig="master";

    public $belongsTo  = array(
        'TblMstepWeatherImages' => array(
            'className' => 'TblMstepWeatherImages',
            'foreignKey' => 'img_id'
        )
    );

}
