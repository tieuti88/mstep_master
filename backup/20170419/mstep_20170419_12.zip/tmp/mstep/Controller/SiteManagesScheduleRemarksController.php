<?php

require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";
require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";

class SiteManagesScheduleRemarksController extends AppController{

        var $name = "SiteManagesScheduleRemarks";

		var $defaultRemarkTitle="備考%s";

		var $titles=array("site"=>array("site_remark1","site_remark2","site_remark3"),
					   	  "schedule"=>array("schedule_remark1","schedule_remark2","schedule_remark3"));

        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepSiteScheduleRemark",
				"TblMstepSiteRemarkTitle",
				"TblMstepSiteSchedule"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				//$this->unbindFully();
		}

		function __saveRemarks($remarks=array()){

				$all_schedule_ids=array_keys($remarks);
				$all_remarks=$this->TblMstepSiteScheduleRemark->findAllByScheduleId($all_schedule_ids);

				$insert=array();
				foreach($remarks as $schedule_id=>$v){

						$count=count($insert);
						foreach($v as $_k=>$_v){

								$index=($_k+1);
								$insert[$count]["remarks{$index}"]=$_v;
						}
						$insert[$count]["schedule_id"]=$schedule_id;
						$count++;
				}

				try{

						$this->TblMstepSiteScheduleRemark->multiInsert($insert);
				
				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __getRemarkTitles(){

				$res=array();
				$remark_title=$this->TblMstepSiteRemarkTitle->findOne();

				$counter=1;
				$def=$this->defaultRemarkTitle;
				foreach($this->titles as $category=>$titles){

						foreach($titles as $k=>$title){

								$__title=isset($remark_title["TblMstepSiteRemarkTitle"][$title])?$remark_title["TblMstepSiteRemarkTitle"][$title]:sprintf($def,($k+1));
								$res[$category][]=$__title;
						}
				}

				return $res;
		}

		function __getRegistedSiteRemarks($schedule_ids=array()){

				if(!$remarks=$this->TblMstepSiteScheduleRemark->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();

				$res=array();
				foreach($remarks as $k=>$v){
				
						$data=$v["TblMstepSiteScheduleRemark"];
						$schedule_id=$data["schedule_id"];
						$res[$schedule_id]["remarks1"]=$data["remarks1"];
						$res[$schedule_id]["remarks2"]=$data["remarks2"];
						$res[$schedule_id]["remarks3"]=$data["remarks3"];
				}

				return $res;
		} 

		function __saveScheduleColor($colors){

				App::uses("SiteManagesColorController","Controller");
				$controller=new SiteManagesColorController();
				$res=$controller->__saveScheduleColor($colors);
				return $res;
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$is_worker_senior=$this->__isWorkerSenior();
				$worker_id=$this->Auth->user("worker_id");
				$controller=new SiteController();
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"       =>$worker_id,
						"is_worker_senior"=>$is_worker_senior
				));
				return $res;
		}

}//END class

?>
