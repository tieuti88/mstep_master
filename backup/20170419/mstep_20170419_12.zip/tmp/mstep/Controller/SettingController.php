<?php
class SettingController extends AppController {
    
    var $uses = [
            'TblMstepGroupWorker',
            'TblMstepSiteRemarkTitle',
            'TblMstepWorker'
    ];
    
    function beforeFilter() {
    
        parent::beforeFilter();
    }
    
    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {
    
        // All registered users can logout
//         if ($this->action === 'index') {
//             return true;
//         }
    
        return parent::isAuthorized($user);
    }
    
	public function index() {
    	if($this->Auth->user("authority") === "master"){
    		    $this->set('is_mater', true);
    	}else{
    	    $this->set('is_mater', false);
    	}
	}

	public function advanced() {
	    $siteRemark = [];
        $_siteRemark = $this->TblMstepSiteRemarkTitle->find('first');
        if(isset($_siteRemark)){
            $siteRemark = $_siteRemark;
        }
        
        $this->TblMstepGroupWorker->unBindFully();
        $_groupWorker = $this->TblMstepGroupWorker->findAllByDelFlg(0);
        $groupWorker = Set::combine($_groupWorker, "{n}.TblMstepGroupWorker.id", "{n}.TblMstepGroupWorker.name");
		$this->__setRemarkDefaultValue($siteRemark["TblMstepSiteRemarkTitle"]);

        $this->set(compact('siteRemark', 'groupWorker'));
	}

	private function __setRemarkDefaultValue(&$remarks){

			$titles=tsv("remark_titles.tsv");

            if(empty($remarks)){

             		$remarks=$titles;
             		return;
            }

			foreach($titles as $k=>$v){

					if(!isset($remarks[$k])){

							$remarks[$k]=$v;
							continue;
					}

					if(!empty($remarks[$k])) continue;
					$remarks[$k]=$v;
			}
	}
	
	public function updateSetting(){

		if(!$this->isPostRequest()) exit;

	    $post = $_POST;
	    $data = [];
	    $data['site_remark1'] = $post['site_remark1'];
	    $data['site_status'] = $post['site_status'];
	    $data['schedule_remark1'] = $post['schedule_remark1'];
	    $data['schedule_remark2'] = $post['schedule_remark2'];
	    $data['schedule_remark3'] = $post['schedule_remark3'];

	    $datasource = $this->TblMstepSiteRemarkTitle->getDataSource();
	    $datasource->begin();
	    
	    $res = $this->TblMstepSiteRemarkTitle->find('first');
	    if(!empty($res)){
	        $this->TblMstepSiteRemarkTitle->id = $res['TblMstepSiteRemarkTitle']['id'];
	    }else{
    	    $this->TblMstepSiteRemarkTitle->create();
	    }
	    $this->TblMstepSiteRemarkTitle->save($data);
	    $res = $this->updateGroupWorker($post);
	    $datasource->commit();
		Output::__outputYes();
	}
	
	function updateGroupWorker($data){
	    if(!empty($data['arrEdit'])){
	        foreach ($data['arrEdit'] as $arrEdit){
	            if($arrEdit['del_flg'] === "true"){
                    $group = [];
                    $group['del_flg'] = 1;
                    $this->TblMstepGroupWorker->id = $arrEdit['id'];
                    if(!$this->TblMstepGroupWorker->save($group)){
                        Output::__outputStatus(5);
                    }
                    $this->updateWorkerHasDelete($arrEdit['id']);
	            }else{
	                $group = [];
	                $group['name'] = $arrEdit['name'];
	                $this->TblMstepGroupWorker->id = $arrEdit['id'];
	                
	                if(!$this->TblMstepGroupWorker->save($group)){
	                    Output::__outputStatus(5);
	                }
	            }
	        }
	    }

	    if(!empty($data['arrAdd'])){
	        foreach ($data['arrAdd'] as $arrAdd){
	            $group = [];
	            $group['name'] = $arrAdd;
	            
	            $this->TblMstepGroupWorker->create();
	            if(!$this->TblMstepGroupWorker->save($group)){
	                Output::__outputStatus(5);
	            }
	        }
	    }
	}
	
	function checkDeleteGroup(){

		if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$this->TblMstepWorker->unBindFully();
		$workers = $this->TblMstepWorker->findAllByDelFlgAndGroupId(0, $post['group_id']);
		Output::__outputYes($workers);
	}
	
	function updateWorkerHasDelete($group_id){
	    
	    $this->TblMstepWorker->updateAll(array("group_id"=>0),array("group_id"=>$group_id));
	}
}
