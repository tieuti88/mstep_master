<?php

/**
 * Created by PhpStorm.
 * User: Edward
 * Date: 3/27/17
 * Time: 3:36 PM
 */
class MasterUserComponent extends Component {
	
	var $name="MasterUserComponent";
	var $users=array(
		'TblMstepMasterUser'
	);
	
	public function getMasterInformation($connection_name){
		
	}
}