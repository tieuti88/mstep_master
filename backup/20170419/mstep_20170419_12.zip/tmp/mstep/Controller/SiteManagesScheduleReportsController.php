<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */
App::uses('CakeEmail', 'Network/Email');

//require_once(dirname(ROOT).DS."sendgrid-php".DS."sendgrid-php.php");

class SiteManagesScheduleReportsController extends AppController{

		//public $components=array("SendGirdPlainText","Email");

        var $name = "SiteManagesScheduleReports";
        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepCustomer",
				"TblMstepSiteSchedule",
				"TblMstepSiteRemarkTitle",
				"TblMstepWorker",
				"TblMstepCustomer",
				"TblMstepTruck",
				"TblMstepSiteScheduleRemark",
				"TblMstepAreaInformation",
				"TblMasterClientProfile"
        ];

		var $titles=array();
		var $informations=array();
		var $emptySpace=" ";

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				$this->titles["siteName"]         ="現場名";
				$this->titles["customerName"]     ="顧客名";
				$this->titles["siteSchedule"]     ="日程";
				$this->titles["siteAddress"]      ="場所";
				$this->titles["siteAddressMapUrl"]="現地詳細";
				$this->titles["scheduleWorker"]   ="作業員";
				$this->titles["scheduleTruck"]    ="配車";
				$this->titles["siteRemark"]       ="現場詳細";
				$this->titles["scheduleRemark1"]  ="備考1";
				$this->titles["scheduleRemark2"]  ="備考2";
				$this->titles["scheduleRemark3"]  ="備考3";
		}

		function __makeTemplate($black_list=array()){

				$tpls=array();
				$titles=$this->titles;
				foreach($this->titles as $title=>$value){

						if(in_array($title,$black_list)) continue;
						$a=array();
						$a[]=".##{$title}_title##";
						$a[]="##{$title}_value##";
						$text=implode("\n\n",$a);
						$tpls[]=$text;
				}

				if(empty($tpls)) return false;
				$tpl=implode("\n\n",$tpls);
				return $tpl;
		}

		function __setInformations($schedule_id){

				if(!$schedules=$this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_id,0)) return false;

				$worker_ids=array();
				$truck_ids=array();
				$customer_ids=array();
				foreach($schedules as $k=>$schedule){

						$site=$schedule["TblMstepSiteDetail"];
						$site_worker=$schedule["TblMstepSiteWorker"];
						$schedule_trucks=$schedule["TblMstepScheduleTruck"];
						$schedule=$schedule["TblMstepSiteSchedule"];

						if(!empty($site["customer_id"])) $customer_ids[]=$site["customer_id"];
						if(!empty($site_worker))     $worker_ids=array_merge($worker_ids,Set::extract($site_worker,"{}.worker_id"));
						if(!empty($schedule_trucks)) $truck_ids =array_merge($truck_ids,Set::extract($schedule_trucks,"{}.truck_id"));
				}

				$customer_ids=array_unique($customer_ids);
				$worker_ids=array_unique($worker_ids);
				$truck_ids =array_unique($truck_ids);

				$customers=array();
				if(!empty($customer_ids)){

						$customers=$this->TblMstepCustomer->getCustomerInfomration($customer_ids);
						$customers=Set::combine($customers,"{n}.TblMstepCustomer.id","{n}.TblMstepCustomer");
				}

				$worker_informations=array();
				if(!empty($worker_ids)){

						$workers=$this->TblMstepWorker->getWorkers($worker_ids);
						$worker_informations=Set::combine($workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker");
				}

				$truck_informations=array();
				if(!empty($truck_ids)){

						$trucks=$this->TblMstepTruck->getTrucks($truck_ids);
						$truck_informations=Set::combine($trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck");
				}

				//■remark
				$remark_titles=array();
				if($titles=$this->TblMstepSiteRemarkTitle->find('first')) $remark_titles=$titles["TblMstepSiteRemarkTitle"];
				if(empty($remark_titles)) $remark_titles=tsv("remark_titles.tsv");

				$schedule_remark_informations=array();
				if($schedule_remarks=$this->TblMstepSiteScheduleRemark->findAllByScheduleId($schedule_id)){
				
						$schedule_remark_informations=Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");
				}

				foreach($schedules as $k=>$v){

						$schedule_id=$v["TblMstepSiteSchedule"]["id"];
						$customer_id=$v["TblMstepSiteDetail"]["customer_id"];
						$customer=(empty($customer_id) OR !isset($customers[$customer_id]))?array():$customers[$customer_id];
						$schedule_remark=(isset($schedule_remark_informations[$schedule_id]))?$schedule_remark_informations[$schedule_id]:array();

						$this->informations[$schedule_id]["site"]    =$v["TblMstepSiteDetail"];
						$this->informations[$schedule_id]["schedule"]=$v["TblMstepSiteSchedule"];
						$this->informations[$schedule_id]["customer"]=$customer;
						$this->informations[$schedule_id]["remark_titles"]=$remark_titles;
						$this->informations[$schedule_id]["schedule_remarks"]=$schedule_remark;
						$this->informations[$schedule_id]["workers"]=array();
						$this->informations[$schedule_id]["trucks"] =array();

						if(!empty($v["TblMstepSiteWorker"])){

								$site_workers=$v["TblMstepSiteWorker"];
								foreach($site_workers as $_k=>$site_worker){

										$worker_id=$site_worker["worker_id"];
										if(!isset($worker_informations[$worker_id])) continue;
										$this->informations[$schedule_id]["workers"][$worker_id]=$worker_informations[$worker_id];
								}
						}

						if(!empty($v["TblMstepScheduleTruck"])){

								$site_trucks=$v["TblMstepScheduleTruck"];
								foreach($site_trucks as $_k=>$site_truck){

										$truck_id=$site_truck["truck_id"];
										if(!isset($truck_informations[$truck_id])) continue;
										$this->informations[$schedule_id]["trucks"][$truck_id]=$truck_informations[$truck_id];
								}
						}
				}
				return true;
		}

		function __makeParams($values){

				$schedule_values=$values["siteSchedule"]["value"];
				$schedule_value="{$schedule_values["y"]}年{$schedule_values["m"]}月{$schedule_values["d"]}日({$schedule_values["w"]})";

				$schedule_worker_value="";
				$schedule_worker_values=$values["scheduleWorker"]["value"];
				foreach($schedule_worker_values as $k=>$v){
				
						$schedule_worker_value.="{$v["first_name"]}{$v["last_name"]}({$v["nickname"]})";
						$schedule_worker_value.=" ";
				}

				$schedule_truck_value="";
				$schedule_truck_values=$values["scheduleTruck"]["value"];
				foreach($schedule_truck_values as $k=>$v){
				
						$schedule_truck_value.="{$v["name"]}";
						$schedule_truck_value.=" ";
				}

				$params=array(
				
				        "siteName_title"=>$values["siteName"]["title"],
			            "siteName_value"=>$values["siteName"]["value"],
			            "customerName_title"=>$values["customerName"]["title"],
			            "customerName_value"=>$values["customerName"]["value"],
			            "siteSchedule_title"=>$values["siteSchedule"]["title"],
			            "siteSchedule_value"=>$schedule_value,
			            "siteAddress_title"=>$values["siteAddress"]["title"],
			            "siteAddress_value"=>$values["siteAddress"]["value"],
			            "siteAddressMapUrl_title"=>$values["siteAddressMapUrl"]["title"],
			            "siteAddressMapUrl_value"=>$values["siteAddressMapUrl"]["value"],
			            "scheduleWorker_title"=>$values["scheduleWorker"]["title"],
			            "scheduleWorker_value"=>trim($schedule_worker_value),
			            "scheduleTruck_title"=>$values["scheduleTruck"]["title"],
			            "scheduleTruck_value"=>trim($schedule_truck_value),
			            "siteAddress_title"=>$values["siteAddress"]["title"],
			            "siteAddress_value"=>$values["siteAddress"]["value"],
				        "siteRemark_title"=>$values["siteRemark"]["title"],
			            "siteRemark_value"=>$values["siteRemark"]["value"],
				        "scheduleRemark1_title"=>$values["scheduleRemark1"]["title"],
			            "scheduleRemark1_value"=>$values["scheduleRemark1"]["value"],
					    "scheduleRemark2_title"=>$values["scheduleRemark2"]["title"],
			            "scheduleRemark2_value"=>$values["scheduleRemark2"]["value"],
					    "scheduleRemark3_title"=>$values["scheduleRemark3"]["title"],
			            "scheduleRemark3_value"=>$values["scheduleRemark3"]["value"],
				);

				return $params;
		}

		function __getSubject($values){

				$subject="【{$values["siteName"]["value"]}】"."({$values["siteSchedule"]["value"]["m"]}月{$values["siteSchedule"]["value"]["d"]}日)";
				return $subject;
		}

		/*
		 * from       : クライアント企業メールアドレス
		 * returnPath : エラーはサーバへ届ける(info@error.dandori-taro.com)
		 * replyTo    : クライアント企業メールアドレス(返信先メールアドレス)
		 * https://sendgrid.kke.co.jp/docs/User_Manual_JP/email_activity.html
		 * */
		//function __sendMail($emails,$values,$params,$headers=array()){
		function __sendMail($emails,$message,$params,$headers=array()){

				if(empty($emails)){

					$res["headers"]=$headers;
					return $res;
				}

				$subject=$params["subject"];
				$from   =$params["from"];
				$replyTo=$params["replyTo"];
				$to     =array_shift($emails);
				if(empty(trim($to))) return $this->__sendMail($emails,$message,$params,$headers);

		        	$Email=new CakeEmail("scheduleReport");
				$Email->returnPath(EMAIL_RETURN_PATH);
				$Email->subject($subject);
				$Email->from($from);
		        	$Email->to($to);
		        	if(!empty($replyTo)) $Email->replyTo($replyTo);

			    	//$Email->template("schedule_report",null);
			    	$Email->emailFormat('text');
			    	//$Email->viewVars($values);
				$res=$Email->send($message);

				$count=count($headers);
				$headers[$count][$to]["header"]=$res["headers"];
				$headers[$count][$to]["message"]=$res["message"];
				return $this->__sendMail($emails,$message,$params,$headers);
		} 

		function sendScheduleReport(){

				$post=$this->data;
				//$schedule_id=$post["schedule_id"];
				
				$log_path=$this->__getLogPath();
				$post=unserialize(file_get_contents($log_path));
				$schedule_id=$post["schedule_id"];

				$send_black_list=(isset($post["black_list"])?$post["black_list"]:array());
				//$send_black_list=array("customerName","siteSchedule");
				
				$map_url=(isset($post["map_url"])?$post["map_url"]:array());
				//$map_url[555]="aaaaaa";
				//$map_url[735]="bbbbbb";

				$this->__sendScheduleReport($schedule_id,$send_black_list,$map_url);
		}

		function __sendScheduleReport($schedule_id,$send_black_list=array(),$map_url=array()){

				if(!is_array($schedule_id)) $schedule_id=array($schedule_id);
				$this->__setInformations($schedule_id);
				$information_values=$this->__getReportInformations($schedule_id);

				$client_id=CLIENT_DATA_SESSION["id"];
				$profile=$this->TblMasterClientProfile->findById($client_id);
				if(!$tpl=$this->__makeTemplate($send_black_list)) Output::__outputStatus(14);

				$emails=array();
				$message="";
				foreach($schedule_id as $k=>$schedule_id){

						$__values=$information_values[$schedule_id];
						$__values["siteAddressMapUrl"]["title"]=$this->titles["siteAddressMapUrl"];
						$__values["siteAddressMapUrl"]["value"]=(isset($map_url[$schedule_id])?$map_url[$schedule_id]:"");
						if(empty($__values["scheduleWorker"]["value"])) continue;

						$subject=$this->__getSubject($__values);
						$params=$this->__makeParams($__values);
						$workers=$__values["scheduleWorker"]["value"];
						$emails=array_merge($emails,Set::extract($workers,"{}.email"));
						$message.=("■".$this->__replaceViewValues($tpl,$params));
						$message.="\n\n";
				}

				$emails=array_unique($emails);
				if(in_array(DEVELOP_MODE,array("local","dev"))) $emails=TEST_EMAIL_TO;
				
				$message=trim($message,"\n");
				set_time_limit(EMAIL_TIMEOUT*count($emails));
				$res=$this->__sendMail($emails,$message,array(

						"subject"=>$subject,
						"from"   =>$profile["TblMasterClientProfile"]["client_email"],
						"replyTo"=>$profile["TblMasterClientProfile"]["client_email"]
				));
	
				Output::__outputYes();
		}

		function __getReportInformations($schedule_ids=array()){

				$values=array();
				foreach($schedule_ids as $k=>$schedule_id){

						$values[$schedule_id]=array();
						foreach($this->titles as $method=>$title){

								$__method="__{$method}";
								if(!method_exists($this,$__method)) continue;
								$value=$this->$__method($title,$schedule_id);

								$val=$value["value"];
								if(is_string($val)) $val=addcslashes($val,"\\");
								$values[$schedule_id][$method]["value"]=$val;
								$values[$schedule_id][$method]["title"]=$value["title"];
						}
				}

				return $values;
		}

		function __replaceViewValues($tpl,$viewValues=array()){

				foreach($viewValues as $k=>$v){
				
						$viewValues["##{$k}##"]=trim($v,"\n\s\t");
						unset($viewValues[$k]);
				}

				$tpl=str_replace(array_keys($viewValues),array_values($viewValues),$tpl);
				return $tpl;
		}

		function scheduleReport(){

				$post=$this->data;
				$schedule_id=$post["schedule_id"];

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				//$schedule_id=$post["schedule_id"];
				//$schedule_id=array(555,735);

				if(!is_array($schedule_id)) $schedule_id=array($schedule_id);
				if(!$this->__setInformations($schedule_id)) Output::__outputNo();
				$client_id=CLIENT_DATA_SESSION["id"];
				$profile=$this->TblMasterClientProfile->findById($client_id);
				$values=$this->__getReportInformations($schedule_id);
				$output["data"]["informations"]=$values;
				$output["data"]["customer"]["client_email"]=$profile["TblMasterClientProfile"]["client_email"];
				Output::__outputYes($output);
		}

		function __getScheduleRemarks($title,$num,$schedule_id){

				$information=$this->informations[$schedule_id];
				$schedule_remarks=$information["schedule_remarks"];
				$remark_titles=$information["remark_titles"];
				$remark_title=empty($remark_titles["schedule_remark{$num}"])?$title:$remark_titles["schedule_remark{$num}"];
				$value=(isset($schedule_remarks["remarks{$num}"])?$schedule_remarks["remarks{$num}"]:"");
				$res["value"]=$value;
				$res["title"]=$remark_title;
				return $res;
		}

		function __scheduleRemark1($title,$schedule_id){

				return $this->__getScheduleRemarks($title,1,$schedule_id);
		}

		function __scheduleRemark2($title,$schedule_id){

				return $this->__getScheduleRemarks($title,2,$schedule_id);
		}

		function __scheduleRemark3($title,$schedule_id){

				return $this->__getScheduleRemarks($title,3,$schedule_id);
		}

		function __scheduleTruck($title,$schedule_id){

				$names=array();
				$counter=0;

				$information=$this->informations[$schedule_id];
				$trucks=$information["trucks"];
				foreach($trucks as $truck_id=>$truck){

						$names[$counter]["name"]=$truck["name"];
						$counter++;
				}

				$res["value"]=$names;
				$res["title"]=$title;
				return $res;
		}

		function __scheduleWorker($title,$schedule_id){
		
				$names=array();
				$counter=0;

				$information=$this->informations[$schedule_id];
				$workers=$information["workers"];
				foreach($workers as $worker_id=>$worker){

						$name="{$worker["first_name"]}{$worker["last_name"]}";
						$nickname=$worker["nickname"];
						$names[$counter]["first_name"]=$worker["first_name"];
						$names[$counter]["last_name"]=$worker["last_name"];
						$names[$counter]["nickname"]=$worker["nickname"];
						$names[$counter]["email"]=$worker["email"];
						$counter++;
				}

				$res["value"]=$names;
				$res["title"]=$title;
				return $res;
		}

		function __siteRemark($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$remark_title=$information["remark_titles"];
				$remark_title=$remark_title["site_remark1"];
				if(empty($remark_title)) $remark_title=$title;

				$remark=$information["site"]["remarks"];
				$res["value"]=$remark;
				$res["title"]=$remark_title;
				return $res;
		}

		function __siteSchedule($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$ym=$information["schedule"]["start_month_prefix"];
				$day=$information["schedule"]["start_day"];
				$time=strtotime($ym.sprintf("%02d",$day));
				$date=date("Y年m月d日",$time);
				$youbi=youbi(date("w",$time));
				$date.="({$youbi})";
				$res["value"]["y"]=date("Y",$time);
				$res["value"]["m"]=date("m",$time);
				$res["value"]["d"]=date("d",$time);
				$res["value"]["w"]=$youbi;
				$res["title"]=$title;
				return $res;
		}

		function __siteAddress($title,$schedule_id){
		
				$this->TblMstepAreaInformation->unbindFully();
				$information=$this->informations[$schedule_id];
				$area_id=$information["site"]["area_id"];

				$address="";
				if(!empty($area_id)){

						$area=$this->TblMstepAreaInformation->findById($area_id);
						$address=$area["TblMstepAreaInformation"]["pref"].$area["TblMstepAreaInformation"]["address1"];
						$address.=$information["site"]["address"];
				}

				$res["value"]=$address;
				$res["title"]=$title;
				return $res;
		}

		function __customerName($title,$schedule_id){
		
				$information=$this->informations[$schedule_id];
				$name=((isset($information["customer"]["name"]))?$information["customer"]["name"]:"");
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

		function __siteName($title,$schedule_id){

				$information=$this->informations[$schedule_id];
				$name=$information["site"]["name"];
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

}//END class

?>
