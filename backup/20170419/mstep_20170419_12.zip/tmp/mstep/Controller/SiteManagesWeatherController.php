<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteManagesWeatherController extends AppController{

        var $name = "SiteManagesWeather";
        var $uses = [

                "TblMstepWeatherWeeklyReports",
                "TblMstepWeatherInformations",
                "TblMstepWeatherImages"
        ];

        function beforeFilter(){

                parent::beforeFilter();
        }

        #
        # @author Akabane
        # @date 2011/05/07 14:44:59
        function beforeRender(){
        }

        function __getImageByWeatherDate($user_pref_id){

            	$results = array();
            	$weather_id = $this->TblMstepWeatherWeeklyReports->getWeatherIdByPrefId($user_pref_id);
            	$weather_data = $this->TblMstepWeatherInformations->findAllByReportId($weather_id);
            	$results = Set::combine($weather_data,"{n}.TblMstepWeatherInformations.date","{n}.TblMstepWeatherImages.image");
            	return $results;
        }


}//END class

?>
