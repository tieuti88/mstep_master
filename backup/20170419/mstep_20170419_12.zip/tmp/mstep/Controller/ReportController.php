<?php
class ReportController extends AppController {
    var $name = 'Report';
    var $uses = [
            'TblMstepMasterUser',
            'TblMstepSiteDetail',
            'TblMstepSiteWorker',
            'TblMstepSiteSchedule',
            'TblMstepWorker',
            'TblMstepWorkerPrice'
    ];
    var $viewAuth = ['index', 'add', 'deleteSchedule', 'saveReport', 'getScheduleIdByStartDate'];

    function beforeFilter() {

        parent::beforeFilter();
    }

    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {

        // All registered users can logout
        if (in_array($this->action, $this->viewAuth)) {
            return true;
        }

        return parent::isAuthorized($user);
    }
    public function index() {

        if($this->Auth->user("worker_id") > 0 && in_array($this->Auth->user("authority"), ["normal", "senior"])){

            $worker_id = $this->Auth->user("worker_id");

        }else{

            throw new NotFoundException();
        }

        $this->TblMstepSiteWorker->unbindModel(
	            array(
	                    'belongsTo' => array(
	                            'TblMstepWorker',
	                            'TblMstepSiteScheduleRemark'
	                    )
	            ));
        $this->TblMstepSiteDetail->unbindFully();

        $schedules = $this->TblMstepSiteWorker->find('all', array(
	            'conditions' => array(
	                    'TblMstepSiteWorker.worker_id' => $worker_id,
	                    'TblMstepSiteWorker.report <>' => '',
	                    'TblMstepSiteWorker.del_flg' => 0
	            ),
	            'order' => array(
	                    'TblMstepSiteSchedule.start_date' => 'DESC'
	            ),
                'recursive' => 1
	    ));
        $schedule_report = $this->TblMstepSiteWorker->find('all', array(
                'conditions' => array(
                        'TblMstepSiteWorker.worker_id' => $worker_id,
                        'TblMstepSiteWorker.report' => '',
                        'TblMstepSiteWorker.del_flg' => 0
                ),
                'order' => array(
                        'TblMstepSiteSchedule.start_date' => 'ASC'
                ),
                'recursive' => 1
        ));

        $this->set(compact('schedules', 'schedule_report'));
	}

	function deleteSchedule(){
	    if(!$this->isPostRequest()) exit;

	    $schedule_id = $_POST["schedule_id"];
	    $worker_id = $this->Auth->user("worker_id");

	    $this->TblMstepSiteWorker->unbindFully();
	    if (!$site_worker = $this->TblMstepSiteWorker->findByScheduleIdAndWorkerIdAndDelFlg($schedule_id, $worker_id, 0)) {
	        Output::__outputStatus(1);
	    }

	    $this->TblMstepSiteWorker->id = $site_worker['TblMstepSiteWorker']['id'];
	    if($site_worker['TblMstepSiteWorker']['assign_flg'] == 1){
	       $this->TblMstepSiteWorker->save(array('report' => ''));
	       $res['assign_flg'] = true;
	    }else{
	        $this->TblMstepSiteWorker->delete($site_worker['TblMstepSiteWorker']['id']);
	        $res['assign_flg'] = false;
	    }

	    Output::__outputYes($res);
	}

	public function add($schedule_id = null) {
	    $schedule = [];
	    $sites = [];

	    $this->TblMstepSiteWorker->unbindModel(
	            array(
	                    'belongsTo' => array(
	                            'TblMstepWorker',
	                            'TblMstepSiteScheduleRemark'
	                    )
	            ));
	    $this->TblMstepSiteDetail->unbindModel(
            array(
                    'hasMany' => array('TblMstepSiteWorker')
            )
	    );

	    $this->TblMstepSiteSchedule->unbindFully();

	    if(!empty($schedule_id)){
	        $_schedule = $this->TblMstepSiteWorker->find('all', array(
	                'conditions' => array(
	                        'TblMstepSiteWorker.worker_id' => $this->Auth->user("worker_id"),
	                        'TblMstepSiteWorker.del_flg' => 0,
	                        'TblMstepSiteSchedule.id' => $schedule_id
	                ),
	                'order' => array(
	                        'TblMstepSiteSchedule.id' => 'ASC'
	                ),
	                'recursive' => 2
	        ));
	        if(!$_schedule){
	            throw new NotFoundException();
	        }else{
	            $schedule = $_schedule[0];
	            if(strtotime($schedule['TblMstepSiteSchedule']['start_date']) > time()){
	                throw new NotFoundException();
	            }
	        }
        }else{
            $sites = $this->TblMstepSiteDetail->find('all', array(
                    'conditions' => array(
                            'TblMstepSiteDetail.del_flg' => 0
                    ),
                    'order' => array(
                            'TblMstepSiteDetail.id' => 'ASC'
                    ),
                    'recursive' => 1
            ));
        }

        $this->set(compact('schedule', 'sites'));
    }

    public function saveReport(){

        if(!$this->isPostRequest()) exit;
        
        $post = $_POST;

        $data = [];
        $data['worker_id'] = $this->Auth->user("worker_id");
        $data['report'] = $post['report'];

        // Edit
        if(isset($post['schedule_id'])){
            	$data['schedule_id'] = $post['schedule_id'];
        }else{
				Output::__outputStatus(1);
        }

		$this->TblMstepSiteWorker->unbindFully();
	    $report = $this->TblMstepSiteWorker->findByWorkerIdAndScheduleIdAndDelFlg($data['worker_id'], $data['schedule_id'], 0);
	    if(isset($report['TblMstepSiteWorker']['id'])){
	        $this->TblMstepSiteWorker->id = $report['TblMstepSiteWorker']['id'];
	    }else{
	        $worker = $this->TblMstepWorker->findById($data['worker_id']);
	        $this->TblMstepSiteWorker->create();
	        $data['site_id'] = $post['site_id'];
	        $data['assign_flg'] = 0;
	        $data['initial_assign_flg'] = 0;
	        $schedule = $this->TblMstepSiteSchedule->findById($data['schedule_id']);
	        $data['price'] = $this->TblMstepWorkerPrice->getWorkerPriceByDate($data['worker_id'], $schedule['TblMstepSiteSchedule']['start_date']);
	    }

	    if($this->TblMstepSiteWorker->save($data)){
	        Output::__outputYes();
	    }else{
	        Output::__outputStatus(5);
	    }
	}

	public function getScheduleIdByStartDate(){
	    if(!$this->isPostRequest()) exit;

	    $post = $_POST;
	    $data = [];
	    if(isset($post['site_id']) && isset($post['schedule_date'])){
	        $this->TblMstepSiteSchedule->unbindFully();
	        $schedule = $this->TblMstepSiteSchedule->findBySiteIdAndStartDate($post['site_id'], $post['schedule_date']);
	        if($schedule){
	            $schedule_id = $schedule['TblMstepSiteSchedule']['id'];
	            $report = $this->TblMstepSiteWorker->findByWorkerIdAndScheduleIdAndDelFlg($this->Auth->user("worker_id"), $schedule_id, 0);
	            if($report){
	                $data = $report['TblMstepSiteWorker'];
	                Output::__outputYes($data);
	            }else{
	                $data['schedule_id'] = $schedule['TblMstepSiteSchedule']['id'];
	                Output::__outputYes($data);
	            }
	        }else{
	            Output::__outputStatus(1);
	        }
	    }
	}
}
