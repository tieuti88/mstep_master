<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";

class SiteManagesRegistedInfomationsController extends AppController{

        var $name = "SiteManagesRegistedInfomations";
        var $uses = [

				"TblMstepGroupWorker",
				"TblMstepWorker",
				"TblMstepSiteSchedule",
				"TblMstepSiteWorker",
				"TblMstepSiteDetail",
				"TblMstepAreaInformation",
				"TblMstepScheduleTruck"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				//$this->unbindFully();
		}

		public function isAuthorized($user){

				return true;
		}

		function getInformations(){

				$post=$this->data;

				//$post=unserialize(file_get_contents($log_path));

				//group
				$site_id  =$post["site_id"];
				$schedule_id=isset($post["schedule_id"])?$post["schedule_id"]:false;
				if(!$site_detail=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0)) Output::__outputStatus(1);

				$all_groups=$this->TblMstepGroupWorker->findAllByDelFlg(0);
				$all_groups=Set::combine($all_groups,"{n}.TblMstepGroupWorker.id","{n}.TblMstepGroupWorker.name");

				//worker
				$all_group_workers=array();
				$all_group_ids=array_keys($all_groups);
				if($all_workers=$this->TblMstepWorker->findAllByGroupIdAndDelFlg($all_group_ids,0)){

						foreach($all_workers as $k=>$v){

								if(!isset($all_group_workers[$v["TblMstepWorker"]["group_id"]]))$all_group_workers[$v["TblMstepWorker"]["group_id"]]=array();
								$worker_id=$v["TblMstepWorker"]["id"];
								$all_group_workers[$v["TblMstepWorker"]["group_id"]][$worker_id]["first_name"]=$v["TblMstepWorker"]["first_name"];
								$all_group_workers[$v["TblMstepWorker"]["group_id"]][$worker_id]["last_name"] =$v["TblMstepWorker"]["last_name"];
								$all_group_workers[$v["TblMstepWorker"]["group_id"]][$worker_id]["nickname"]  =$v["TblMstepWorker"]["nickname"];
								$all_group_workers[$v["TblMstepWorker"]["group_id"]][$worker_id]["id"] =$worker_id;
						}
				}

				// site
				$area_id=$site_detail["TblMstepSiteDetail"]["area_id"];
				$area_information=$this->TblMstepAreaInformation->findById($area_id);

				if($schedule_id) {

						//workers by group
						$registed_workers_group = $this->__getRegistedSiteWorkersByGroup($schedule_id);
						$output["data"]["registed_workers_group"] = $registed_workers_group;

						//truck by schedule id
						$registed_truck_informations=$this->__getTruckInformationsBySiteIdAndScheduleId($site_id, $schedule_id);
						$output["data"]["registed_truck_informations"] = $registed_truck_informations;
				}

				//registed informations.
				$schedules=array();
				$this->TblMstepSiteSchedule->unbindFully();
				if(!empty($schedule_id)) $schedules=$this->TblMstepSiteSchedule->findAllById($schedule_id);
				if(empty($schedule_id))  $schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);

				$all_schedules=$this->__getSiteSchedules($site_id,$schedules);
				$registed_workers  =$this->__getRegistedSiteWorkers($all_schedules);
				$registed_trucks   =$this->__getRegistedSiteTrucks($all_schedules);
				$registed_schedules=$this->__getRegistedSchedule($schedules);
				$start_date_mss=Set::extract($registed_schedules,"{}.start_date_ms");
				$min_start_date_ms=min($start_date_mss);
				$max_start_date_ms=max($start_date_mss);

				//truck informations.
				$all_schedule_ids=Set::extract($schedules,"{}.TblMstepSiteSchedule.id");
				$truck_inforamtions=$this->__getAllTruckInformations();
				$registed_truck_informations=$this->__getRegistedTruck($site_id,$all_schedule_ids,$truck_inforamtions);

				//remarks
				$registed_remarks=$this->__getRegistedSiteRemarks($all_schedule_ids);
				$remark_titles=$this->__getRemarkTitles();

				//colors
				$all_colors=$this->__getColorList();
				$registed_colors=$this->__getRegistedColor($schedules,$site_detail["TblMstepSiteDetail"]["color_id"]);

				$output["data"]["site_group_worker"]  =$all_group_workers;
				$output["data"]["site_group"]         =$all_groups;
				$output["data"]["site_colors"]        =$all_colors;
				$output["data"]["site_remark_titles"] =$remark_titles;
				$output["data"]["site_detail"]["name"]=$site_detail["TblMstepSiteDetail"]["name"];
				$output["data"]["site_location"]["area"]=!empty($area_information)?$area_information["TblMstepAreaInformation"]["address1"]:"";
				$output["data"]["registed_workers"]   =$registed_workers;
				$output["data"]["registed_schedule"]  =$registed_schedules;
				$output["data"]["registed_trucks"]    =$registed_trucks;
				$output["data"]["registed_remarks"]   =$registed_remarks;
				$output["data"]["registed_colors"]    =$registed_colors;
				$output["data"]["registed_all_trucks"]=$truck_inforamtions;
				$output["data"]["registed_schedule_ms_range"]["start"]=$min_start_date_ms;
				$output["data"]["registed_schedule_ms_range"]["end"]=$max_start_date_ms;

				Output::__outputYes($output);
		}

		function __getSiteSchedules($site_id,$schedules){

				$ym=array();
				$d=array();
				foreach($schedules as $k=>$v){

						$data=$v["TblMstepSiteSchedule"];
						$ym[]=$data["start_month_prefix"];
						$d[] =$data["start_day"];
				}

				//using where.
				$ym=array_unique($ym);
				$this->TblMstepSiteSchedule->unbindFully();
				$all_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndStartMonthPrefixAndStartDayAndDelFlg($site_id,$ym,$d,0);
				return $all_schedules;
		}

		function __getRegistedSiteTrucks($all_schedules){

				$all_start_dates=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_date");
				$all_month_prefix=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_month_prefix");
				$all_start_day=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_day");

				$all_schedule_ids=array_keys($all_start_dates);
				$all_site_ids=array_unique(Set::extract($all_schedules,"{}.TblMstepSiteSchedule.site_id"));

				if(!$all_site_trucks=$this->TblMstepScheduleTruck->findAllBySiteIdAndScheduleIdAndDelFlg($all_site_ids,$all_schedule_ids,0)) return array();

				$registed_trucks=array();
				foreach($all_site_trucks as $k=>$v){

						$schedule_id=$v["TblMstepScheduleTruck"]["schedule_id"];
						$s=strtotime($all_start_dates[$schedule_id]);
						$start_date=date("Ymd",$s);

						$start_month_prefix=$all_month_prefix[$schedule_id];
						$start_day=$all_start_day[$schedule_id];

						$site_id=$v["TblMstepScheduleTruck"]["site_id"];

						if(!isset($registed_trucks[$start_date][$site_id])){

								$registed_truck[$start_date][$site_id]["start_month_prefix"]=$start_month_prefix;
								$registed_truck[$start_date][$site_id]["start_day"]=sprintf("%02d",$start_day);
								$registed_truck[$start_date][$site_id]["start_date_ms"]=$s*1000;
								$registed_truck[$start_date][$site_id]["schedule_id"]  =$v["TblMstepScheduleTruck"]["schedule_id"];
								$registed_truck[$start_date][$site_id]["remarks"]      =$v["TblMstepScheduleTruck"]["remarks"];
						}

						$registed_truck[$start_date][$site_id]["truck_id"][]=$v["TblMstepScheduleTruck"]["truck_id"];
				};

				return $registed_truck;
		}

		function __getRegistedSiteWorkersByGroup($schedule_id) {

				$site_workers = $this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_id, 0);
				$worker_ids = Set::combine($site_workers,"{n}.TblMstepSiteWorker.id","{n}.TblMstepSiteWorker.worker_id");
				$all_worker_ids = array_values($worker_ids);

				$this->TblMstepWorker->unbindModel(
						array(
								'belongsTo' => array('TblMstepAreaInformation'),
						)
				);
				$workers = $this->TblMstepWorker->findAllByIdAndDelFlg($all_worker_ids, 0);
				$registed_worker_group=array();
				$i=1;
				foreach ($workers as $k => $worker) {

						$registed_worker_group[$worker["TblMstepWorker"]["group_id"]]["group"]=$worker["TblMstepGroupWorker"]["name"];
						$registed_worker_group[$worker["TblMstepWorker"]["group_id"]]["workers"][$i]=[];
						$registed_worker_group[$worker["TblMstepWorker"]["group_id"]]["workers"][$i]["first_name"] = $worker["TblMstepWorker"]["first_name"];
						$registed_worker_group[$worker["TblMstepWorker"]["group_id"]]["workers"][$i]["last_name"] = $worker["TblMstepWorker"]["last_name"];
						$registed_worker_group[$worker["TblMstepWorker"]["group_id"]]["workers"][$i]["nickname"] = $worker["TblMstepWorker"]["nickname"];

						++$i;
				}

				return $registed_worker_group;
		}

		function __getRegistedSiteWorkers($all_schedules){

				$all_start_dates=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_date");
				$all_month_prefix=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_month_prefix");
				$all_start_day=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_day");

				$all_schedule_ids=array_keys($all_start_dates);
				$all_site_ids=array_unique(Set::extract($all_schedules,"{}.TblMstepSiteSchedule.site_id"));

				$this->TblMstepSiteWorker->unbindFully();
				$f=array("schedule_id","site_id","worker_id","assign_flg");
				if(!$all_site_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndSiteIdAndDelFlg($all_schedule_ids,$all_site_ids,0,$f)) return array();

				$registed_workers=array();
				foreach($all_site_workers as $k=>$v){

						$schedule_id=$v["TblMstepSiteWorker"]["schedule_id"];
						$s=strtotime($all_start_dates[$schedule_id]);
						$start_date=date("Ymd",$s);
						$site_id=$v["TblMstepSiteWorker"]["site_id"];

						$start_month_prefix=$all_month_prefix[$schedule_id];
						$start_day=$all_start_day[$schedule_id];

						if(empty($v["TblMstepSiteWorker"]["assign_flg"])) continue;

						if(!isset($registed_workers[$start_date][$site_id])){

								$registed_workers[$start_date][$site_id]["start_date_ms"]=$s*1000;
								$registed_workers[$start_date][$site_id]["start_month_prefix"]=$start_month_prefix;
								$registed_workers[$start_date][$site_id]["start_day"]=sprintf("%02d",$start_day);
								$registed_workers[$start_date][$site_id]["schedule_id"]  =$v["TblMstepSiteWorker"]["schedule_id"];
						}

						$registed_workers[$start_date][$site_id]["worker_id"][]=$v["TblMstepSiteWorker"]["worker_id"];
				};

				return $registed_workers;
		}
	
		/*
		function __getRegistedSiteWorkers($all_schedules){

				$all_start_dates=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_date");
				$all_month_prefix=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_month_prefix");
				$all_start_day=Set::combine($all_schedules,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.start_day");

				$all_schedule_ids=array_keys($all_start_dates);
				$all_site_ids=array_unique(Set::extract($all_schedules,"{}.TblMstepSiteSchedule.site_id"));

				$this->TblMstepSiteWorker->unbindFully();
				$f=array("schedule_id","site_id","worker_id","assign_flg");
				if(!$all_site_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndSiteIdAndDelFlg($all_schedule_ids,$all_site_ids,0,$f)) return array();

				$registed_workers=array();
				foreach($all_site_workers as $k=>$v){

						$schedule_id=$v["TblMstepSiteWorker"]["schedule_id"];
						$s=strtotime($all_start_dates[$schedule_id]);
						$start_date=date("Ymd",$s);
						$site_id=$v["TblMstepSiteWorker"]["site_id"];

						$start_month_prefix=$all_month_prefix[$schedule_id];
						$start_day=$all_start_day[$schedule_id];

						if(!isset($registed_workers[$start_date][$site_id])){

								$registed_worker[$start_date][$site_id]["start_date_ms"]=$s*1000;
								$registed_worker[$start_date][$site_id]["start_month_prefix"]=$start_month_prefix;
								$registed_worker[$start_date][$site_id]["start_day"]=sprintf("%02d",$start_day);
								$registed_worker[$start_date][$site_id]["schedule_id"]  =$v["TblMstepSiteWorker"]["schedule_id"];
						}

						$registed_worker[$start_date][$site_id]["worker_id"][]=$v["TblMstepSiteWorker"]["worker_id"];
				};

				return $registed_worker;
		}
		 */

		function __getRegistedColor($schedules,$base_color_id=0){

				$res=array();
				foreach($schedules as $k=>$v){

						$data=$v["TblMstepSiteSchedule"];
						$res[$data["id"]]=empty($data["color_id"])?$base_color_id:$data["color_id"];
				}
				return $res;
		}

		function __getRegistedSchedule($schedule){

				$res=array();
				foreach($schedule as $k=>$v){

						$start_month_prefix=$v["TblMstepSiteSchedule"]["start_month_prefix"];
						$start_day=sprintf("%02d",$v["TblMstepSiteSchedule"]["start_day"]);
						$res[$k]["schedule_id"]  =$v["TblMstepSiteSchedule"]["id"];
						$res[$k]["start_date_ms"]=strtotime($start_month_prefix.$start_day)*1000;
						$res[$k]["start_month_prefix"]=$start_month_prefix;
						$res[$k]["start_day"]         =$start_day;
						//$res[$k]["start_date_ms"]=strtotime($v["TblMstepSiteSchedule"]["start_date"])*1000;
				}

				return $res;
		}

		function __getAllTruckInformations(){

				App::uses("SiteManagesTrucksController","Controller");
				$controller=new SiteManagesTrucksController();
				$truck_informations=$controller->__getAllTruckInformations();
				return $truck_informations;
		}

		function __getTruckInformationsBySiteIdAndScheduleId($site_id, $schedule_id) {

				App::uses("SiteManagesTrucksController","Controller");
				$controller=new SiteManagesTrucksController();
				$registed_truck_informations=$controller->__getTruckInformationsBySiteIdAndScheduleId($site_id, $schedule_id);
				return $registed_truck_informations;
		}

		function __getRegistedTruck($site_id,$all_schedule_ids,$truck_informations){

				App::uses("SiteManagesTrucksController","Controller");
				$controller=new SiteManagesTrucksController();
				return $controller->__getRegistedTruck($site_id,$all_schedule_ids,$truck_informations);
		}

		function __getRegistedSiteRemarks($schedule_ids){

				App::uses("SiteManagesScheduleRemarksController","Controller");
				$controller=new SiteManagesScheduleRemarksController();
				return $controller->__getRegistedSiteRemarks($schedule_ids);
		}

		function __getRemarkTitles(){

				App::uses("SiteManagesScheduleRemarksController","Controller");
				$controller=new SiteManagesScheduleRemarksController();
				return $controller->__getRemarkTitles();
		}

		function __getColorList(){

				App::uses("SiteManagesColorController","Controller");
				$controller=new SiteManagesColorController();
				return $controller->__getColorList();
		}

}//END class

?>
