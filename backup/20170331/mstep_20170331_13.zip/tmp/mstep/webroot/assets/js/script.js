/**
 * Created by yen on 9/20/16.
 */

$(document).ready(function(){

    $("#add-calendar").click(function(){

        // Add new calendar element

        var stt = 0;
        

    });

});