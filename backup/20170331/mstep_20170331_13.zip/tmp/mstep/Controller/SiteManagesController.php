<?php

require_once "Schedule".DS."ScheduleNinku.php";
require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "Error".DS."ScheduleError.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

App::uses('ScheduleBaseController','Controller');
class SiteManagesController extends ScheduleBaseController{

		var $name = "SiteManages";
		var $clientManagesSitesIds = array();
		var $uses = [

			"TblMstepSiteDetail",
			"TblMstepSiteSchedule",
			"TblMstepSiteWorker",
			"TblMstepScheduleLog",
			"TblMstepCustomer",
			"TblMstepAreaInformation",
			"TblMstepScheduleTruck",
			"TblMstepMasterUser",
			"TblMstepSiteScheduleReport",
			"TblMstepSiteScheduleRemark"
		];

		function beforeFilter() {

				parent::beforeFilter();
				$this->__init();
		}

		function __init(){

		}

		public function isAuthorized($user){
		
				return true;
		}

		function getSiteOptionValues() {

				$post = $this->data;

				if(!$customers=$this->TblMstepCustomer->findAllByDelFlg(0)){

						$output["data"] = array();
						Output::__outputYes($output);
				}

				$customer_ids = Set::extract($customers, "{}.TblMstepCustomer.id");
				if (!$site_details = $this->TblMstepSiteDetail->findAllByCustomerIdAndDelFlg($customer_ids, 0)) {

						$output["data"] = array();
						Output::__outputYes($output);
				}

				$customer_list = array();
				foreach ($customers as $k => $v) {

						$customer_list[$k]["id"] = $v["TblMstepCustomer"]["id"];
						$customer_list[$k]["name"] = $v["TblMstepCustomer"]["name"];
				}

				$output["data"]["customers"] = $customer_list;
				Output::__outputYes($output);
		}

		// delete site and some informations by site_id.
		function deleteSite() {

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				//$site_id=$post["site_id"];
				if(!$this->isPostRequest()) exit;

				$site_id = $_POST["site_id"];
				if (!$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0)) {

						Output::__outputStatus(1);
				}

				$datasource = $this->TblMstepSiteDetail->getDataSource();
				$datasource->begin();

				// delete site information.
				$save = array();
				$save["id"] = $site_id;
				$save["del_flg"] = 1;
				if (!$this->TblMstepSiteDetail->save($save)) {

						Output::__outputStatus(1);
				}

				// execution before __deleteSiteScheduleById
				$target_dates=$this->TblMstepSiteSchedule->getNinkuRefreshBySiteId($site_id);

				// delete schedules.
				$res = $this->__deleteSiteScheduleBySiteId($site_id);
				if (!$res["status"]) {

						Output::__outputStatus(1);
				}

				// delete workers.
				$res = $this->__deleteSiteWorkersBySiteId($site_id);
				if (!$res["status"]) {

						Output::__outputStatus(1);
				}

				// refresh ninku values.(人が登録されている日を対象)
				if(!empty($target_dates) AND !$res=$this->__refreshNinku($target_dates)) Output::__outputStatus(1);

				$datasource->commit();
				Output::__outputYes();
		}

		function __deleteSchedule($schedule_id){

				// delete schedules.
				$res = $this->__deleteSiteScheduleById($schedule_id);
				if(!$res["status"]){

						throw new Exception(1);
						return;
				}

				//delete site workers.
				$res = $this->__deleteSiteWorkersByScheduleId($schedule_id);
				if(!$res["status"]){

						throw new Exception(1);
						return;
				}

				//delete site schedule remarks.
				$res = $this->__deleteSiteScheduleRemarkByScheduleId($schedule_id);
				if(!$res["status"]){

 						throw new Exception(1);
						return;
				}

				//delete site schedule trucks.
				$res = $this->__deleteSiteScheduleTruckByScheduleId($schedule_id);
				if(!$res["status"]){

 						throw new Exception(1);
						return;
				}

				return true;
		}

		// delete schedule and some informations by schedule_id.
		function deleteSchedule() {

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				//$schedule_id=$post["schedule_id"];
				
				if(!$this->isPostRequest()) exit;
				$schedule_id=$_POST["schedule_id"];
				$datasource=$this->TblMstepSiteSchedule->getDataSource();
				$datasource->begin();

				// refresh date for ninku.
				$ninku_refresh_dates=$this->TblMstepSiteSchedule->getNinkuRefreshByScheduleId($schedule_id);

				try{

						$this->__deleteSchedule($schedule_id);
				
				}catch(Exception $e){
				
						$error_code=$e->getMessage();
						Output::__outputStatus(1);
				}

				// ninku(作業員が登録されていないなら、更新する必要は無い)
				if($ninku_refresh_dates){

						$res=$this->__refreshNinku($ninku_refresh_dates);
						if(empty($res["status"])) Output::__outputStatus(1);
				}

				$datasource->commit();
				Output::__outputYes();
		}

		function __getNinkuRefreshDates($values){
		
				$values=array_filter($values,function($v){

						return !empty($v["is_diffrent_day"]);
				});

				if(empty($values)) return array();
				$current_dates=Set::extract($values,"{}.day");
				$prev_dates   =Set::extract($values,"{}.prev_day");
				$current_dates=array_values($current_dates);
				$prev_dates=array_values($prev_dates);
				$dates=(array_unique(array_merge($current_dates,$prev_dates)));
				return $dates;
		}

		function saveSchedule(){

				if(!$this->isPostRequest()) exit;

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				$user_id      =$post["user_id"];
				$start_date   =$post["start_date"];
				$end_date     =$post["end_date"];
				$around_values=isset($post["around_values"])?$post["around_values"]:array();
				//$date_action_history=(isset($post["date_history"]))?$post["date_history"]:array();
				$data           =(isset($post["effective_date"]))?$post["effective_date"]:array();
				$remove_site_ids=(isset($post["remove_site_ids"])?$post["remove_site_ids"]:array());
				$local_time_key =isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;
				//$date_history=$this->__parseDateHistory($post["date_history"]);

				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				//transaction
				$datasource=$this->TblMstepSiteSchedule->getDataSource();
				$datasource->begin();

				//around values.
				if(!empty($around_values)){

						$res=$this->TblMstepSiteDetail->updateAroundValues($around_values);
						if(empty($res["status"])) Output::__outputStatus(5);
				}

				$res=$this->__saveSchedule($data);
				if(empty($res["status"])) Output::__outputStatus($res["errorNo"]);

				if(!empty($remove_site_ids)) $this->__deleteScheduleBySiteIds($remove_site_ids);

				$schedule_insert_ids=$res["insert_ids"];
				if(empty($res["status"])) Output::__outputStatus(5);

				// commit.
				$datasource->commit();

				// edit limited time.
				$last_edit_time=time();
				$instance=ScheduleLog::getInstance($this);
				if(!$instance->timeInitialize($user_id,$last_edit_time)) Output::__outputStatus(1);
				$last_edit_time=($last_edit_time*1000);

				// new informations.
				$start_date=date("Y-m-d", strtotime($start_date));
				$end_date  =date("Y-m-d", strtotime($end_date));
				$informations = $this->__getInformations($start_date, $end_date);

				//refresh dates for ninku values.
				$site_ids=$informations["data"]["site_ids"];
				if($ninku_refresh_dates=$this->__getNinkuRefreshDates($data)){

						// ninku
						$res=$this->__refreshNinku($ninku_refresh_dates);
						if(empty($res["status"])) Output::__outputStatus(5);
				}
	
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$output["last_edit_time"]=$last_edit_time;
				$output["data"]["schedule_ids"]=$schedule_insert_ids;
				$output["data"]["informations"]=$informations["informations"];
				$output["data"]["ninku_situations"]=$ninku_situations;
				Output::__outputYes($output);
		}

		function __siteTruckIdHistories($schedule_ids=array()){

				$history_ids=array();
				$all_schedule_trucks=$this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($schedule_ids,0);
				foreach($all_schedule_trucks as $k=>$v){

						$site_truck=$v["TblMstepScheduleTruck"];
						$history_ids[$site_truck["schedule_id"]][$site_truck["truck_id"]]=$site_truck["id"];
				}

				return $history_ids;
		}

		function __siteWorkerIdHistories($schedule_ids=array()){

				$history_ids=array();
				$this->TblMstepSiteWorker->unbindFully();
				$all_schedule_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_ids,0);
				foreach($all_schedule_workers as $k=>$v){

						$site_worker=$v["TblMstepSiteWorker"];
						$history_ids[$site_worker["schedule_id"]][$site_worker["worker_id"]]=$site_worker["id"];
				}

				return $history_ids;
		}

		function __deleteSiteWorkers($schedule_ids=array()){

				try{

						$v=array("del_flg"=>1);
						$c=array("schedule_id"=>$schedule_ids,"del_flg"=>0);
						$this->TblMstepSiteWorker->unbindFully();
						$this->TblMstepSiteWorker->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"]=false;
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __deleteSiteTrucks($schedule_ids=array()){

				try{

						$v=array("del_flg"=>1);
						$c=array("schedule_id"=>$schedule_ids,"del_flg"=>0);
						$this->TblMstepScheduleTruck->unbindFully();
						$this->TblMstepScheduleTruck->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"]=false;
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __insertSiteWorkers($inserts){
		
				try{

						$this->TblMstepSiteWorker->multiInsert($inserts);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"]=false;
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __insertSiteTrucks($inserts){
		
				try{

						$this->TblMstepScheduleTruck->multiInsert($inserts);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"]=false;
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __deleteScheduleBySiteIds($site_ids=array()){

				if(!$schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_ids,0)){
				
						$res["status"]=true;
						$res["insert_ids"]=array();
						return $res;
				}

				$schedule_ids=Set::extract($schedules,"{}.TblMstepSiteSchedule.id");

				$inserts=array();
				foreach($schedule_ids as $k=>$schedule_id){
				
						$inserts[$k]["schedule_id"]=$schedule_id;
						$inserts[$k]["is_enable"]=0;
				}

				return $this->__saveScheduleNORMAL($inserts);
		}

		function __saveScheduleNORMAL($data){

				#When shedule is moved all workers on the schedule are removed.
				#When shedule is moved all trucks on the schedule are removed.
				$remove_schedule_ids=array();
				if($remove_schedules=array_filter($data,function($a){ return (empty($a["is_diffrent_day"]))?false:true; })){
				
						$remove_schedule_ids=Set::extract($remove_schedules,"{}.schedule_id");

						$res=$this->__deleteSiteWorkers($remove_schedule_ids);
						if(empty($res["status"])) return $res;
	
						$res=$this->__deleteSiteTrucks($remove_schedule_ids);
						if(empty($res["status"])) return $res;
				}

				$insert=array();
				$worker_inserts=array();
				$truck_inserts=array();
				$check_date_positions=array();
				foreach($data as $k=>$v){

						$schedule_id=$v["schedule_id"];
						$del_flg=(!empty($v["is_enable"])?0:1);
						$insert[$k]["id"]=$schedule_id;
						$insert[$k]["del_flg"]=$del_flg;

						if(isset($v["day"])){

								$_s=strtotime($v["day"]);
								$insert[$k]["start_month_prefix"]=date("Ym",$_s);
								$insert[$k]["start_day"] =date("j",$_s);
								$insert[$k]["start_date"]=date("Y-m-d",$_s);
								$insert[$k]["end_date"]  =$insert[$k]["start_date"];
						}

						if(isset($v["position_num"])){ 

								$position_num=$v["position_num"];
								$insert[$k]["position_num"]=$position_num;
								if(!isset($check_date_positions[$v["day"]][$v["site_id"]]))$check_date_positions[$v["day"]][$v["site_id"]]=array();
								if(count($check_date_positions[$v["day"]][$v["site_id"]])>0){

										$res=array();
										$res["status"]=false;
										$res["errorNo"]=6;
										return $res;
								}

								$check_date_positions[$v["day"]][$v["site_id"]][]=$position_num;
						}
				}

				mail("kiyosawa-n@spc-jpn.co.jp","DELETE_SCHEDULE_".CLIENT."_".$this->params["controller"],print_r($insert,1),"hayahide4561@gmail.com");
				$res=$this->__multiInsert($this->TblMstepSiteSchedule,$insert);
				if(empty($res["status"])) return $res;

				$res["insert_ids"]=array();
				return $res;
		}

		function __saveScheduleCOPY($datas,$insert_ids=array()){

				if(1>count($datas)){

						$res["status"]=true;
						$res["insert_ids"]=$insert_ids;
						return $res;
				}

				$data=array_shift($datas);

				if(empty($data["is_enable"])){

						return $this->__saveScheduleCOPY($datas,$insert_ids);
				}

				$_s=strtotime($data["day"]);
				$insert["start_month_prefix"]=date("Ym",$_s);
				$insert["start_day"] =date("j",$_s);
				$insert["start_date"]=date("Y-m-d",$_s);
				$insert["end_date"]=$insert["start_date"];
				$insert["position_num"]=$data["position_num"];
				$insert["site_id"]     =$data["site_id"];
				$this->TblMstepSiteSchedule->id=null;
				if(!$this->TblMstepSiteSchedule->save($insert)){

						$res["status"]=false;
						return $res;
				}

				$schedule_id=$this->TblMstepSiteSchedule->getLastInsertID();
				$insert_ids[$data["object_id"]]=$schedule_id;
				return $this->__saveScheduleCOPY($datas,$insert_ids);
		}

		function __saveSchedule($data=array()){

				$types=array();
				foreach($data as $object_id=>$v){

						$v["object_id"]=$object_id;
						$types[$v["type"]][]=$v;
				}

				$insert_ids=array();
				foreach($types as $type=>$v){

						$type=strtoupper($type);
						$method="__saveSchedule{$type}";
						if(!method_exists($this,$method)) continue;
						$res=$this->{$method}($v);
						if(empty($res["status"])){

								$res["status"]=false;
								return $res;
						}

						$insert_ids+=$res["insert_ids"];
				}

				$res["status"]=true;
				$res["insert_ids"]=$insert_ids;
				return $res;
		}

		function getSiteDetails() {

				$post=$this->data;
				$site_id=$post["site_id"];
				$schedule_id=(isset($post["schedule_id"])?$post["schedule_id"]:"");

				if(!$res=$this->__getSiteDetails($site_id)) Output::__outputStatus(1);

				if(!empty($schedule_id)){

						if($report=$this->TblMstepSiteScheduleReport->findByScheduleIdAndDelFlg($site_id,$schedule_id,0)){

								$res["data"]["site_report"]=$report["TblMstepSiteScheduleReport"]["report"];
						}
				}

				Output::__outputYes($res);
		}

		function __getSiteDetails($site_id) {

				if(!$site_detail=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0)){

						return false;
				}

				$this->TblMstepSiteSchedule->unbindFully();
				$schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);

				//[20161205] Hien Nguyen edit start
				if(!empty($schedules)) {

						$schedules=Set::extract($schedules,"{}.TblMstepSiteSchedule");
						$start_dates=array();
						foreach($schedules as $k=>$v){

								$start_dates[]=$v["start_date"];
						}

						array_multisort($start_dates,SORT_ASC,$schedules);

						$schedule_groups=array();
						$all_schedules=array_map(function($a){

								return date("Ymd",strtotime($a));

						},Set::extract($schedules,"{}.start_date"));
				}
				//[20161205] Hien Nguyen edit end
				
				//pref
				$tsv=new TSV();
				$pref_tsv=$tsv->getTSV("pref");

				// area.
				$pref="";
				$pref_id="";
				$middle_areas=array();
				$area_id=$site_detail["TblMstepSiteDetail"]["area_id"];
				if(!empty($area_id)){

						$area=$this->TblMstepAreaInformation->findById($area_id);
						$middle_areas=$this->__getAreas($area["TblMstepAreaInformation"]["pref_id"]);
						$pref=$pref_tsv[$area["TblMstepAreaInformation"]["pref_id"]];
						$pref_id=$area["TblMstepAreaInformation"]["pref_id"];
				}

				//customer
				$customer_name="";
				$customer_id=$site_detail["TblMstepSiteDetail"]["customer_id"];
				if(!empty($customer_id)){

						$customer=$this->TblMstepCustomer->findById($customer_id);
						$customer_name=$customer["TblMstepCustomer"]["name"];
				}

				$res["data"]["site_id"] =$site_detail["TblMstepSiteDetail"]["id"];
				$res["data"]["site_name"] =$site_detail["TblMstepSiteDetail"]["name"];
				$res["data"]["site_name_kana"] =$site_detail["TblMstepSiteDetail"]["name_kana"];
				$res["data"]["site_customer"] =$customer_name;
				$res["data"]["site_customer_id"] =$customer_id;
				$res["data"]["site_area"] =$site_detail["TblMstepSiteDetail"]["area_id"];
				$res["data"]["site_address"] =$site_detail["TblMstepSiteDetail"]["address"];
				$res["data"]["site_remarks"] =$site_detail["TblMstepSiteDetail"]["remarks"];
				$res["data"]["site_ninku"] =$site_detail["TblMstepSiteDetail"]["power_num"];
				$res["data"]["site_color_id"] =$site_detail["TblMstepSiteDetail"]["color_id"];
				$res["data"]["site_pref"] =$pref;
				$res["data"]["site_pref_id"] =$pref_id;
				$res["data"]["schedules"]=$all_schedules ?? '';
				$res["data"]["area_informations"] =$middle_areas;
				return $res;
		}

		//delete site worker by site id
		function __deleteSiteWorkersBySiteId($site_id) {

				try {

						$v=array("del_flg"=>1);
						$c=array("TblMstepSiteWorker.site_id"=>$site_id,"TblMstepSiteWorker.del_flg"=>0);
						$this->TblMstepSiteWorker->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		//delete site worker by schedule id
		function __deleteSiteWorkersByScheduleId($schedule_id) {

				try {

						$v=array("del_flg"=>1);
						$c=array("TblMstepSiteWorker.schedule_id"=>$schedule_id,"TblMstepSiteWorker.del_flg"=>0);
						$this->TblMstepSiteWorker->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		//delete site schedule remark by schedule id
		function __deleteSiteScheduleRemarkByScheduleId($schedule_id) {

				try {

						$v=array("del_flg"=>1);
						$c=array("TblMstepSiteScheduleRemark.schedule_id"=>$schedule_id,"TblMstepSiteScheduleRemark.del_flg"=>0);
						$this->TblMstepSiteScheduleRemark->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		//delete site schedule truck by schedule id
		function __deleteSiteScheduleTruckByScheduleId($schedule_id) {

				try {

						$v=array("del_flg"=>1);
						$c=array("TblMstepScheduleTruck.schedule_id"=>$schedule_id,"TblMstepScheduleTruck.del_flg"=>0);
						$this->TblMstepScheduleTruck->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __deleteSiteScheduleBySiteId($site_id) {

				try{

						$v=array("del_flg"=>1);
						$c=array("TblMstepSiteSchedule.site_id"=>$site_id);
						$res=$this->TblMstepSiteSchedule->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __deleteSiteScheduleById($schedule_id) {

				try{

						$v=array("del_flg"=>1);
						$c=array("TblMstepSiteSchedule.id"=>$schedule_id);
						$this->TblMstepSiteSchedule->updateAll($v,$c);

				}catch(Exception $e){

						$res["message"]=$e->getMessage();
						$res["status"] =false;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function __initScheduleLog($data = array()) {

				App::uses("SiteManagesEditAuthoritiesController", "Controller");
				$controller = new SiteManagesEditAuthoritiesController();
				return $controller->__initScheduleLog($data);
		}

		function __getInformations($start,$end) {

				App::uses("SiteController", "Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));
				return $res;
		}

		function __getAreas($pref_id) {

				App::uses("ScheduleController", "Controller");
				$controller = new ScheduleController();
				$res = $controller->__getAreas($pref_id);
				return $res;
		}

		function __refreshNinku($dates){

				$res["status"]=true;
				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($dates);
				if(empty($inserts)) return $res;
				return $this->__multiInsert($this->TblMstepSiteWorker,$inserts);
		}

		function __getSiteNinkuSituations($site_ids=array()) {
	
				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

} //END class

?>
