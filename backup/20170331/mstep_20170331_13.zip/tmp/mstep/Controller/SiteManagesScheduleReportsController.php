<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */
App::uses('CakeEmail', 'Network/Email');

//require_once(dirname(ROOT).DS."sendgrid-php".DS."sendgrid-php.php");

class SiteManagesScheduleReportsController extends AppController{

		//public $components=array("SendGirdPlainText","Email");

        var $name = "SiteManagesScheduleReports";
        var $uses = [

				"TblMstepSiteDetail",
				"TblMstepCustomer",
				"TblMstepSiteSchedule",
				"TblMstepSiteRemarkTitle",
				"TblMstepWorker",
				"TblMstepCustomer",
				"TblMstepSiteScheduleRemark",
				"TblMstepAreaInformation",
				"TblMasterClientProfile"
        ];

		var $titles=array();
		var $informations=array();
		var $emptySpace=" ";

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

                	$titles=array_map(function($a){

                		$char=mb_detect_encoding($a);
                		return mb_convert_encoding($a,"UTF-8",$char);

                	},tsv("report_titles.tsv"));
			$this->titles=$titles;

		}

		function __setInformations($schedule_id){

				if(!$schedule=$this->TblMstepSiteSchedule->findByIdAndDelFlg($schedule_id,0)) return false;

				$site=$schedule["TblMstepSiteDetail"];
				$site_worker=$schedule["TblMstepSiteWorker"];
				$schedule=$schedule["TblMstepSiteSchedule"];
				$worker_ids=Set::extract($site_worker,"{}.worker_id");

				$customer="";
				if(!empty($site["customer_id"])){

						$this->TblMstepCustomer->unbindFully();
						$customer=$this->TblMstepCustomer->findById($site["customer_id"]);
						$customer=$customer["TblMstepCustomer"];
				}

				$this->TblMstepWorker->unbindFully();
				$workers=$this->TblMstepWorker->findAllById($worker_ids);
				$workers=Set::combine($workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker");

				//■remark
				$remark_titles=array();
				if($titles = $this->TblMstepSiteRemarkTitle->find('first')) $remark_titles=$titles["TblMstepSiteRemarkTitle"];
				if(empty($remark_titles)) $remark_titles=tsv("remark_titles.tsv");

				$schedule_remark_titles=array();
				if($schedule_remarks=$this->TblMstepSiteScheduleRemark->findByScheduleId($schedule_id)){

						$schedule_remark_titles=$schedule_remarks["TblMstepSiteScheduleRemark"];
				}
	
				$this->informations["site"]=$site;
				$this->informations["schedule"]=$schedule;
				$this->informations["customer"]=$customer;
				$this->informations["workers"] =$workers;
				$this->informations["remark_titles"]=$remark_titles;
				$this->informations["schedule_remarks"]=$schedule_remarks;
				return true;
		}

		function __makeParams($values){

				$schedule_values=$values["siteSchedule"]["value"];
				$schedule_value="{$schedule_values["y"]}年{$schedule_values["m"]}月{$schedule_values["d"]}日({$schedule_values["w"]})";
				$schedule_worker_value="";
				$schedule_worker_values=$values["scheduleWorker"]["value"];
				foreach($schedule_worker_values as $k=>$v){
				
						$schedule_worker_value.="{$v["first_name"]}{$v["last_name"]}({$v["nickname"]})";
						$schedule_worker_value.=" ";
				}

				$params=array(
				
				        "siteName_title"=>$values["siteName"]["title"],
			            "siteName_value"=>$values["siteName"]["value"],
			            "customerName_title"=>$values["customerName"]["title"],
			            "customerName_value"=>$values["customerName"]["value"],
			            "siteSchedule_title"=>$values["siteSchedule"]["title"],
			            "siteSchedule_value"=>$schedule_value,
			            "siteAddress_title"=>$values["siteAddress"]["title"],
			            "siteAddress_value"=>$values["siteAddress"]["value"],
			            "siteAddressMapUrl_title"=>$values["siteAddressMapUrl"]["title"],
			            "siteAddressMapUrl_value"=>$values["siteAddressMapUrl"]["value"],
			            "scheduleWorker_title"=>$values["scheduleWorker"]["title"],
			            "scheduleWorker_value"=>trim($schedule_worker_value),
			            "siteAddress_title"=>$values["siteAddress"]["title"],
			            "siteAddress_value"=>$values["siteAddress"]["value"],
				        "siteRemark_title"=>$values["siteRemark"]["title"],
			            "siteRemark_value"=>$values["siteRemark"]["value"],
				        "scheduleRemark1_title"=>$values["scheduleRemark1"]["title"],
			            "scheduleRemark1_value"=>$values["scheduleRemark1"]["value"],
					    "scheduleRemark2_title"=>$values["scheduleRemark2"]["title"],
			            "scheduleRemark2_value"=>$values["scheduleRemark2"]["value"],
					    "scheduleRemark3_title"=>$values["scheduleRemark3"]["title"],
			            "scheduleRemark3_value"=>$values["scheduleRemark3"]["value"],
				);

				return $params;
		}

		function __getSubject($values){

				$subject="【{$values["siteName"]["value"]}】"."({$values["siteSchedule"]["value"]["m"]}月{$values["siteSchedule"]["value"]["d"]}日)";
				return $subject;
		}

		/*
		 * from       : クライアント企業メールアドレス
		 * returnPath : エラーはサーバへ届ける(info@error.dandori-taro.com)
		 * replyTo    : クライアント企業メールアドレス(返信先メールアドレス)
		 * https://sendgrid.kke.co.jp/docs/User_Manual_JP/email_activity.html
		 * */
		function __sendMail($emails,$values,$params,$headers=array()){

				if(empty($emails)){

						$res["headers"]=$headers;
						return $res;
				}
		
				$subject=$params["subject"];
				$from   =$params["from"];
				$replyTo=$params["replyTo"];
				$to     =array_shift($emails);
				if(empty(trim($to))) return $this->__sendMail($emails,$values,$params,$headers);

		        $Email=new CakeEmail("scheduleReport");
				$Email->returnPath(EMAIL_RETURN_PATH);
				$Email->subject($subject);
				$Email->from($from);
		        $Email->to($to);
		        if(!empty($replyTo)) $Email->replyTo($replyTo);
			    $Email->template("schedule_report",null);
			    $Email->emailFormat('text');
			    $Email->viewVars($values);
				$res=$Email->send();

				$count=count($headers);
				$headers[$count][$to]["header"]=$res["headers"];
				$headers[$count][$to]["message"]=$res["message"];
				return $this->__sendMail($emails,$values,$params,$headers);
		} 

		function sendScheduleReport(){

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				
				$schedule_id=$post["schedule_id"];
				$map_url=$post["map_url"];
				$this->__setInformations($schedule_id);
				$values=$this->__getReportInformations();
				$values["siteAddressMapUrl"]["title"]="現地詳細";
				$values["siteAddressMapUrl"]["value"]=$map_url;

				$this->TblMstepSiteSchedule->unbindFully();
				if(!$schedule=$this->TblMstepSiteSchedule->findByIdAndDelFlg($schedule_id,0)) Output::__outputNo();
				$site_id=$schedule["TblMstepSiteSchedule"]["site_id"];

				$this->TblMstepSiteDetail->unbindFully();
				$this->TblMstepCustomer->unbindFully();
				$site=$this->TblMstepSiteDetail->findById($site_id);
				$customer=CLIENT_DATA_SESSION;

				$subject=$this->__getSubject($values);
				$params=$this->__makeParams($values);
				$workers=$values["scheduleWorker"]["value"];
				$emails=Set::extract($workers,"{}.email");

				set_time_limit(EMAIL_TIMEOUT*count($emails));
				$res=$this->__sendMail($emails,$params,array(

						"subject"=>$subject,
						"from"   =>$customer["client_email"],
						"replyTo"=>$customer["client_email"]
				));

				Output::__outputYes();
		}

		function __getReportInformations(){

				$values=array();
				foreach($this->titles as $method=>$title){

						$__method="__{$method}";
						if(!method_exists($this,$__method)) continue;
						$value=$this->$__method($title);

						$val=$value["value"];
						if(is_string($val)) $val=addcslashes($val,"\\");
						$values[$method]["value"]=$val;
						$values[$method]["title"]=$value["title"];
				}

				return $values;
		}

		function scheduleReport(){

				$post=$this->data;
				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
				$schedule_id=$post["schedule_id"];
				//$schedule_id=8;
				if(!$this->__setInformations($schedule_id)) Output::__outputNo();
				$client_id=CLIENT_DATA_SESSION["id"];
				$profile=$this->TblMasterClientProfile->findById($client_id);
				$values=$this->__getReportInformations();
				$output["data"]["informations"]=$values;
				$output["data"]["customer"]["client_email"]=$profile["TblMasterClientProfile"]["client_email"];
				Output::__outputYes($output);
		}

		function __getScheduleRemarks($title,$num){

				$schedule_remarks=$this->informations["schedule_remarks"];
				$remark_titles=$this->informations["remark_titles"];
				$remark_title=empty($remark_titles["schedule_remark{$num}"])?$title:$remark_titles["schedule_remark{$num}"];
				$value=(isset($schedule_remarks["TblMstepSiteScheduleRemark"]["remarks{$num}"])?$schedule_remarks["TblMstepSiteScheduleRemark"]["remarks{$num}"]:"");
				$res["value"]=$value;
				$res["title"]=$remark_title;
				return $res;
		}

		function __scheduleRemark1($title){

				return $this->__getScheduleRemarks($title,1);
		}

		function __scheduleRemark2($title){

				return $this->__getScheduleRemarks($title,2);
		}

		function __scheduleRemark3($title){

				return $this->__getScheduleRemarks($title,3);
		}

		function __scheduleWorker($title){
		
				$names=array();
				$counter=0;
				$workers=$this->informations["workers"];
				foreach($workers as $worker_id=>$worker){

						$name="{$worker["first_name"]}{$worker["last_name"]}";
						$nickname=$worker["nickname"];
						$names[$counter]["first_name"]=$worker["first_name"];
						$names[$counter]["last_name"]=$worker["last_name"];
						$names[$counter]["nickname"]=$worker["nickname"];
						$names[$counter]["email"]=$worker["email"];
						$counter++;
				}

				$res["value"]=$names;
				$res["title"]=$title;
				return $res;
		}

		function __siteRemark($title){

				$remark_title=$this->informations["remark_titles"];
				$remark_title=$remark_title["site_remark1"];
				if(empty($remark_title)) $remark_title=$title;
				$remark=$this->informations["site"]["remarks"];
				$res["value"]=$remark;
				$res["title"]=$remark_title;
				return $res;
		}

		function __siteSchedule($title){
		
				$ym=$this->informations["schedule"]["start_month_prefix"];
				$day=$this->informations["schedule"]["start_day"];
				$time=strtotime($ym.sprintf("%02d",$day));
				$date=date("Y年m月d日",$time);
				$youbi=youbi(date("w",$time));
				$date.="({$youbi})";
				$res["value"]["y"]=date("Y",$time);
				$res["value"]["m"]=date("m",$time);
				$res["value"]["d"]=date("d",$time);
				$res["value"]["w"]=$youbi;
				$res["title"]=$title;
				return $res;
		}

		function __siteAddress($title){
		
				$this->TblMstepAreaInformation->unbindFully();
				$area_id=$this->informations["site"]["area_id"];

				$address="";
				if(!empty($area_id)){

						$area=$this->TblMstepAreaInformation->findById($area_id);
						$address=$area["TblMstepAreaInformation"]["pref"].$area["TblMstepAreaInformation"]["address1"];
						$address.=$this->informations["site"]["address"];
				}

				$res["value"]=$address;
				$res["title"]=$title;
				return $res;
		}

		function __customerName($title){
		
				$name=((isset($this->informations["customer"]["name"]))?$this->informations["customer"]["name"]:"");
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

		function __siteName($title){

				$name=$this->informations["site"]["name"];
				$res["value"]=$name;
				$res["title"]=$title;
				return $res;
		}

}//END class

?>
