<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-15 10:14:45
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-09-19 17:33:07
 */

/**
*
*/
class GroupsUsersController extends AppController {
    var $name = 'GroupsUsers';
    var $uses = [
                "TblMstepMasterUser",
                "TblMstepGroupsUser"
        ];

    function beforeFilter() {
        parent::beforeFilter();
        $this->isAuthorized();
    }

    public function index() {
        v(__LINE__);
    }

    // public function admin_create_aros() {

    //     $aro = $this->Acl->Aro;
    //     $groups = $this->TblMstepGroupsUser->find('all');
    //     foreach ($groups as $group) {
    //         $aro->create();
    //         $aro->save(array(
    //             'alias' => $group['TblMstepGroupsUser']['name'],
    //             'model' => 'Group',
    //             'foreign_key' => $group['TblMstepGroupsUser']['id']
    //             ));
    //     }

    //     $users = $this->TblMstepMasterUser->find('all');
    //     foreach ($users as $user) {
    //         $aro->create();
    //         $aro->save(array(
    //             'parent_id' => $user['TblMstepMasterUser']['group_id'],
    //             'alias' => $user['TblMstepMasterUser']['first_name'],
    //             'model' => 'User',
    //             'foreign_key' => $user['TblMstepMasterUser']['id']
    //             ));
    //     }

    //     exit('susscess');
    // }

    function parentNode() {
        return null;
    }

}
