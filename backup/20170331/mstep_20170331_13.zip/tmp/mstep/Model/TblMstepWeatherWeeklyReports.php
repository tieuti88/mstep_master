<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-08-23 10:57:36
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-08-26 18:34:40
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepWeatherWeeklyReports extends AppModel{

    var $name = "TblMstepWeatherWeeklyReports";
    var $useTable = "tbl_mstep_weather_weekly_reports";
    var $primaryKey = "id";
	var $useDbConfig="master";

    /**
     * Gets rss_url list
     *
     * @param      null
     * @return     $rss_url list.
     */
    function getWeatherLink(){

        $w=null;
        $w["and"]["prefectural_capital_flg"] = 1;
        $f = "id, rss_url";
        $datas = $this->findAll($w, $f);
        $result = array();
        foreach ($datas as $k => $v) {
            $result[$v["TblMstepWeatherWeeklyReports"]["id"]]=$v["TblMstepWeatherWeeklyReports"]["rss_url"];
        }

        return $result;
    }

    /**
     * Get weather_id by pref_id
     *
     * @param      null
     * @return     $rss_url list.
     */
    function getWeatherIdByPrefId($pref_id){

        $w=null;
        $w["and"]["pref_id"] = $pref_id;
        $w["and"]["prefectural_capital_flg"] = 1;
        if(!$result = $this->findOne($w)) return false;
        return $result["TblMstepWeatherWeeklyReports"]['id'];
    }
}
