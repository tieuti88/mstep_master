<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleLog.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

App::uses('ScheduleBaseController','Controller');
class SiteManagesMemoController extends ScheduleBaseController{

        var $name = "SiteManagesMemo";
        var $uses = [

				"TblMstepMemo",
				"TblMstepMasterUser"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){
		}

		function saveMemoList(){

				if(!$this->isPostRequest()) exit;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
	
				$post=$this->data;
				$user_id  =$post["user_id"];
				$local_time_key=isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;
				$position_num=$post["position"];
				$memo     =$post["memo"];

				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				$memo_list=$this->TblMstepMemo->findAll();
				$position_ids=Set::combine($memo_list,"{n}.TblMstepMemo.id","{n}.TblMstepMemo.position_num");
				$id=in_array($position_num,$position_ids)?array_search($position_num,$position_ids):"";

				$save=array();
				if(!empty($id)) $save["id"]=$id;
				$save["memo"]             =$memo;
				$save["user_id"]          =$user_id;
				$save["position_num"]     =$position_num;
				if(!$this->TblMstepMemo->save($save)) Output::__outputNo(1);

				$last_edit_time=$this->__getRefreshLastEditTime();

				$output["memo_list"]=$this->__getMemoList();
				$output["last_edit_time"]=$last_edit_time;
				Output::__outputYes($output);
		}

		function __getMemoList(){
		
				if(!$memos=$this->TblMstepMemo->findAll()) return array();

				$res=array();
				foreach($memos as $k=>$v){
				
						$position=$v["TblMstepMemo"]["position_num"];
						$res[$position]["id"]      =$v["TblMstepMemo"]["id"];
						$res[$position]["memo"]    =$v["TblMstepMemo"]["memo"];
						$res[$position]["modified_ms"]=strtotime($v["TblMstepMemo"]["modified"])*1000;
				}

				return $res;
		}

}//END class

?>
