<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteManagesColorController extends AppController{

        var $name = "SiteManagesColor";
        var $uses = [

				"TblMstepColor",
				"TblMstepSiteSchedule"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
        }

		function __init(){

				//$this->unbindFully();
		}

        #
        # @author Akabane
        # @date 2011/05/07 14:44:59
        function beforeRender(){
        }

		function __getColorList(){

				if(!$colors=$this->TblMstepColor->findAll()) return array();
				return Set::combine($colors,"{n}.TblMstepColor.id","{n}.TblMstepColor.name");
		}

		function __saveScheduleColor($colors=array()){

				$count=0;
				$insert=array();
				foreach($colors as $schedule_id=>$color_id){

						$insert[$count]["id"]=$schedule_id;
						$insert[$count++]["color_id"]=$color_id;
				}

				try{

						$this->TblMstepSiteSchedule->multiInsert($insert);
				
				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

}//END class

?>
