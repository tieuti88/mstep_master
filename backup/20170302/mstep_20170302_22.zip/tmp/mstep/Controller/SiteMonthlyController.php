<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleGetLastEditSiteUser.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

class SiteMonthlyController extends AppController{

        var $name = "SiteMonthly";
		var $uses = [
		
				"TblMstepAreaInformation",
				"TblMstepSiteDetail"

		];
	
	public function isAuthorized($user) {
		
		// All registered users can view index and search staff
//		return true;
		if (in_array($this->action, array('index'))) {return true;}
		
		return parent::isAuthorized($user);
	}

        function beforeFilter(){

                parent::beforeFilter();

				// base informations.
				$firstname = $this->Auth->user("first_name");
				$this->set(compact("firstname"));
				$this->__init();
        }

		function __init(){

				$this->unbindFully();
		}

		function __getPeriod($date,$range=4,$format="Ym"){

				$base_ym=date("Ym",strtotime($date."01"));
				$base_time=strtotime($base_ym."01");
				$ym_dates[]=$base_ym;
				for($i=1;$i<$range;$i++){

						$ym_dates[]=date($format,strtotime("- {$i} month",$base_time));
						$ym_dates[]=date($format,strtotime("+ {$i} month",$base_time));
				}

				sort($ym_dates);
				return $ym_dates;
		}

		function getDateRange(){

				if(!$this->isPostRequest()) exit;

				$post=$_POST;
				$start=(!isset($post["start"]))?date("Ym01"):$post["start"];
				$end  =(!isset($post["end"]))?date("Ymt",strtotime($start)):$post["end"];
				$informations=$this->__getDateRange($start,$end);

				$res["data"]["informations"]=$informations;
				$res["status"] = "YES";
				Output::__output($res);
		}

		function getPrevInformations(){

				$post=$this->data;
				$start_date=$post["date"];
				$start_date=date("Ym",strtotime("- 3 month",strtotime($start_date."01")));

				$period=$this->__getPeriod($start_date);
				$informations=$this->__getDateRange((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$res["informations"]=$informations;
				$this->__outputYes($res);
		}

		function getNextInformations(){

				$post=$this->data;
				$start_date=$post["date"];
				$start_date=date("Ym",strtotime("+ 3 month",strtotime($start_date."01")));

				$period=$this->__getPeriod($start_date);

				$informations=$this->__getDateRange((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$res["informations"]=$informations;
				$this->__outputYes($res);
		}

		function getAddDateApi() {

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
	
				//$post["date"]="201608";
				$date  =isset($post["date"]) ?$post["date"]:date("Ym");
				$month =isset($post["month"])?$post["month"]:"6";

				$start =date("Ym01",strtotime($date."01"));
				$end   =date("Ymt",strtotime("+ {$month} month",strtotime($date."01")));
				$data=$this->__getInformations($start,$end);

				$edit_informations=array();
				if(!empty($data["data"]["site_ids"])){
				
						$site_ids=$data["data"]["site_ids"];
						$site_details=$this->TblMstepSiteDetail->findAllById($site_ids);
						$site_details=Set::combine($site_details,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail");

						//■edit informations.
						$instance=new ScheduleGetLastEditSiteUser($this);
						$instance->setSiteInformations($site_details);
						$edit_informations=$instance->getEditUsersInformations();
				}

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function getSubDateApi() {

				if(!$this->isPostRequest()) exit;

				//■基準日,何ヶ月分
				$post = $this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));
	
				$date =isset($post["date"])?$post["date"]:date("Ym");
				$month=isset($post["month"])?$post["month"]:"6";

				$end  =date("Ymt",strtotime($date."01"));
				$start=date("Ym01",strtotime("-{$month} month",strtotime($date."01")));
				$data=$this->__getInformations($start,$end);

				$edit_informations=array();
				if(!empty($data["data"]["site_ids"])){
				
						$site_ids=$data["data"]["site_ids"];
						$site_details=$this->TblMstepSiteDetail->findAllById($site_ids);
						$site_details=Set::combine($site_details,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail");

						//■edit informations.
						$instance=new ScheduleGetLastEditSiteUser($this);
						$instance->setSiteInformations($site_details);
						$edit_informations=$instance->getEditUsersInformations();
				}

				$informations=$data["informations"];
				$res["data"]["edit_informations"]=$edit_informations;
				$res["data"]["informations"]=$informations;
				$res["status"]="YES";
				Output::__output($res);
		}

		function __startDateArgesValidate($start_date){

				if(empty($start_date) OR !is_numeric($start_date) OR strlen($start_date)!=6) return false; 

				$year =substr($start_date,0,4);
				$month=substr($start_date,4,2);
				if(!checkDate($month,"01",$year)) return false;
				return true;
		}

		function index($start_date=""){

				if(!$this->__startDateArgesValidate($start_date)) $start_date=date("Ym");


				$user_id  =$this->Auth->user("id");
				$pref_id  =$this->Auth->user('pref_id');
				$period=$this->__getPeriod($start_date);

				$data=$this->__getInformations((min($period)."01"),date("Ymt",strtotime(max($period)."01")));
				$informations=$data["informations"];
				$site_ids=$data["data"]["site_ids"];

				$site_details=array();
				if(empty($site_ids))    $site_datas=$this->TblMstepSiteDetail->findAll();
				if(!empty($site_ids))   $site_datas=$this->TblMstepSiteDetail->findAllById($site_ids);
				if(!empty($site_datas)) $site_details=Set::combine($site_datas, "{n}.TblMstepSiteDetail.id", "{n}.TblMstepSiteDetail");
	
				$instance=new ScheduleGetLastEditSiteUser($this);
				$instance->setSiteInformations($site_details);
				$edit_informations=$instance->getEditUsersInformations();

				$site_ids=array();
				if(!empty($informations)) $site_ids=array_values(array_unique(array_filter(Set::classicExtract($informations,"{[a-zA-Z0-9-_.]}.0.site_detail.id"),"strlen")));
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$weather=$this->__getImageByWeatherDate($pref_id);

				//remark title
				$remark_titles=$this->__getRemarkTitles();

		        //prefs
				$tsv=new TSV();
				$prefs=$tsv->getTSV("pref");

				//color
				$color_list=$this->__getColorList(false);

				$last_modified_user=$this->__getLastModifiedInformations();
				$instance=ScheduleLog::getInstance($this);
				$last_edit_time =$instance->getLastEditTime();
				$last_start_user=$instance->getLastStartUser();
				$edit_time_expired_ms=$instance->getLastEditTimeExpireMs();

				$user_id=$this->Auth->user("id");
				$is_authority=$this->__checkAuthorityToEdit($user_id)?1:0;

				$weather      =json_encode($weather);
				$remark_titles=json_encode($remark_titles);
				$edit_informations=json_encode($edit_informations);
				$informations =json_encode($informations);
				$last_modified_user=json_encode($last_modified_user);
				$prefs        =json_encode($prefs);
				$color_list   =json_encode($color_list);
				$ninku_situations=json_encode($ninku_situations);

				$this->set(compact("remark_titles",
								   "informations",
								   "is_authority",
								   "edit_informations",
								   "last_modified_user",
								   "ninku_situations",
								   "last_edit_time",
								   "edit_time_expired_ms",
								   "last_start_user",
								   "weather",
								   "prefs",
								   "color_list",
								   "start_date",
								   "user_id"));
		}

		function __getRemarkTitles(){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				return $controller->__getRemarkTitles();
		}

		function __getInformations($start,$end){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));

				return $res;
		}

		function __getColorList($is_set){

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getColorList($is_set);
				return $res;
		}

        function __getImageByWeatherDate($user_pref_id) {

				App::uses("SiteManagesWeatherController","Controller");
				$controller=new SiteManagesWeatherController();
				$res=$controller->__getImageByWeatherDate($user_pref_id);
				return $res;
        }

        function __getLastModifiedInformations() {

				App::uses("SiteController","Controller");
				$controller=new SiteController();
				$res=$controller->__getLastModifiedInformations();
				return $res;
        }

		function __getSiteNinkuSituations($site_ids=array()) {
	
				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

		function __checkAuthorityToEdit($user_id){
	
				$time_key=$this->Session->read(TimeoutInvestigationKeys::makeTimeSesKey(UNIQUE_KEY));
	
				App::uses("SiteManagesEditAuthoritiesController","Controller");
				$controller=new SiteManagesEditAuthoritiesController();
				$is_edit=$controller->__checkAuthorityToEditWithDeadline($user_id,$time_key);
				return $is_edit;
		}

		function __getDateRange($start,$end){

				App::uses("SiteController","Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getDateRange($start,$end,$worker_id);
				return $res;
		}


}//END class

?>
