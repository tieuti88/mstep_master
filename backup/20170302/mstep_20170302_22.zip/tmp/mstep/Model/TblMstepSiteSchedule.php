<?php
/**
 * Application model for CakePHP.
 *
 * This file is application-wide model file. You can put all
 * application-wide model-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Model
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepSiteSchedule extends AppModel {

	var $name = "TblMstepSiteSchedule";
	var $useTable = "tbl_mstep_site_schedules";
	var $primaryKey = "id";

	public $hasMany = array(

		'TblMstepSiteWorker' => array(
			'className' => 'TblMstepSiteWorker',
			'foreignKey' => 'schedule_id',
			'conditions' => array('TblMstepSiteWorker.del_flg' => '0'),
			'order' => 'TblMstepSiteWorker.id DESC',
			'dependent' => true,
		),
		'TblMstepScheduleTruck' => array(
			'className' => 'TblMstepScheduleTruck',
			'foreignKey' => 'schedule_id',
			'conditions' => array('TblMstepScheduleTruck.del_flg' => '0'),
			'order' => 'TblMstepScheduleTruck.id DESC',
			'dependent' => true,
		),
	);
	public $belongsTo = array(
		'TblMstepSiteDetail' => array(
			'className' => 'TblMstepSiteDetail',
			'foreignKey' => 'site_id',
			'conditions' => array('TblMstepSiteDetail.del_flg' => '0'),
		),
	);

	//■get data from start_date
	function getTargetByDate($target_days = array()) {

		$w = null;
		$w["and"]["TblMstepSiteSchedule.del_flg"] = 0;
		$w["and"]["DATE_FORMAT(start_date,'%Y%m%d')"] = $target_days;
		return $this->findAll($w);
	}

	function getRangeDataBySiteId($site_id) {

		$f = array("MAX(start_date) as max", "MIN(start_date) as min");
		if (!$range = $this->findBySiteIdAndDelFlg($site_id, 0, $f)) {
			return array();
		}

		return $range[0];
	}

	function getScheduleBySiteId($id = null) {

		$datas = $this->findAllBySiteId($id);
		$result = array();
		foreach ($datas as $k => $v) {
			$result[$v["TblMstepSiteSchedule"]["start_date"]] = $v["TblMstepSiteSchedule"];
		}
		return $result;
	}

	//function getSiteScheduleByDate($dates=array(),$site_ids=array(),$del_flg=0){
	function getSiteScheduleByDate($dates=array(),$del_flg=0){

			if(empty($dates)) return array();

			$w=array();
			//$w["and"]["site_id"]=$site_ids;
			$counter=0;
			foreach($dates as $k=>$v){

					$s=strtotime($v);
					$w["and"]["or"][$counter]["and"]["start_month_prefix"]=date("Ym",$s);
					$w["and"]["or"][$counter++]["and"]["start_day"]=date("j",$s);
			}

			$w["and"]["TblMstepSiteSchedule.del_flg"]=$del_flg;
			return $this->findAll($w);
	}

		function updatePosition($values=array()){

				if(empty($values)) return;

				$counter=0;
				$inserts=array();
				foreach($values as $schedule_id=>$position){

						$inserts[$counter]["id"]=$schedule_id;
						$inserts[$counter++]["position_num"]=$position;
				}

				try{
				
						$this->multiInsert($inserts);

				}catch(Exception $e){
				
						$res["status"]=false;
						$res["message"]=$e->getMessage();
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function getScheduleByYmAndSiteWorker($target_ym,$worker_id,$f=array()){

				$current_recursive=$this->recursive;
				$this->recursive=1;
				$this->hasOne=array(
	
						'TblMstepSiteWorker'=>array(
	
								'className' => 'TblMstepSiteWorker',
								'foreignKey' => 'schedule_id',
						),
				);

				$w=null;
				$w["and"]["{$this->name}.start_month_prefix"]=$target_ym;
				$w["and"]["{$this->name}.del_flg"]=0;
				$w["and"]["TblMstepSiteWorker.worker_id"]=$worker_id;
				$w["and"]["TblMstepSiteWorker.del_flg"]=0;
				$data=$this->findAll($w,$f);
				if(empty($data)) $data=array();
				$this->recursive=$current_recursive;
				return $data;
		}

		function getStartDatesBySiteId($site_id){
		
				$target_dates=array();
				$this->unbindFully();
				$f=array("CONCAT(TblMstepSiteSchedule.start_month_prefix,TblMstepSiteSchedule.start_day) as start_date");
				if($site_schedules=$this->findAllBySiteIdAndDelFlg($site_id,0,$f)){

						$target_dates=Set::extract($site_schedules,"{}.0.start_date");
				}
				return $target_dates;
		}

		function getNinkuRefreshByScheduleId($schedule_id){

				$current_recursive=$this->recursive;
				$this->recursive=1;

				$this->unbindModel(array("belongsTo"=>array("TblMstepSiteDetail")),true);
				$this->unbindModel(array("hasMany"  =>array("TblMstepScheduleTruck")),true);

				$w=null;
				$w["and"]["{$this->name}.id"]=$schedule_id;
				$w["and"]["{$this->name}.del_flg"]=0;
				if(!$data=$this->findAll($w,array())) return array();

				$dates=array();
				foreach($data as $k=>$v){

						if(1>count($v["TblMstepSiteWorker"])) continue;
						$d=$v["TblMstepSiteSchedule"];
						$ymd=$d["start_month_prefix"].sprintf("%02d",$d["start_day"]);
						$dates[]=$ymd;
				}

				$this->recursive=$current_recursive;
				$dates=array_unique($dates);
				return $dates;
		}


		function getNinkuRefreshBySiteId($site_id){

				$current_recursive=$this->recursive;
				$this->recursive=1;

				$this->unbindModel(array("belongsTo"=>array("TblMstepSiteDetail")),true);
				$this->unbindModel(array("hasMany"=>array("TblMstepScheduleTruck")),true);

				$w=null;
				$w["and"]["{$this->name}.site_id"]=$site_id;
				$w["and"]["{$this->name}.del_flg"]=0;
				$f=array("TblMstepSiteSchedule.start_month_prefix","TblMstepSiteSchedule.start_day");
				if(!$data=$this->findAll($w,array())) return array();

				$dates=array();
				foreach($data as $k=>$v){

						if(1>count($v["TblMstepSiteWorker"])) continue;
						$d=$v["TblMstepSiteSchedule"];
						$ymd=$d["start_month_prefix"].sprintf("%02d",$d["start_day"]);
						$dates[]=$ymd;
				}

				$this->recursive=$current_recursive;
				$dates=array_unique($dates);
				return $dates;
		}

		function getSchedule($schedule_ids=array(),$del_flg=0,$f=array()){
	
				$current_recursive=$this->recursive;
				$this->recursive=-1;
	
				$w=null;
				$w["and"]["id"]=$schedule_ids;
				if(is_numeric($del_flg)) $w["and"]["del_flg"]=$del_flg;
				$workers=$this->findAll($w,$f);
				$this->recursive=$current_recursive;
				return $workers;
		}

}
