<?php
App::uses('AuthComponent', 'Controller/Component');

class TblMstepLogin extends AppModel {

    var $name = "TblMstepLogin";
    var $useTable = 'tbl_mstep_master_users';
    var $primaryKey = "id";

    public $validate = array(
        'login_id' => array(
            'nonEmpty' => array(
                'rule' => array('notEmpty'),
                'message' => 'A username is required',
                'allowEmpty' => false
            ) ),
        'login_pass' => array(
                'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'A password is required'
            ) )
    );

}

?>
