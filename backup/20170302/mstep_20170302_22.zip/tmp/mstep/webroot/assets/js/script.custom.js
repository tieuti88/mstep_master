$(document).ready(function() {
	$('.data-numeric').on('input', function (event) { 
	    this.value = this.value.replace(/[^0-9]/g, '');
	});
	$(document).scroll(function(event) {
		$('.navbar-inverse').css('left', '-'+$(document).scrollLeft()+'px');
	});
});