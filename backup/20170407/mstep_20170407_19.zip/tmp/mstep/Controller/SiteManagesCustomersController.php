<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

class SiteManagesCustomersController extends AppController{

        var $name = "SiteManagesCustomers";
        var $uses = [

				"TblMstepCustomer",
				"TblMstepAreaInformation"
        ];

        function beforeFilter(){

                parent::beforeFilter();
				$this->__init();
		}

		function __init(){
		}

		function getCustomerInformations(){

				$customer_ids=isset($_POST["customer_ids"])?$_POST["customer_ids"]:array();
				$customers=$this->__getCustomerInformations($customer_ids);
				$res["data"]["informations"]=$customers;
				Output::__outputYes($res);
		}

		function __getCustomerInformations($customer_ids){

				$this->TblMstepCustomer->unbindFully();
				if(!$all_customers=$this->TblMstepCustomer->getCustomers($customer_ids)) return array();

				$this->TblMstepAreaInformation->unbindFully();
				$all_area_ids=Set::extract($all_customers,"{}.TblMstepCustomer.area_id");
				$area_informations=$this->TblMstepAreaInformation->findAllById($all_area_ids);
				$address=Set::combine($area_informations,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation.address1");
				$prefs=Set::combine($area_informations,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation.pref");

				$res=array();
				foreach($all_customers as $k=>$v){

						$data=$v["TblMstepCustomer"];

						$label=$data["name"];
						$value=$label;
						if(!empty($data["area_id"])){

								$pref=$prefs[$data["area_id"]];
								$town=$address[$data["area_id"]];
								$other=$data["address"];
								$label.=(" "."{$pref}{$town}{$other}");
						}

						$res[$k]["label"]=$label;
						$res[$k]["value"]=$value;
						$res[$k]["id"]=$data["id"];
				}

				return $res;
		}

}//END class

?>
