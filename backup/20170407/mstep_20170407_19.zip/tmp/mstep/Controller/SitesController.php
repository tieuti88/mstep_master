<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-01 16:00:45
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-10-05 15:20:14
 */

class SitesController extends AppController {
    var $name='Sites';
    var $uses = [
            "TblMstepAreaInformation",
            "TblMstepCustomer",
            "TblMstepSiteDetail",
            "TblMstepSiteWorker",
            "TblMstepColor",
            "TblMstepSiteSchedule",
            "TblMstepWorker",
            "TblMsTepMasterUser",
            "TblMstepGroupWorker"
    ];

    function beforeFilter(){

            parent::beforeFilter();

            $this->isAuthorized();

			// base informations.
			$user_id  =$this->Auth->user("id");
			$client_id=$this->Auth->user("client_id");
			$this->set(compact("user_id","client_id"));
    }

    /**
     * get site list
     *
     * @param null;
     * @return array();
     */
    public function index() {

			// site details under my client_id.
			$client_id=$this->Auth->user("client_id");
			if(!$site_details=$this->__getSite($client_id)){
			
					$site_details=array();
					$this->set(compact("site_details"));
					return;
			}

			// area informations.
			$pref_tsv=tsv("pref.tsv");
			$area_ids=array_unique(Set::extract($site_details,"{}.TblMstepSiteDetail.area_id"));
			$all_areas=$this->TblMstepAreaInformation->findAllById($area_ids);
			$all_area_pref_id=Set::combine($all_areas,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation.pref_id");
			$all_area_address=Set::combine($all_areas,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation.address1");

			$site_schedules=array();
			$site_ids=Set::extract($site_details,"{}.TblMstepSiteDetail.id");
			if($__site_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_ids,0)){

					foreach($__site_schedules as $k=>$v){

							$site_schedules[$v["TblMstepSiteSchedule"]["site_id"]][]=$v["TblMstepSiteSchedule"]["start_date"];
							sort($site_schedules[$v["TblMstepSiteSchedule"]["site_id"]]);
					}
			}

			foreach($site_details as $k=>$v){

					// area informatios.
					$area_id=$v["TblMstepSiteDetail"]["area_id"];
					if(isset($all_area_pref_id[$area_id])){

							$pref_id=$all_area_pref_id[$area_id];
							$site_details[$k]["TblMstepSiteDetail"]["area_information"]["pref"]   =$pref_tsv[$pref_id];
							$site_details[$k]["TblMstepSiteDetail"]["area_information"]["address"]=$all_area_address[$area_id];
							$site_details[$k]["TblMstepSiteDetail"]["area_information"]["address1"]=$v["TblMstepSiteDetail"]["address"];
					}

					// worker informations.
					if(!isset($site_schedules[$v["TblMstepSiteDetail"]["id"]])) continue;
					foreach($site_schedules[$v["TblMstepSiteDetail"]["id"]] as $_k=>$date){

							$site_details[$k]["TblMstepSiteDetail"]["schedule_date"][]=date("n/j",strtotime($date));
					}
			}

			$this->set(compact("site_details"));
    }

    /**
     * Create new site
     *
     * @param null;
     * @return array();
     */
    public function add() {

        //■customers
        $customers = $this->TblMstepCustomer->getCustomerList();
        $customers = json_encode($customers);

        //■prefs
        $prefs = $this->TblMstepAreaInformation->getPref();
        $prefs = json_encode($prefs);

        //■areas
        $areas = $this->TblMstepAreaInformation->getAddress();
        $areas = json_encode($areas);

        //■groupWorkers
        $_groupWorkers = $this->TblMstepGroupWorker->findAllByDelFlg(0);
        $groupWorkers = Set::combine($_groupWorkers,"{n}.TblMstepGroupWorker.id","{n}.TblMstepGroupWorker.name");
        $groupWorkers = json_encode($groupWorkers);

        //■colors
        $colors = $this->getColors();

        $this->set(compact('customers', 'prefs', 'areas', 'colors', 'groupWorkers'));
    }

	function __getAreas($pref_id){

	    	$areas=$this->TblMstepAreaInformation->findAllByPrefId($pref_id);
        	$areas=Set::combine($areas,"{n}.TblMstepAreaInformation.id","{n}.TblMstepAreaInformation.address1");
			return $areas;
	}

    /**
     * Gets the areas.
     *
     * @param null
     * @return void
     */
    function getAreas(){

        	$pref_id=$_POST["pref_id"];
			$areas=$this->__getAreas($pref_id);
        	$this->__output($areas);
    }

    /**
     * Gets the colors.
     */
    function getColors() {

        if(!$colors=$this->TblMstepColor->findAll()) return array();
        $colors =  Set::combine($colors,"{n}.TblMstepColor.id","{n}.TblMstepColor.name");

        return json_encode($colors);
    }

    /**
     * { function_description }
     *
     * @return     array  ( description_of_the_return_value )
     */
    public function checkDate() {

        $res                    = [];
        $startDateTime          = $_POST["start_time"];
        $endDateTime            = $_POST["end_time"];
        $startUnitTime          = strtotime($startDateTime);
        $endUnitTime            = strtotime($endDateTime);

        $i = 0;
        $currentTime = $startUnitTime;
        while($currentTime < $endUnitTime) {

            $nextTime   = strtotime('+1 day', $currentTime);
            $start_time_schedule = date('Y-m-d H:i:s', $currentTime);

            if ($nextTime > $endUnitTime) {

                $end_time_schedule = date('Y-m-d H:i:s', $endUnitTime);
                $i = date('m/d', $currentTime);
                $res[$i]["schedule"] = $this->getWorkerByTimeSchedule($start_time_schedule, $end_time_schedule);
                $res[$i]["date"] = date('m/d', $currentTime);
                $res[$i]["start_schedule"] = $start_time_schedule;
                $res[$i]["end_schedule"] = $end_time_schedule;
                $res[$i]["count"] = $_POST["count"];
            } else {

                $end_time_schedule = date('Y-m-d H:i:s', $nextTime);
                $i = date('m/d', $currentTime) . ' - ' . date('m/d', $nextTime);
                $res[$i]["schedule"] = $this->getWorkerByTimeSchedule($start_time_schedule, $end_time_schedule);
                $res[$i]["date"] = date('m/d', $currentTime) . ' - ' . date('m/d', $nextTime);
                $res[$i]["start_schedule"] = $start_time_schedule;
                $res[$i]["end_schedule"] = $end_time_schedule;
                $res[$i]["count"] = $_POST["count"];
            }

            $currentTime = $nextTime;
        }

        $this->__output($res);
    }


    public function getWorker() {

        $group_id = $_POST["group_id"];
        $stTime = $_POST["start_schedule"];
        $endTime = $_POST["end_schedule"];
        $workers_list = $this->getWorkerByTimeSchedule($stTime, $endTime, $group_id);

        $this->__output($workers_list);
    }

    public function getWorkerByTimeSchedule($st_Time, $end_Time, $group_id=null) {

        $schedules = $this->TblMstepSiteSchedule->find('all', array(
            'fields' => array(
                'id',
                'site_id'
            ),
            'conditions' => array(
                'AND' => array(
                    'start_date <' => $end_Time,
                    'end_date >'   => $st_Time
                )
            )
        ));

        $w=null;
        $client_id = $this->TblMsTepMasterUser->getClientID($this->Auth->user('id'));
        $w["and"]["client_id"] = $client_id;

        if (isset($group_id)) {

            $w["and"]["group_id"] = $group_id;
        }
        $list_workers = [];

        if ($schedules) {

            $schedules=$this->___arrangeAry($schedules,$this->TblMstepSiteSchedule->primaryKey);
            $schedule_ids = Set::extract($schedules,"{}.id");
            $site_workers=$this->TblMstepSiteWorker->findAllByScheduleId($schedule_ids);

            if (!empty($site_workers)) {

                $site_workers=$this->__arrangeAry($site_workers,$this->TblMstepSiteWorker->primaryKey);

                $worker_ids = Set::extract($site_workers,"{}.worker_id");
                // Removes duplicate values in array
                $worker_ids = array_unique($worker_ids);
                // Get list worker_id
                $_worker_ids = $this->getWorker_Id();
                //Return list worker_id is not working
                $list_worker_ids = array_diff($_worker_ids, $worker_ids);

                $w["and"]["id"] = $list_worker_ids;
                $_list_workers=$this->TblMstepWorker->findAll($w);

                $list_workers = Set::combine($_list_workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker.first_name");

            } else {
                $_list_workers=$this->TblMstepWorker->findAll($w);
                $list_workers = Set::combine($_list_workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker.first_name");
            }

        } else {

            $_list_workers=$this->TblMstepWorker->findAll($w);
            $list_workers = Set::combine($_list_workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker.first_name");
        }

        return $list_workers;
    }

    function getWorker_Id() {

        $_workers = $this->TblMstepWorker->findAllByDelFlg(0);
        $_workers=$this->___arrangeAry($_workers,$this->TblMstepWorker->primaryKey);
        $_workersIds = Set::extract($_workers,"{}.id");

        return $_workersIds;
    }

    function ___arrangeAry($data=array(),$key){

            $res=array();
            foreach($data as $k=>$v){

                    $__data=current($v);
                    $res[$__data[$key]]=$__data;
            }

            return $res;
    }

	function __getSite($client_id){
	
			App::uses("SiteManagesController","Controller");
			$controller=new SiteManagesController();
			$res=$controller->__getSite($client_id);
			return $res;
	}

	function __checkIFSamePosition($targets=array(),$position){
	
			App::uses("SiteManagesController","Controller");
			$controller=new SiteManagesController();
			$res=$controller->__checkIFSamePosition($targets,$position);
			return $res;
	}

    /**
     * { function_description }
     */
    public function save() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;

		//$log_path=WWW_ROOT."post5.txt";
		//file_put_contents($log_path,serialize($post));
		//$post=unserialize(file_get_contents($log_path));
		//exit;

	    //$post = $_POST;
	    //begin transaction
	    $datasource  =$this->TblMstepSiteDetail->getDataSource();
	    $datasource->begin();
	
		$client_id=$post["client_id"];
		$user_id  =$post["user_id"];
	
	    $res = array();
	    $res['name']        = $post['site_name'];
	    $res['customer_id'] = $post['site_customer'];
	    $res['area_id']     = $post['site_area'];
	    $res['address']     = $post['site_address'];
	    $res['color']       = $post['site_color'];
	    $res['color_id']    = $post['site_color_id'];
	    $res['power_num']   = $post['site_power_num'];
	    $res['remarks']     = $post['site_remarks'];
	    $res['delivery']    = $post['site_truck_num'];
	    $this->TblMstepSiteDetail->create();
	    if(!$this->TblMstepSiteDetail->save($res)){
	
				Output::__outputStatus(5);
	    }
	
	    if (isset($post['site_schedule_data'])) {
	
	        $res_schedules = array();
	        $site_schedules_data = $post['site_schedule_data'];
	        $last_site_id = $this->TblMstepSiteDetail->getLastInsertId();
	
			// where start_date_prefix
			$all_schedule_start_dates=Set::extract($site_schedules_data,"{}.start_time_date");
			$all_schedule_start_dates=array_map(function($a){
	
					return date("Ymd",strtotime($a));
	
			},$all_schedule_start_dates);
	
			$position_ids=array();
			$site_details=$this->__getSite($client_id);
			$all_site_ids=Set::extract($site_details,"{}.TblMstepSiteDetail.id");
	
			if($current_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndStartDatePrefixAndDelFlg($all_site_ids,$all_schedule_start_dates,0)){
	
					foreach($current_schedules as $k=>$v) $position_ids[$v["TblMstepSiteSchedule"]["start_date_prefix"]][]=$v["TblMstepSiteSchedule"]["position_num"];
			}
	
	        foreach ($site_schedules_data as $_v) {
	
	            $res_schedules['start_date']    = $_v["start_time_date"];
				$res_schedules['start_date_prefix']= date("Ymd",strtotime($_v["start_time_date"]));
	            $res_schedules['end_date']      = $_v["end_time_date"];
	            $res_schedules['site_id']       = $last_site_id;
				$res_schedules['position_num']  = 0;
	
				// update
				if(isset($position_ids[$res_schedules['start_date_prefix']])){
	
						$newest_position=$this->__checkIFSamePosition($position_ids[$res_schedules['start_date_prefix']],0);
						$res_schedules['position_num']=$newest_position;
				}
				
	            $this->TblMstepSiteSchedule->create();
	            if(!$this->TblMstepSiteSchedule->save($res_schedules)){

					Output::__outputStatus(5);
	            }
	
	            if (isset($_v['power'])) {
	
	                $res_worker = array();
	                $site_schedules_workers = array();
	                $site_schedules_workers = $_v['power'];
	                $last_schedule_id = $this->TblMstepSiteSchedule->getLastInsertId();
	
	                foreach ($site_schedules_workers as $k_w => $v_w) {
	
	                    $res_worker['site_id']      = $last_site_id;
	                    $res_worker['schedule_id']  = $last_schedule_id;
	                    $res_worker['worker_id']    = $k_w;
	                    $res_worker['man_hour']     = $v_w;
	                    $this->TblMstepSiteWorker->create();
	                    if(!$this->TblMstepSiteWorker->save($res_worker)){
	
							Output::__outputStatus(5);
	                    }
	                }
	            }
	        }

            // end transaction
            $datasource->commit();
			Output::__outputYes();
        }
    }
}
