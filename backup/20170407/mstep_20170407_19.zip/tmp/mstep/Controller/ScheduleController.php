<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-01 16:00:45
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2017-03-31 10:04:15
 */
App::uses("SiteController", "Controller");
App::uses("SiteManagesCustomersController","Controller");
App::uses("SiteManagesSiteTmpSavesController","Controller");
App::uses("SiteManagesInformationRegistsController","Controller");

class ScheduleController extends AppController {

	var $name = 'Schedule';
	var $sendInformations=array();
	var $uses = [
		"TblMstepAreaInformation",
		"TblMstepCustomer",
		"TblMstepSiteDetail",
		"TblMstepSiteWorker",
		"TblMstepColor",
		"TblMstepSiteSchedule",
		"TblMstepWorker",
		"TblMstepMasterUser",
		"TblMstepGroupWorker",
		"TblMstepSiteScheduleRemark",
		"TblMstepScheduleTruck",
		"TblMstepTruck",
		"TblMstepSiteRemarkTitle"
	];

	function beforeFilter() {

		parent::beforeFilter();

		$this->__init();

		// base informations.
		$user_id = $this->Auth->user("id");
		$this->set(compact("user_id"));
	}

	function __init(){

		if(!defined("TMP_PREFIX")) define("TMP_PREFIX","TMP_");
	}

	/**
	 * Determines if authorized.
	 *
	 * @param      <type>   $user   The user
	 *
	 * @return     boolean  True if authorized, False otherwise.
	 */
	public function isAuthorized($user) {

		// All registered users can view,search
		// if ($this->action === 'index' || $this->action === 'searchCustomerByConditions') return true;

		return parent::isAuthorized($user);
	}

	/**
	 * get site list
	 *
	 * @param null;
	 * @return array();
	 */
	public function index() {

		$this->paginate = array(
	        'limit' => 20,
	        'conditions' => array('TblMstepSiteDetail.del_flg' => 0),
	        'order' => array(
	            'TblMstepSiteDetail.created' => 'desc'
	        )
	    );

		$this->TblMstepSiteDetail->unbindModel(
			array(
				'hasMany' => array('TblMstepSiteWorker'),
			)
		);

		$this->TblMstepCustomer->recursive = 2;

		//■schedule list
		$listSchedule = $this->paginate("TblMstepSiteDetail");

		//■remark
		$titleRemarks=$this->TblMstepSiteRemarkTitle->getRemarkTitles();

		//■color list
		$controller = new SiteController();
		$color_list = $controller->__getColorList(true);
		$color_list = json_encode($color_list);

		$customer_ids=isset($_POST["customer_ids"])?$_POST["customer_ids"]:array();
		$customers = $this->__getCustomerInformations($customer_ids);

		//■prefs
		$prefs = $this->TblMstepAreaInformation->getPref();
		$prefs = json_encode($prefs);

		//■schedule_remarks
		$remark_titles = $controller->__getRemarkTitles();
		$remark_titles = json_encode($remark_titles);
		$this->set(compact('listSchedule', 'prefs', 'color_list', 'remark_titles', 'titleRemarks', 'customers'));
	}

	/**
	 * Gets the areas.
	 *
	 * @param null
	 * @return void
	 */
	function getAreas() {

		if(!$this->isPostRequest()) exit;

		$pref_id = $_POST["pref_id"];
		$areas = $this->__getAreas($pref_id);

		$this->__output($areas);
	}

	function __getAreas($pref_id = null) {

		$areas = $this->TblMstepAreaInformation->findAllByPrefId($pref_id);
		$areas = Set::combine($areas, "{n}.TblMstepAreaInformation.id", "{n}.TblMstepAreaInformation.address1");
		return $areas;
	}

	/**
	 * Gets the colors.
	 */
	function getColors() {

		if (!$colors = $this->TblMstepColor->findAll()) return array();
		$colors = Set::combine($colors, "{n}.TblMstepColor.id", "{n}.TblMstepColor.name");
		return json_encode($colors);
	}

	/**
	 * view site detail
	 *
	 * @param      <type>  $id     The identifier
	 */
	public function detail($id = null) {

		$_month=date('Ym');
		if(isset($this->request->query['month'])){
			$_month=$this->request->query['month'];
		}

		$pos = strlen($_month)-2;
        $year = substr($_month, 0, $pos);
        $month = substr($_month, $pos);

        if(!is_numeric($year) || !is_numeric($month) || $year<=0 || $month<=0 || $month>12){
            throw new NotFoundException();
        }

        $month_prefix = $year . "/" . $month . "/" . "01";

		$_site = $this->TblMstepSiteDetail->findAllByIdAndDelFlg($id, 0);
		if (!$_site || !is_numeric($id)) throw new NotFoundException();

		$site = $_site[0];
		$schedules = $this->getScheduleBySiteIdAndMonth($id, $_month);

		//■customers
		$customer_ids=isset($_POST["customer_ids"])?$_POST["customer_ids"]:array();
		$customers = $this->__getCustomerInformations($customer_ids);

		//■remark
		$remarks = $this->TblMstepSiteRemarkTitle->findAll();

		//■color list
		$controller = new SiteController();
		$color_list = $controller->__getColorList(true);
		$color_list = json_encode($color_list);

		//■prefs
		$prefs = $this->TblMstepAreaInformation->getPref();
		$prefs = json_encode($prefs);

		//■schedule_remarks
		$remark_titles = $controller->__getRemarkTitles();
		$remark_titles = json_encode($remark_titles);

		$this->set(compact('site', 'schedules', 'customers', 'prefs', 'color_list', 'remark_titles', 'remarks', 'month_prefix'));
	}

	public function getSchedulesByMonth() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$site_id = $post["site_id"];
		$month = $post["start_month_prefix"];
		$schedules = $this->getScheduleBySiteIdAndMonth($site_id, $month);

		Output::__outputYes($schedules);
	}

	//get schedules by site id and month
	protected function getScheduleBySiteIdAndMonth($site_id, $month) {

		$this->TblMstepSiteSchedule->recursive = 2;
		$schedules = $this->TblMstepSiteSchedule->findAllBySiteIdAndStartMonthPrefixAndDelFlg($site_id, $month, 0);

		return $schedules;
	}

	/**
	 * Search worker by conditions
	 */
	function searchCustomerByConditions() {

		if(!$this->isPostRequest()) exit;

		//$log_path=$this->__getLogPath();
		//$post=unserialize(file_get_contents($log_path));

		$post = $_POST;
		$query = '';
		$schedule_all_ids 	= [];
		$site_name 			= $post["searchby_name"] ?? '';
		$customer_name 		= $post["searchby_customer"] ?? '';
		$pref_name 			= $post["searchby_pref"] ?? '';
		$area_name 			= $post["searchby_area"] ?? '';
		$address_name 		= $post["searchby_address"] ?? '';
		$start_date 		= $post["searchby_start"] ?? '';
		$end_date 			= $post["searchby_end"] ?? '';
		$site_remark 		= $post["searchby_remark"] ?? '';
		$remark1 			= $post["searchby_schedule_remark1"] ?? '';
		$remark2 			= $post["searchby_schedule_remark2"] ?? '';
		$remark3 			= $post["searchby_schedule_remark3"] ?? '';
		$free_keyword 		= $post["searchby_free_keyword"] ?? '';
		$around 			= $post["searchby_around_value"] ?? '';
		$conditions[] 		= "TblMstepSiteDetail.del_flg = 0";

		//■site name
		if (!empty($site_name)) array_push($conditions, " TblMstepSiteDetail.name LIKE '%" . $site_name . "%'");

		//■site customer
		if (!empty($customer_name)) array_push($conditions, $this->searchCustomer($customer_name));

		//■site pref
		if (!empty($pref_name)) array_push($conditions, $this->searchPref($pref_name));

		//■site area
		if (!empty($area_name)) array_push($conditions, $this->searchArea($area_name));

		//■site address
		if (!empty($address_name)) array_push($conditions, " TblMstepSiteDetail.address LIKE '%" . $address_name . "%'");

		//■site start day
		if (!empty($start_date) && empty($end_date)) array_push($conditions, $this->searchStartDate($start_date));

		//■site end day
		if (!empty($end_date) && empty($start_date)) array_push($conditions, $this->searchEndDate($end_date));

		//■site start day and end day
		if (!empty($start_date) && !empty($end_date)) array_push($conditions, $this->searchStartDateAndEndDate($start_date, $end_date));

		//■site remark
		if (!empty($site_remark)) array_push($conditions, " TblMstepSiteDetail.remarks LIKE '%" . $site_remark . "%'");

		//■around value
		if($around!='') array_push($conditions, " TblMstepSiteDetail.around_value = '" .$around. "'");

		//■site schedule remark 1
		if (!empty($remark1)) {

			$schedules1 = $this->searchScheduleRemark1($remark1);
			$schedule_ids = array_keys($schedules1);

			//initialization data for schedule_all_ids
			if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
			$schedule_all_ids = array_intersect($schedule_all_ids, $schedule_ids);
			$site_all_ids = array_values($schedules1);
			$query = " TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";

		 	array_push($conditions, $query);
		}

		//■site schedule remark 2
		if (!empty($remark2)) {

			$schedules2 = $this->searchScheduleRemark2($remark2);
			$schedule_ids = array_keys($schedules2);

			//initialization data for schedule_all_ids
			if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
			$schedule_all_ids = array_intersect($schedule_all_ids, $schedule_ids);
			$site_all_ids = array_values($schedules2);
			$query = " TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";

		 	array_push($conditions, $query);
		}

		//■site schedule remark 3
		if (!empty($remark3)) {

			$schedules3 = $this->searchScheduleRemark3($remark3);
			$schedule_ids = array_keys($schedules3);

			//initialization data for schedule_all_ids
			if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
			$schedule_all_ids = array_intersect($schedule_all_ids ,$schedule_ids);
			$site_all_ids = array_values($schedules3);
			$query = " TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";

			array_push($conditions, $query);
		}

		//■free keyword
		if (isset($post["searchby_free_keyword"]) && $post["searchby_free_keyword"] != null) {

			$sql_search = "(";
			$sql_search .= " TblMstepSiteDetail.name LIKE '%" . $free_keyword . "%'";
			$sql_search .= " OR TblMstepSiteDetail.address LIKE '%" . $free_keyword . "%'";
			$sql_search .= " OR TblMstepSiteDetail.remarks LIKE '%" . $free_keyword . "%'";

			//■site customer
			if($this->searchCustomer($free_keyword, false) !== false) $sql_search .= " OR" .$this->searchCustomer($free_keyword, false);

			//■site pref
			if($this->searchPref($free_keyword, false) !== false) $sql_search .= " OR" .$this->searchPref($free_keyword, false);

			//■site area
			if($this->searchArea($free_keyword, false) !== false) $sql_search .= " OR" .$this->searchArea($free_keyword, false);

			//■site schedule remark 1
			$schedule_1 = $this->searchScheduleRemark1($free_keyword, false);
			if($schedule_1 !== false) {

				$schedule_ids = array_keys($schedule_1);

				//initialization data for schedule_all_ids
				if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
				$schedule_all_ids = array_intersect($schedule_all_ids, $schedule_ids);
				$site_all_ids = array_values($schedule_1);
				$sql_search .= " OR TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";
			}

			//■site schedule remark 2
			$schedule_2 = $this->searchScheduleRemark2($free_keyword, false);
			if($schedule_2 !== false) {

				$schedule_ids = array_keys($schedule_2);

				//initialization data for schedule_all_ids
				if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
				$schedule_all_ids = array_intersect($schedule_all_ids, $schedule_ids);
				$site_all_ids = array_values($schedule_2);
				$sql_search .= " OR TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";
			}

			//■site schedule remark 3
			$schedule_3 = $this->searchScheduleRemark2($free_keyword, false);
			if($schedule_3 !== false) {

				$schedule_ids = array_keys($schedule_3);

				//initialization data for schedule_all_ids
				if(empty($schedule_all_ids)) $schedule_all_ids = $schedule_ids;
				$schedule_all_ids = array_intersect($schedule_all_ids, $schedule_ids);
				$site_all_ids = array_values($schedule_3);
				$sql_search .= " OR TblMstepSiteDetail.id IN ( " . implode(", ", $site_all_ids) . " )";
			}

			$sql_search .= ")";

			array_push($conditions, $sql_search);
		}

		if (!$sites = $this->TblMstepSiteDetail->findAll($conditions)) {

				Output::__outputStatus(8);
		};

		$res["data"]["sites"] = $sites;
		$res["data"]["schedule_ids"] = $schedule_all_ids;
		Output::__outputYes($res);
	}

	//■seaerch customer
	function searchCustomer($customer_name, $check=true) {

			$query = '';
			$w_cus[] = ["TblMstepCustomer.del_flg = 0"];
			array_push($w_cus, " TblMstepCustomer.name LIKE '%" . $customer_name . "%'");

			if (!$_customers = $this->TblMstepCustomer->findAll($w_cus)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			$__cus_ids = $this->isPrimaryKey($_customers, $this->TblMstepCustomer->primaryKey);
			$cus_ids = Set::extract($__cus_ids, "{}.id");

			$query =  " TblMstepSiteDetail.customer_id IN ( " . implode(", ", array_keys($cus_ids)) . " )";

			return $query;
	}

	//■search pref
	function searchPref($pref_name, $check=true) {

			$query = '';
			$w_pref = "TblMstepAreaInformation.pref LIKE '%" . $pref_name . "%'";

			if (!$_prefs = $this->TblMstepAreaInformation->findAll($w_pref)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			$__pref_ids = $this->isPrimaryKey($_prefs, $this->TblMstepAreaInformation->primaryKey);
			$pref_ids = Set::extract($__pref_ids, "{}.id");

			$query = " TblMstepSiteDetail.area_id IN ( " . implode(", ", array_keys($pref_ids)) . " )";

			return $query;
	}

	//■search area
	function searchArea($area_name, $check=true) {

			$query = '';
			$w_area = "TblMstepAreaInformation.address1 LIKE '%" . $area_name . "%'";

			if (!$_areas = $this->TblMstepAreaInformation->findAll($w_area)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			$__area_ids = $this->isPrimaryKey($_areas, $this->TblMstepAreaInformation->primaryKey);
			$area_ids = Set::extract($__area_ids, "{}.id");

			$query = " TblMstepSiteDetail.area_id IN ( " . implode(", ", array_keys($area_ids)) . " )";

			return $query;
	}

	//■search start date
	function searchStartDate($start_date) {

			$query = '';
			$w_start = "TblMstepSiteSchedule.del_flg = 0 AND TblMstepSiteSchedule.start_date >= " . " '" . $start_date . "' ";

			if (!$_schedules_start = $this->TblMstepSiteSchedule->findAll($w_start)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			$schedule_Start = $this->__arrangeAry($_schedules_start, $this->TblMstepSiteSchedule->primaryKey);
			if (!$__site_start_ids = Set::extract($schedule_Start, "{}.site_id")) Output::__outputStatus(1);

			//remove duplicate
			$site_start_ids = array_unique($__site_start_ids);

			$query =" TblMstepSiteDetail.id IN ( " . implode(", ", array_values($site_start_ids)) . " )";

			return $query;
	}

	//■search end date
	function searchEndDate($end_date) {

			$query = '';
			$w_end = "TblMstepSiteSchedule.del_flg = 0 AND TblMstepSiteSchedule.end_date <= " . " '" . $end_date . "' ";

			if (!$_schedules_end = $this->TblMstepSiteSchedule->findAll($w_end)) Output::__outputStatus(1);

			$schedule_end = $this->__arrangeAry($_schedules_end, $this->TblMstepSiteSchedule->primaryKey);
			if (!$__site_end_ids = Set::extract($schedule_end, "{}.site_id")) Output::__outputStatus(1);

			//remove duplicate
			$site_end_ids = array_unique($__site_end_ids);

			$query = " TblMstepSiteDetail.id IN ( " . implode(", ", array_values($site_end_ids)) . " )";

			return $query;
	}

	//■search start and end date
	function searchStartDateAndEndDate($start_date, $end_date) {

			$query = '';
			$w_end = "TblMstepSiteSchedule.del_flg = 0 AND TblMstepSiteSchedule.start_date >= " . " '" . $start_date . "' " . " AND TblMstepSiteSchedule.end_date <=" . " '" . $end_date . "' ";

			if (!$_schedules_all = $this->TblMstepSiteSchedule->findAll($w_end)) Output::__outputStatus(1);

			$schedules_all = $this->__arrangeAry($_schedules_all, $this->TblMstepSiteSchedule->primaryKey);
			if (!$__site_all_ids = Set::extract($schedules_all, "{}.site_id")) Output::__outputStatus(1);

			//remove duplicate
			$site_all_ids = array_unique($__site_all_ids);

			$query = " TblMstepSiteDetail.id IN ( " . implode(", ", array_values($site_all_ids)) . " )";

			return $query;
	}

	//search site schedule remark1
	function searchScheduleRemark1($remark1, $check=true) {

			$w_remark1 = "TblMstepSiteScheduleRemark.remarks1 LIKE '%" . $remark1 . "%' AND TblMstepSiteScheduleRemark.del_flg = 0";

			if (!$schedule_remarks = $this->TblMstepSiteScheduleRemark->findAll($w_remark1)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$schedule_ids = Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark.remarks1");

			if(!$schedule_ids = array_keys($schedule_ids)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$this->TblMstepSiteSchedule->unbindFully();
			if(!$schedules_all = $this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_ids, 0)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			if(!$schedules_alls = Set::combine($schedules_all,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.site_id")) return array();

			return $schedules_alls;
	}

	//search site schedule remark2
	function searchScheduleRemark2($remark2, $check=true) {

			$w_remark2 = "TblMstepSiteScheduleRemark.remarks2 LIKE '%" . $remark2 . "%' AND TblMstepSiteScheduleRemark.del_flg = 0";

			if (!$schedule_remarks = $this->TblMstepSiteScheduleRemark->findAll($w_remark2)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$schedule_ids = Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark.remarks2");

			if(!$schedule_ids = array_keys($schedule_ids)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$this->TblMstepSiteSchedule->unbindFully();
			if(!$schedules_all = $this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_ids, 0)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			if(!$schedules_alls = Set::combine($schedules_all,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.site_id")) return array();

			return $schedules_alls;
	}

	//search site schedule remark3
	function searchScheduleRemark3($remark3, $check=true) {

			$w_remark3 = "TblMstepSiteScheduleRemark.remarks3 LIKE '%" . $remark3 . "%' AND TblMstepSiteScheduleRemark.del_flg = 0";

			if (!$schedule_remarks = $this->TblMstepSiteScheduleRemark->findAll($w_remark3)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$schedule_ids = Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark.remarks3");

			if(!$schedule_ids = array_keys($schedule_ids)) {

				if($check) Output::__outputStatus(1);
				return false;
			}
			$this->TblMstepSiteSchedule->unbindFully();
			if(!$schedules_all = $this->TblMstepSiteSchedule->findAllByIdAndDelFlg($schedule_ids,0)) {

				if($check) Output::__outputStatus(1);
				return false;
			}

			$schedules_alls = Set::combine($schedules_all,"{n}.TblMstepSiteSchedule.id","{n}.TblMstepSiteSchedule.site_id");

			return $schedules_alls;
	}

	/**
	 * Gets the site by worker identifier.
	 */
	function getScheduleBySiteId() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$site_id = $post["site_id"];
		$currentDay = date("Y-m-d H:i:s");
		$conditions[] = "TblMstepSiteSchedule.site_id = " . $site_id . " AND TblMstepSiteSchedule.start_date >= " . "'" . $currentDay . "'" . " AND TblMstepSiteSchedule.del_flg = 0 ";
		$schedules = $this->TblMstepSiteSchedule->findAll($conditions);
		Output::__outputYes($schedules);
	}

	function registScheduleInformations() {

			if(!$this->isPostRequest()) exit;

			$post=$this->data;

			$user_id     =$post["user_id"];
			$site_id     =$post["site_id"];
			$schedule_id =$post["schedule_id"];
			$informations=$post["informations"];

			$all_schedule_ids=array_keys($informations);
			$schedule_ids=$this->__scheduleIDs($all_schedule_ids);
			$normal_schedule_ids=$schedule_ids["normal"];

			//set schedules.
			$this->__setSchedules($normal_schedule_ids);
			$this->__setInformations($informations);

			$worker_id_histories=$this->__workerRegistedIdHistory($all_schedule_ids);
			$truck_id_histories=$this->__truckRegistedIdHistory($all_schedule_ids);

			//begin transaction
      		$datasource=$this->TblMstepSiteWorker->getDataSource();
      		$datasource->begin();

			// worker.
			$this->__deleteBySiteId($this->TblMstepSiteWorker,$site_id);
			$site_worker_inserts=$this->__insertWorkerArray(array(

					"id_histories"=>$worker_id_histories,
					"site_id"     =>$site_id
			));

			// truck.
			$this->__deleteBySiteId($this->TblMstepScheduleTruck,$site_id);
			$site_truck_inserts=$this->__insertTruckArray(array(

					"id_histories"=>$truck_id_histories,
					"site_id"     =>$site_id
			));

			//color. remarks. primary key is schedule_id.
			$site_color_inserts =$this->__insertColorArray();
			$site_remark_inserts=$this->__insertRemarkArray();

			$res["status"]=true;
			if(!empty($site_worker_inserts)) $res=$this->__multiInsert($this->TblMstepSiteWorker,$site_worker_inserts);
			if(empty($res["status"])) Output::__outputStatus(1);

			$res["status"]=true;
			if(!empty($site_truck_inserts)) $res=$this->__multiInsert($this->TblMstepScheduleTruck,$site_truck_inserts);
			if(empty($res["status"])) Output::__outputStatus(1);

			$res["status"]=true;
			if(!empty($site_color_inserts)) $res=$this->__multiInsert($this->TblMstepSiteSchedule,$site_color_inserts);
			if(empty($res["status"])) Output::__outputStatus(1);

			$res["status"]=true;
			if(!empty($site_remark_inserts)) $res=$this->__multiInsert($this->TblMstepSiteScheduleRemark,$site_remark_inserts);
			if(empty($res["status"])) Output::__outputStatus(1);

			//commit transaction
			$datasource->commit();

			$schedule_worker_ids = $informations[$schedule_id]["workers"] ?? '';
			$schedule_truck_ids = $informations[$schedule_id]["trucks"] ?? '';

			//get list worker by schedule id
			$_workers=$this->TblMstepWorker->findAllByIdAndDelFlg($schedule_worker_ids, 0);
			$worker_names=Set::combine($_workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker.nickname");

			//get list truck by schedule id
			$_trucks=$this->TblMstepTruck->findAllByIdAndDelFlg($schedule_truck_ids, 0);
			$truck_names=Set::combine($_trucks,"{n}.TblMstepTruck.id","{n}.TblMstepTruck.name");

			$res["worker_names"]=array_values($worker_names);
			$res["truck_names"]=array_values($truck_names);

			Output::__outputYes($res);
	}

	//Update site
	function updateSite() {

		if(!$this->isPostRequest()) exit;

		$post=$this->data;

		if ($res = $this->__checkPostDataEmpty($post)) {
			Output::__outputStatus(1);
		}

		$res=$this->__updateSite($post);
		if(empty($res["status"])) Output::__outputStatus(1);

		$site_id  =isset($post["site_id"])?$post["site_id"]:"";
		$site_detail=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0);

		Output::__outputYes($site_detail);
	}

	function __updateSite($post) {

		$site_id  =isset($post["site_id"])?$post["site_id"]:"";
		$color_id=$post["site_color_id"];
		$schedule_enable_days = $post["schedule_dates"];
		$user_id  =$post["user_id"];

		//customer.
		if(!empty($site_id)){

				$site_detail=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0);
				if(!$customer_id=$site_detail["TblMstepSiteDetail"]["customer_id"]) {

						$res["status"]=false;
						return $res;
				}
		}

		//begin transaction
		$datasource=$this->TblMstepSiteDetail->getDataSource();
		$datasource->begin();

		//update site information
		if(!$site_information=$this->__saveSiteInformation($site_id,$user_id,$customer_id,$post)){

				$res["status"]=false;
				return $res;
		}

		//update customer information
		$customer_information=$this->__saveCustomer(array(

				"name"       =>$post["site_customer"],
				"customer_id"=>$customer_id,
		));

		//check customer information
		if(empty($customer_information)){

				$res["status"]=false;
				return $res;
		}

		//update schedule information
		$schedule_information=$this->__updateSchedule($site_id, $color_id, $schedule_enable_days);

		//check customer information
		if(empty($schedule_information)){

				$res["status"]=false;
				return $res;
		}

		//commit transaction
		$datasource->commit();

		$res["status"]=true;
		$res["data"]["site_id"] = $site_information["id"];

		return $res;
	}

	function __updateSchedule($site_id, $color_id, $schedule_enable_days) {

		if(isset($site_id)) {

				$all_site_schedules=$this->TblMstepSiteSchedule->findAllBySiteIdAndDelFlg($site_id,0);
				$registed_site_id_histories = $this->__getRegistedIdHistories($all_site_schedules);

				//get current day
				$current_days = array_keys($registed_site_id_histories);
		}

		//get all regist days
		$regist_days = $this->__getSeparatorRegistDays($schedule_enable_days, $current_days);

		$new_regist_dates = ($regist_days["new"]) ? $regist_days["new"] : "";
		$current_regist_dates = ($regist_days["current"]) ? $regist_days["current"] : "";
		$all_position_ids = $this->__getAllPositionNums($schedule_enable_days);

		$remove_regist_date_ids = $this->__checkScheduleDateRemove($registed_site_id_histories, $current_regist_dates);
		if(!empty($remove_regist_date_ids)) {

			foreach($remove_regist_date_ids as $k =>$schedule_id) {

				//update schedule information
				$save = array();
				$save["id"] = $schedule_id;
				$save["del_flg"] = 1;
				if (!$this->TblMstepSiteSchedule->save($save)) {

						$res["status"]=false;
						return $res;
				}
			}

		}

		if (!empty($new_regist_dates)) {

			//regist new days
			$insert_result = $this->__registNewSiteSchedule($new_regist_dates, array(

				"site_id"         =>$site_id,
				"position_num"    =>0,
				"color_id"        =>$color_id,
				"all_position_ids"=>$all_position_ids,
			));

			if(empty($insert_result["status"])){

					$res["status"]=false;
					return $res;
			}
		}

		$res = array();
		$res["status"]=true;
		return $res;
	}

	function __checkScheduleDateRemove($registed_site_id_histories, $current_regist_dates) {

		$res=array();
		foreach ($registed_site_id_histories as $key => $value) {

			if(!in_array($key, $current_regist_dates)) {

				array_push($res, $value);
			}
		}
		return $res;
	}

	/**
	 * [getWorkerReportBySchedule description]
	 *
	 */
	function getWorkerReportBySchedule() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$schedule_id = $post["schedule-id"];
		$res=array();

		$this->TblMstepSiteWorker->unbindModel(
			array('belongsTo' => array('TblMstepSiteSchedule', 'TblMstepSiteScheduleRemark', 'TblMstepSiteDetail'))
		);

		//schedule report by staff has assigned for site
		$scheduleReports = "";
		$scheduleReports = $this->TblMstepSiteWorker->findAllByScheduleIdAndAssignFlgAndDelFlg($schedule_id, 1, 0);

		//schedule report by staff has not assigned for site
		$scheduleReportOthers = "";
		$scheduleReportOthers = $this->TblMstepSiteWorker->findAllByScheduleIdAndAssignFlgAndDelFlg($schedule_id, 0, 0);

		$res["scheduleReports"] = $scheduleReports;
		$res["scheduleReportOthers"] = $scheduleReportOthers;

		Output::__outputYes($res);
	}

	/**
	 * [getWorkerReportBySchedule description]
	 *
	 */
	function getManHourBySchedule() {

		if(!$this->isPostRequest()) exit;

		$post=$_POST;
		$schedule_id = $post["schedule-id"];

		$manHours = $this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_id, 0);

		Output::__outputYes($manHours);
	}

	function updateWorkerManHour() {

		if(!$this->isPostRequest()) exit;

		$man_hours = $_POST;

		if(!empty($man_hours)) {

			foreach($man_hours as $k =>$manhour) {

				//update manhour for staff
				$save = array();
				$save["id"] = $k;
				$save["man_hour"] = $manhour;
				if (!$this->TblMstepSiteWorker->save($save)) {

						Output::__outputNo();
				}
			}
		}

		Output::__outputYes();
	}

	/**
	 * [__checkPostDataEmpty description]
	 *
	 * @param  [type]     $post [description]
	 * @return [type]           [description]
	 */
	function __checkPostDataEmpty($post){

		$controller=new SiteManagesSiteTmpSavesController();
		$res=$controller->__checkPostDataEmpty($post);
		return $res;
	}

	/**
	 * [__saveSiteInformation description]
	 *
	 * @param  [type]     $site_id     [description]
	 * @param  [type]     $user_id     [description]
	 * @param  [type]     $customer_id [description]
	 * @param  [type]     $post        [description]
	 * @return [type]                  [description]
	 */
	function __saveSiteInformation($site_id,$user_id,$customer_id,$post){

		$controller=new SiteManagesSiteTmpSavesController();
		$res=$controller->__saveSiteInformation($site_id,$user_id,$customer_id,$post);
		return $res;
	}

	function __setInformations($informations=array()){

		$this->sendInformations=$informations;
	}

	function __workerRegistedIdHistory($schedule_ids=array()) {

		if(!$site_workers=$this->TblMstepSiteWorker->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();

		$ids=array();
		foreach($site_workers as $k=>$v){

				$data=$v["TblMstepSiteWorker"];
				$ids[$data["site_id"]][$data["schedule_id"]][$data["worker_id"]]=$data["id"];
		}

		return $ids;
	}

	function __truckRegistedIdHistory($schedule_ids=array()) {

		if(!$site_workers=$this->TblMstepScheduleTruck->findAllByScheduleIdAndDelFlg($schedule_ids,0)) return array();

		$ids=array();
		foreach($site_workers as $k=>$v){

				$data=$v["TblMstepScheduleTruck"];
				$ids[$data["site_id"]][$data["schedule_id"]][$data["truck_id"]]=$data["id"];
		}

		return $ids;
	}

	function __deleteBySiteId(Model $model,$site_id){

		$model->unbindFully();
		$conditions["del_flg"]=0;
		$conditions["site_id"]=$site_id;
		$model->updateAll(array("del_flg"=>1),$conditions);
	}

	function __insertWorkerArray($params=array()){

		$site_id     =$params["site_id"];
		$id_histories=$params["id_histories"];

		$counter=0;
		$inserts=array();
		foreach($this->sendInformations as $schedule_id=>$values){

				if(!isset($values["workers"])) continue;
				$worker_ids=$values["workers"];
				foreach($worker_ids as $k=>$worker_id){

						$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$worker_id])?$id_histories[$site_id][$schedule_id][$worker_id]:"");
						$inserts[$counter]["site_id"]=$site_id;
						$inserts[$counter]["schedule_id"]=$schedule_id;
						$inserts[$counter]["del_flg"]=0;
						$inserts[$counter++]["worker_id"]=$worker_id;
				}
		}

		return $inserts;
	}

	function __insertTruckArray($params=array()){

		$site_id     =$params["site_id"];
		$id_histories=$params["id_histories"];

		$counter=0;
		$inserts=array();
		foreach($this->sendInformations as $schedule_id=>$values){

				if(!isset($values["trucks"])) continue;
				$truck_ids=$values["trucks"];
				foreach($truck_ids as $k=>$truck_id){

						$inserts[$counter]["id"]=(isset($id_histories[$site_id][$schedule_id][$truck_id])?$id_histories[$site_id][$schedule_id][$truck_id]:"");
						$inserts[$counter]["site_id"]=$site_id;
						$inserts[$counter]["schedule_id"]=$schedule_id;
						$inserts[$counter]["del_flg"]=0;
						$inserts[$counter++]["truck_id"]=$truck_id;
				}
		}

		return $inserts;
	}

	function __scheduleIDs($schedule_ids=array()){

		$controller=new SiteManagesInformationRegistsController();
		$res=$controller->__scheduleIDs($schedule_ids);
		return $res;
	}

	function __setSchedules($schedule_ids=array()){

		$controller=new SiteManagesInformationRegistsController();
		$res=$controller->__setSchedules($schedule_ids);
		return $res;
	}

	function __insertOptionsArray(){

			$inserts=array();
			$counter=0;
			foreach($this->sendInformations as $schedule_id=>$v){

					if(!isset($v["options"]) OR $v["options"]["type"]==SCHEDULE_TYPE_NORMAL) continue;
					if(is_numeric(strpos($schedule_id,TMP_PREFIX))) continue;
					$type=$v["options"]["type"];
					$inserts[$counter]["id"]=$schedule_id;
					$s=strtotime($v["options"]["day"]);
					$inserts[$counter]["position_num"]=$v["options"]["position_num"];
					$inserts[$counter]["start_month_prefix"]=date("Ym",$s);
					$inserts[$counter]["start_day"]=date("j",$s);
					$inserts[$counter]["del_flg"]=(($type==SCHEDULE_TYPE_REMOVE)?1:0);
					$inserts[$counter++]["start_date"]=date("Y/m/d 00:00:00",$s);
			}

			return $inserts;
	}

	function __insertRemarkArray(){

			$counter=0;
			$inserts=array();
			foreach($this->sendInformations as $schedule_id=>$values){

					if(!isset($values["remarks"])) continue;
					$remarks=$values["remarks"];

					$inserts[$counter]["schedule_id"]=$schedule_id;
					if(isset($remarks["remarks1"])) $inserts[$counter]["remarks1"]=$remarks["remarks1"];
					if(isset($remarks["remarks2"])) $inserts[$counter]["remarks2"]=$remarks["remarks2"];
					if(isset($remarks["remarks3"])) $inserts[$counter]["remarks3"]=$remarks["remarks3"];
					$counter++;
			}

			return $inserts;
	}

	function __insertColorArray(){

			$counter=0;
			$inserts=array();
			foreach($this->sendInformations as $schedule_id=>$values){

					$inserts[$counter]["id"]=$schedule_id;
					$inserts[$counter++]["color_id"]=$values["color"];
			}

			return $inserts;
	}

	/**
	 * [__saveCustomer description]
	 *
	 * @param  [type]     $params [description]
	 * @return [type]             [description]
	 */
	function __getCustomerInformations($customer_ids){

			$controller=new SiteManagesCustomersController();
			$res=$controller->__getCustomerInformations($customer_ids);
			return $res;
	}

	/**
	 * [__saveCustomer description]
	 *
	 * @param  [type]     $params [description]
	 * @return [type]             [description]
	 */
	function __saveCustomer($params){

			$controller=new SiteManagesSiteTmpSavesController();
			$res=$controller->__saveCustomer($params);
			return $res;
	}

	/**
	 * [__getSeparatorRegistDays description]
	 *
	 * @param  [type]     $schedule_enable_days [description]
	 * @param  [type]     $current_days         [description]
	 * @return [type]                           [description]
	 */
	function __getSeparatorRegistDays($schedule_dates, $current_days) {

			$controller=new SiteManagesSiteTmpSavesController();
			$res=$controller->__getSeparatorRegistDays($schedule_dates, $current_days);
			return $res;
	}

	/**
	 * [__getAllPositionNums description]
	 *
	 * @param  [type]     $schedule_enable_days [description]
	 * @return [type]                           [description]
	 */
	function __getAllPositionNums($schedule_enable_days) {

			$controller=new SiteManagesSiteTmpSavesController();
			$res=$controller->__getAllPositionNums($schedule_enable_days);
			return $res;
	}

	function __registNewSiteSchedule($dates,$params) {

			$controller=new SiteManagesSiteTmpSavesController();
			$res=$controller->__registNewSiteSchedule($dates,$params,$insert_datas=array());
			return $res;
	}

	/**
	 * [__getRegistedIdHistories description]
	 *
	 * @param  [type]     $all_site_schedules [description]
	 * @return [type]                         [description]
	 */
	function __getRegistedIdHistories($all_site_schedules) {

		$registed_site_ids=array();
		foreach($all_site_schedules as $k=>$v){

				$data=$v["TblMstepSiteSchedule"];
				$registed_site_ids[$data["start_month_prefix"].sprintf("%02d",$data["start_day"])]=$data["id"];
		}
		return $registed_site_ids;
	}

}
