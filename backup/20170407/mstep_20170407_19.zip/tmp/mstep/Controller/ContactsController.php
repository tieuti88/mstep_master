<?php
App::uses('CakeEmail', 'Network/Email');

class ContactsController extends AppController {
    var $name = 'Contacts';
    var $uses = [
            'TblMstepMasterUser',
			"TblMasterClientProfile"
    ];
    var $viewAuth = ['index'];
    
    function beforeFilter() {
    
        parent::beforeFilter();
    }
    
    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {
    
        // All registered users can logout
//         if (in_array($this->action, $this->viewAuth)) {
//             return true;
//         }
    
        return parent::isAuthorized($user);
    }
	
	function index(){

		if($this->request->is("post")){

	    		 $post = $_POST;
	    		 $content = $post['content'];
	    		 $title = $post['title'];
	    		 
	    		 $emailFrom = $this->Auth->user("email");
	    		 $nameFrom = $this->Auth->user("first_name") . $this->Auth->user("last_name");
	    		 
	    		 $client_info = $this->Session->read('CLIENT_INFO');
				 $client_id=$client_info["id"];

				 if(!$client_profile=$this->TblMasterClientProfile->findById($client_id)) Output::__outputStatus(1);
				 $client_profile=$client_profile["TblMasterClientProfile"];

	    		 $subject = "問い合わせ(" . $client_profile['client_name'] . ")";
	    		 $clientTel = (isset($client_profile['client_tel']))? $client_profile['client_tel']:"";
	    		 $replyTo = (isset($client_profile['client_email']))? $client_profile['client_email']:"";
	    		 
// 	    		 $masterUser = $this->TblMstepMasterUser->findByDelFlgAndAuthority(0, 'master');
// 	    		 $mail_to = $masterUser['TblMstepMasterUser']['email'];
	    		 
	    		 $Email = new CakeEmail('contact');
	    		 $Email->from($replyTo);
	    		 //$Email->to($mail_to);
//				 $Email->to(EMAIL_TO);
				 //$Email->returnPath(EMAIL_RETURN_PATH);
	    		 $Email->subject($subject);
	    		 $Email->replyTo($replyTo);
				 $Email->template('default', null);
				 $Email->emailFormat('html');
				 $Email->viewVars(array(

				    	'nameFrom' => $nameFrom,
				    	'title' => $title,
				    	'emailFrom' => $emailFrom,
				    	'clientTel' => $clientTel
				 ));

	    		 if(!$Email->send($content)){

	    		    Output::__outputNo();
	    		 }
	    		 
	    		 Output::__outputYes();
		}
	}

}
