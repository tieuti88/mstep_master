<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

App::uses('ScheduleBaseController','Controller');
class SiteManagesPrintoutStaffDetailsController extends ScheduleBaseController{

        var $name = "SiteManagesPrintoutStaffDetails";
		var $uses = [
		
				"TblMstepSiteDetail",
				"TblMstepSiteWorker",
				"TblMstepSiteSchedule",
				"TblMstepWorker",
				"TblMstepSiteRemarkTitle",
				"TblMstepSiteScheduleRemark"
		];
	
        function beforeFilter(){

                parent::beforeFilter();
        }

		function __init(){

				$this->unbindFully();
		}

		function getPrintInformations(){

				$post=$_POST;

				if(!$this->isPostRequest()) exit;

				$worker_id=$post["worker_id"];
				//$worker_id=37;
				$ym=$post["ym"];
				//$ym="201702";

				if(!$worker=$this->TblMstepWorker->getWorkers(array($worker_id),false)) Output::__outputStatus(1);
				$worker=$worker[0]["TblMstepWorker"];

				$site_ids=array();
				$site_names=array();
				$reports_informations=array();
				$schedule_informations=array();
				$siteworker_informations=array();
				$schedule_remark_informations=array();
				if($site_workers=$this->TblMstepSiteWorker->getSiteWorkersByOnYmByWorkerId(array($worker_id),$ym)){

						$schedule_ids=Set::extract($site_workers,"{}.TblMstepSiteWorker.schedule_id");
						foreach($site_workers as $k=>$v){
						
								$ym=$v["TblMstepSiteSchedule"]["start_month_prefix"];
								$d =sprintf("%02d",$v["TblMstepSiteSchedule"]["start_day"]);
								$ymd=$ym.$d;
								$schedule_informations[$ymd][]=$v["TblMstepSiteSchedule"];
						}

						$siteworker_informations=Set::combine($site_workers,"{n}.TblMstepSiteWorker.schedule_id","{n}.TblMstepSiteWorker");
						//v($schedule_informations);
						$site_ids=array_values(array_unique(Set::extract($schedule_informations,"{n}.0.site_id")));
						$site_detail=$this->TblMstepSiteDetail->getWorkDetail($site_ids);
						$site_names=Set::combine($site_detail,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail.name");
						if($schedule_remarks=$this->TblMstepSiteScheduleRemark->getScheduleRemarks($schedule_ids)){

								$schedule_remark_informations=Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");
						}
				}

				$start=$ym."01";
				$end=$ym.sprintf("%02d",date("t",strtotime($start)));
				$range=$this->__makeDatePeriod($start,$end);

				$ranges[0]=$range;
				$ranges[1]=$range;
				foreach($range as $date=>$k){

						if(!isset($schedule_informations[$date])){

								continue;

								/*
								$ranges[0][$date][0]["site_detail"]=array();
								$ranges[0][$date][0]["site_worker"]=array();
								$ranges[0][$date][0]["schedule_remark"]=array();
								$ranges[1][$date][0]["site_detail"]=array();
								$ranges[1][$date][0]["site_worker"]=array();
								$ranges[1][$date][0]["schedule_remark"]=array();
								continue;
								*/
						}

						$schedule_information=$schedule_informations[$date];
						foreach($schedule_information as $k=>$v){

								$schedule_id=$v["id"];
								$site_id=$v["site_id"];
								$site_name=$site_names[$site_id];

								$assign_flg=$siteworker_informations[$schedule_id]["assign_flg"];
								if(!isset($ranges[$assign_flg][$date])) $ranges[$assign_flg][$date]=array();
								$count=count($ranges[$assign_flg][$date]);
								$ranges[$assign_flg][$date][$count]["site_detail"]["name"]=$site_name;
								$ranges[$assign_flg][$date][$count]["site_worker"]["ninku"]=$siteworker_informations[$schedule_id]["man_hour"];
								$ranges[$assign_flg][$date][$count]["site_worker"]["price"]=$worker["price"];
								$ranges[$assign_flg][$date][$count]["site_worker"]["allowance"]=$siteworker_informations[$schedule_id]["allowance"];
								$ranges[$assign_flg][$date][$count]["site_worker"]["report"]=$siteworker_informations[$schedule_id]["report"];

								$is_remarks=isset($schedule_remark_informations[$schedule_id]);
								$ranges[$assign_flg][$date][$count]["schedule_remark"]["remark1"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks1"]:"";
								$ranges[$assign_flg][$date][$count]["schedule_remark"]["remark2"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks2"]:"";
								$ranges[$assign_flg][$date][$count]["schedule_remark"]["remark3"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks3"]:"";
						}
				}

				$remark_titles=$this->TblMstepSiteRemarkTitle->getRemarkTitles();

				$output["data"]["information"]=$ranges;
				$output["data"]["worker"]["first_name"]=$worker["first_name"];
				$output["data"]["worker"]["last_name"] =$worker["last_name"];
				$output["data"]["remark_titles"]=$remark_titles;
				Output::__outputYes($output);
		}

		function __makeDatePeriod($start,$end){
	
				App::uses("SiteController", "Controller");
				$controller = new SiteController();
				$res = $controller->__makeDatePeriod($start,$end);
				return $res;
		}

}//END class

?>
