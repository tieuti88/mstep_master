<?php
/**
 * Application model for CakePHP.
 *
 * This file is application-wide model file. You can put all
 * application-wide model-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Model
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepScheduleTruck extends AppModel{

    var $name = "TblMstepScheduleTruck";
    var $useTable = "tbl_mstep_schedule_trucks";
    var $primaryKey = "id";

    public $belongsTo = array(
        'TblMstepTruck' => array(
            'className' => 'TblMstepTruck',
            'foreignKey' => 'truck_id',
        ),
    );

    function getTrucksNum($schedule_ids=array()){

        	$w=null;
        	$w["and"]["schedule_id"]=$schedule_ids;
        	$w["and"]["del_flg"]=0;
        	$w[]="1=1 group by schedule_id";
        	$f=array("COUNT(*) as count","schedule_id");
        	if(!$data=$this->findAll($w,$f)) return array();
        	return Set::combine($data,"{n}.{$this->name}.schedule_id","{n}.0.count");
    }

	function getScheduleTrucks($schedule_ids=array(),$del_flg=0,$f=array()){
	
			$current_recursive=$this->recursive;
			$this->recursive=-1;

			$w=null;
			$w["and"]["schedule_id"]=$schedule_ids;
			if(is_numeric($del_flg)) $w["and"]["del_flg"]=$del_flg;
			$site_trucks=$this->findAll($w,$f);
			$this->recursive=$current_recursive;
			return $site_trucks;
	}

	function deleteSiteTrucks($site_id,$schedule_ids=array()){

			$this->unbindFully();
			$conditions=array();
			if(!empty($schedule_ids)) $conditions["schedule_id"]=$schedule_ids;
			$conditions["site_id"]=$site_id;
			$conditions["del_flg"]=0;

			try{

					$this->updateAll(array("del_flg"=>1),$conditions);

			}catch(Exception $e){

					$res=array();
					$res["status"]=false;
					$res["message"]=$e->getMessage();
					return $res;
			}

			$res=array();
			$res["status"]=true;
			return $res;
	}

}

