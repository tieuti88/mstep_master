<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-09-13 14:30:33
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-09-13 14:36:49
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepMasterCustomersClient extends AppModel{

    var $name = "TblMstepMasterCustomersClient";
    var $useTable = "tbl_mstep_master_customers_client";
    var $primaryKey = "id";

}
