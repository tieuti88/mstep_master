<?php

echo phpinfo();
exit;


?>
