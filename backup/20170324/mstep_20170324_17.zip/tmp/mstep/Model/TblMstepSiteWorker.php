<?php
/**
 * Application model for CakePHP.
 *
 * This file is application-wide model file. You can put all
 * application-wide model-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Model
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepSiteWorker extends AppModel {

	var $name = "TblMstepSiteWorker";
	var $useTable = "tbl_mstep_site_workers";
	var $primaryKey = "id";

	public $belongsTo = array(
		'TblMstepWorker' => array(
			'className' => 'TblMstepWorker',
			'foreignKey' => 'worker_id'
		),

	      // Update 2016.12.13 Hung Nguyen start
	      // Add belongTo TblMstepSiteSchedule
        'TblMstepSiteSchedule' => array(
            'className' => 'TblMstepSiteSchedule',
            'foreignKey' => 'schedule_id'
        ),
        // Add belongTo TblMstepSiteScheduleRemark
        'TblMstepSiteScheduleRemark' => array(
            'conditions' => array('TblMstepSiteScheduleRemark.del_flg' => '0'),
            'className' => 'TblMstepSiteScheduleRemark',
            'foreignKey' => 'schedule_id'
        ),
        // Add belongTo TblMstepSiteDetail
        'TblMstepSiteDetail' => array(
                'conditions' => array('TblMstepSiteDetail.del_flg' => '0'),
                'className' => 'TblMstepSiteDetail',
                'foreignKey' => 'site_id'
        )
        // Update 2017.01.11 Hung Nguyen end
	);

	function deleteSiteWorkerBySiteID($site_id,$schedule_ids=array()){

			$res["status"]=true;
			if(!$data=$this->getSiteWorkerBySiteIdWithEnableWorker($site_id,$schedule_ids)) return $res;
			$all_site_worker_ids=Set::extract($data,"{}.{$this->name}.id");

			$w=null;
			$w["id"]=$all_site_worker_ids;
			$this->unbindFully();

			try{

					$this->updateAll(array("del_flg"=>1),$w);

			}catch(Exception $e){

					$res["status"]=false;
					$res["message"]=$e->getMessage();
					return $res;
			}

			return $res;
	}

	function getSiteWorkerBySiteIdWithEnableWorker($site_id,$schedule_ids=array()){

			$current_recursive=$this->recursive;
			$this->recursive=1;
			$this->belongsTo=array(

					'TblMstepWorker'=>array(

							'className' => 'TblMstepWorker',
							'foreignKey' => 'worker_id',
					),
			);

			$conditions=null;
			if(!empty($schedule_ids)) $conditions["and"]["TblMstepSiteWorker.schedule_id"]=$schedule_ids;
			$conditions["and"]["TblMstepSiteWorker.site_id"]=$site_id;

			//kiyosawa:03/18
			$conditions["and"]["TblMstepSiteWorker.assign_flg"]=1;
			$conditions["and"]["TblMstepWorker.del_flg"]=0;
			$data=$this->findAll($conditions);
			$this->recursive=$current_recursive;
			return $data;
	}

	function getSiteWorkersByOnYmByWorkerId($worker_ids=array(),$ym,$del_flg=0,$f=array()){
	
			$current_recursive=$this->recursive;
			$this->recursive=1;
			$this->belongsTo=array(

					'TblMstepSiteSchedule'=>array(

							'className' =>'TblMstepSiteSchedule',
							'foreignKey'=>'schedule_id',
					),
			);

			$w=null;
			$w["and"]["{$this->name}.worker_id"]=$worker_ids;
			if(is_numeric($del_flg)) $w["and"]["{$this->name}.del_flg"]=$del_flg;
			$w["and"]["TblMstepSiteSchedule.start_month_prefix"]=$ym;
			if(is_numeric($del_flg)) $w["and"]["TblMstepSiteSchedule.del_flg"]=$del_flg;
			$site_workers=$this->findAll($w,$f);
			$this->recursive=$current_recursive;
			return $site_workers;
	}

	function getSiteWorkers($schedule_ids=array(),$f=array()){
	
			$current_recursive=$this->recursive;
			$this->recursive=-1;
			$workers=$this->findAllByScheduleIdAndDelFlg($schedule_ids,0,$f);
			$this->recursive=$current_recursive;
			return $workers;
	}

}

?>
