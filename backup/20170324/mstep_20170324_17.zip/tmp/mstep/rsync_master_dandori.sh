#!/bin/sh

user="ec2-user"
to="13.112.169.136"
key="/home/mstep/stg/mstep_dev_web.pem"
dir="/home/mstep_master/html/web/"
target_dir="/home/mstep_master/html/web/"
file_prefix="mstep"

backup_tmp_base_dir="/tmp/"
backup_tmp_dir="${backup_tmp_base_dir}${file_prefix}/"

if [ ! -e $backup_tmp_dir ]; then

	mkdir $backup_tmp_dir
fi

backup_zip_base_dir="/home/mstep_master/backup/"
backup_dir=$backup_zip_base_dir`date "+%Y%m%d/"`

if [ ! -e $backup_dir ]; then

	mkdir $backup_dir
fi

backup_file="${backup_dir}${file_prefix}_`date "+%Y%m%d_%H.zip"`"
rsync -avz -e "ssh -p 22 -i ${key}" --exclude-from=/home/mstep_master/html/web/.rsync ${user}@${to}:${target_dir} ${backup_tmp_dir}

if [ ! $? -eq 0 ];then

	echo "error backup."
	exit 1
fi

zip -r $backup_file $backup_tmp_dir

rsync -avz -e "ssh -p 22 -i ${key}" --exclude-from=/home/mstep_master/html/web/.rsync ${dir} ${user}@${to}:${target_dir}

if [ ! $? -eq 0 ];then

	echo "error rsync"
	exit 1
fi

echo "backupfile:$backup_file"
exit 0
