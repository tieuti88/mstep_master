<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Minh Hung
 * @Date:   2016-11-03
 */

App::uses('SimplePasswordHasher', 'Controller/Component/Auth');
App::uses("StaffController", "Controller");

class AccountsController extends AppController {
	var $name = 'Account';
	var $uses = [
		'TblMstepMasterUser',
		'TblMstepAreaInformation',
        'TblMstepWorker',
        'TblMstepSiteWorker'
	];
	var $viewAuth = ['index', 'searchAccountByConditions', 'getListAuthority'];

	function beforeFilter() {

		parent::beforeFilter();

		if($this->Auth->user("authority") === "sub_master"){
		    $this->set('role', false);
		}
	}

	/**
	 * Determines if authorized.
	 *
	 * @param      <type>   $user   The user
	 *
	 * @return     boolean  True if authorized, False otherwise.
	 */
	public function isAuthorized($user) {

		// All registered users can logout
	    if($this->Auth->user("authority") === "sub_master"){
	        throw new unAuthorizedException();
	    }

		return parent::isAuthorized($user);
	}

	/**
	 * get account list
	 *
	 * @param null;
	 * @return array();
	 */
	public function index() {

		$this->paginate = array(
			'limit' => 20,
			'conditions' => array(
				'TblMstepMasterUser.del_flg' => '0'
			),
			'fields' => array(
				'id',
				'full_name',
			    'authority'
			),
	        'order' => array(
	                'TblMstepMasterUser.authority' => 'DESC'
	        )
		);

		$listUser = $this->paginate("TblMstepMasterUser");

		$authority = $this->getListAuthority();

		$this->set(compact('listUser', 'authority'));
	}

	/**
	 * Create new account
	 *
	 * @param null;
	 * @return array();
	 */
	public function add() {
		//prefs
		$prefs = $this->TblMstepAreaInformation->getPref();
		$prefs = json_encode($prefs);

		$_authority = $this->getListAuthority();
		//only show sub_mater
		unset($_authority['normal']);
		unset($_authority['master']);

		$authority = json_encode($_authority);

		$this->set(compact('prefs', 'authority'));
	}

	/**
	 * Create new account
	 *
	 * @param null;
	 * @return array();
	 */
	public function edit($id = null) {

		$_account = $this->TblMstepMasterUser->findAllByIdAndDelFlg($id, 0);

		if (!is_numeric($id) || !$_account) {
			throw new NotFoundException();
		}
		$account = $_account[0];

		//prefs
		$prefs = $this->TblMstepAreaInformation->getPref();
		$prefs = json_encode($prefs);

		//get areas
		if(!empty($account['TblMstepAreaInformation']['pref_id'])){
    		$_areas = $this->TblMstepAreaInformation->findAllByPrefId($account['TblMstepAreaInformation']['pref_id']);
    		$areas = Set::combine($_areas, "{n}.TblMstepAreaInformation.id", "{n}.TblMstepAreaInformation.address1");
		}else{
		    $areas = [];
		}
		$areas = json_encode($areas);

// 		$_authority = $this->getListAuthority();
// 		$authority = json_encode($_authority);


		$this->set(compact('account', 'prefs', 'areas'));
	}

	/**
	 * search account
	 *
	 * @param null
	 *
	 * @return list account
	 */
	function searchAccountByConditions() {
	    if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$res = array();
		$res["title"] = "アカウント";
		$res["message"] = "見つけられません。";

		$conditions[] = "TblMstepMasterUser.del_flg = 0";

		if (isset($post["search_name"]) && $post["search_name"] != null) {
			array_push($conditions, " CONCAT(TblMstepMasterUser.first_name, TblMstepMasterUser.last_name) LIKE '%" . $post['search_name'] . "%'");
		}

		if (isset($post["search_authority"]) && $post["search_authority"] != null) {
			array_push($conditions, " TblMstepMasterUser.authority = '" . $post['search_authority'] . "'");
		}

		if (isset($post["search_id"]) && $post["search_id"] != null) {
			array_push($conditions, " TblMstepMasterUser.id = " . intval($post['search_id']));
		}

		if (!$accounts = $this->TblMstepMasterUser->find('all', array(
		        'conditions' => $conditions,
		        'order' => array(
		                'TblMstepMasterUser.authority' => 'DESC'
		        )
		))) {

			Output::__outputStatus(9);
		}

		Output::__outputYes($accounts);
	}

	/**
	 * save data into database
	 */
	public function save() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;

		//$log_path=$this->__getLogPath();
		//$post=unserialize(file_get_contents($log_path));

		$data = [];
		$data['first_name']  = $post['first_name'];
		$data['last_name']   = $post['last_name'];
		$data['login_id']    = $post['user_name'];
		$data['login_pass']  = $post['account_password'];
		//$data['email']       = $post['account_email'];
		$data['area_id']     = $post['account_area'];
		$data['address']     = $post['account_address'];
		$data['authority']   = "sub_master";

		if($this->checkExistUserID($data['login_id'])){

				$output["error_status"]="USERID";
				Output::__output($output);
		}

// 		if(!empty($data['email'])){

//     			if($this->checkExistEmail($data['email'])){

//     					$output["error_status"] = "EMAIL";
//     					Output::__output($output);
//     					return;
//     			}
// 		}

		$this->TblMstepMasterUser->create();

		if (!$this->TblMstepMasterUser->save($data)) {

				Output::__outputStatus(5);
		}

		Output::__outputYes();
	}

	/**
	 * save data into database when edit account
	 */
	public function saveEdit() {

		if(!$this->isPostRequest()) exit;

		$post = $_POST;
		$_account = $this->TblMstepMasterUser->findAllByIdAndDelFlg($post["account_id"], 0);
		if (!$_account) {

			Output::__outputStatus(5);
			return;
		}
		$account = $_account[0];

		$data = [];
		if (isset($post['account_password'])) {
	// 		$passwordHasher = new SimplePasswordHasher(array('hashType' => 'sha1'));
	// 		$old_pass = $passwordHasher->hash($post['account_old_password']);
	// 		if ($account['TblMstepMasterUser']['login_pass'] == $old_pass) {
				$data['login_pass'] = $post['account_password'];
	// 		} else {
	// 			$output["status"] = "NO";
	// 			$output["message"] = "Wrong Password !";
	// 			$this->__output($output);
	// 			return;
	// 		}
		}

		$data['first_name'] = $post['first_name'];
		$data['last_name']   = $post['last_name'];
		$data['login_id']    = $post['user_name'];
		if(isset($post['account_email'])){
		  $data['email']       = $post['account_email'];
		}
		$data['area_id']     = $post['account_area'];
		$data['address']     = $post['account_address'];
		//$data['authority']   = $post['account_authority'];

		if($this->checkExistUserID($data['login_id'], $post["account_id"])){

				$output["error_status"]="USERID";
				Output::__output($output);
		}

		if(!empty($data['email'])){

    			if($this->checkExistEmail($data['email'], $post["account_id"])){

    					$output["error_status"] = "EMAIL";
    					Output::__output($output);
    					return;
    			}
		}

		$this->TblMstepMasterUser->id = $post["account_id"];

		if (!$this->TblMstepMasterUser->save($data)) {

			Output::__outputStatus(5);
		}

		Output::__outputYes();
	}

	/**
	 * delete account
	 *
	 * @param null
	 *
	 * @return null
	 */
	function deleteAccount() {
	    if(!$this->isPostRequest()) exit;

		$account_id = $_POST["account_id"];
		$account = $this->TblMstepMasterUser->findByIdAndDelFlg($account_id, 0);
		if (empty($account)) {
			Output::__outputStatus(5);
		}

		$datasource = $this->TblMstepMasterUser->getDataSource();
		$datasource->begin();

		if($account['TblMstepMasterUser']['worker_id'] > 0){
		    $this->deleteWorker($account['TblMstepMasterUser']['worker_id']);
		}

		// delete account
		$data = array();
		$data["id"] = $account_id;
		$data["del_flg"] = 1;
		if (!$this->TblMstepMasterUser->save($data)) {
			Output::__outputStatus(5);
		}

		$datasource->commit();
		Output::__outputYes();
	}

	//delete worker
	function deleteWorker($worker_id) {

	    if (!$this->TblMstepWorker->findByIdAndDelFlg($worker_id, 0)) Output::__outputStatus(5);

	    // delete worker information.
	    $currentDate = date("Y-m-d H:i:s");
	    $save = array();
	    $save["id"] = $worker_id;
	    $save["del_date"] = $currentDate;
	    $save["del_flg"] = 1;
	    if (!$this->TblMstepWorker->save($save)) Output::__outputStatus(5);

	    // delete workers.
	    $staffController = new StaffController();
	    $res = $staffController->__deleteSiteWorkersByWorkerId($worker_id, $currentDate);
	    if (!$res["status"]) Output::__outputStatus(5);
	}

	/**
	 * get list of authorities
	 *
	 * @param null
	 *
	 * @return null
	 */
	public function getListAuthority(){
	    $authority = [];
	    $table = 'tbl_mstep_master_users';
	    $field = 'authority';
	    $_type = $this->TblMstepMasterUser->query( "SHOW COLUMNS FROM {$table} WHERE Field = '{$field}'" );
	    $type = $_type[0]['COLUMNS']['Type'];
	    preg_match("/^enum\(\'(.*)\'\)$/", $type, $matches);
	    $_authority = explode("','", $matches[1]);
	    //$authority = Set::combine($_authority, "{n}.TblMstepSiteDetail.id", "{n}.TblMstepSiteDetail");
	    foreach($_authority as $auth){
	        $authority[$auth] = __($auth);
	    }

	    return $authority;
	}

	private function checkExistUserID($userID, $account_id = null){

	    $user = $this->TblMstepMasterUser->findByLoginIdAndDelFlg($userID, 0);

	    if(!empty($user)){
	        if(!empty($account_id)){
	            if($account_id == $user['TblMstepMasterUser']['id']){
	                return false;
	            }else{
	                return true;
	            }
	        }else{
	            return true;
	        }
	    }else{
	        return false;
	    }
	}

	private function checkExistEmail($email, $account_id = null){

	    $user = $this->TblMstepMasterUser->findByEmailAndDelFlg($email, 0);

	    if(!empty($user)){
	        if(!empty($account_id)){
	            if($account_id == $user['TblMstepMasterUser']['id']){
	                return false;
	            }else{
	                return true;
	            }
	        }else{
	            return true;
	        }
	    }else{
	        return false;
	    }
	}
}
