<?php

namespace Schedule;

class Errors {

		static $errorStatus = array(

				"0" => array("title" => "実行エラー", "message" => "【##USER##】が編集中です<br /><br />◯期間<br />〜##DEADLINE##<br /><br />◯環境<br />##USER_AGENT##"),
				"1" => array("title" => "実行エラー", "message" => "サーバ側の処理でエラーが発生致しました。時間を開けて再度実行するか管理者へお問い合わせ下さい"),
				"2" => array("title" => "実行エラー", "message" => "【##USER##】によりスケジュールの内容は既に更新されております。<br /><br />※画面をリロード致します."),
				"3" => array("title" => "実行エラー", "message" => "編集権限が他の方に移っています"),
				"4" => array("title" => "保存エラー", "message" => "選択された日程の中に上限を超えた日(MAX50)が存在致します"),
				"5" => array("title" => "保存エラー", "message" => "保存処理を試みましたが成功しませんでした。時間を開けて再度実行するか管理者へお問い合わせ下さい"),
				"6" => array("title" => "保存エラー", "message" => "同日に同じ現場が設定されております<br /><br /><span style='color:red;'>※処理が継続出来ない為画面をリロード致します.</span>"),
				"7" => array("title" => "保存エラー", "message" => "入力されたユーザIDは既に登録されております"),
				"8" => array("title" => "検索結果", "message"   => "検索内容に基づく情報が見つけられませんでした"),
				"9" => array("title" => "検索結果(アカウント検索)", "message"=>"検索内容に基づく情報が見つけられませんでした"),
				"10" => array("title" => "検索結果(顧客検索)", "message"=>"検索内容に基づく情報が見つけられませんでした"),
				"11" => array("title" => "検索結果(車両検索)", "message"=>"検索内容に基づく情報が見つけられませんでした"),
				"12" => array("title" => "保存エラー", "message" => "入力されたメールアドレスは既に登録されております"),
		);

		public static function changeCode($number,$changeCodes=array()){

		        $keys  =array_keys($changeCodes);
                $values=array_values($changeCodes);
				$error=Errors::$errorStatus[$number];
                $error["message"]=str_replace($keys,$values,$error["message"]);
				return $error;
		}
}

?>
