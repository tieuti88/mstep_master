<?php
/*
 * Copyright 2015 SPCVN Co., Ltd.
 * All right reserved.
*/

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-08-23 10:57:36
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2016-08-26 18:34:40
 */

App::uses('AppModel', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class TblMstepMemo extends AppModel{

    var $name = "TblMstepMemo";
    var $useTable = "tbl_mstep_memo";
    var $primaryKey = "id";
}
