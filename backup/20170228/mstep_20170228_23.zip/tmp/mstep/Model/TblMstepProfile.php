<?php

/**
 * Created by PhpStorm.
 * User: Edward
 * Date: 2/13/17
 * Time: 9:53 AM
 */
class TblMstepProfile extends AppModel {
	
	var $name='TblMstepProfile';
	var $useTable='client_profile';
	var $useDbConfig='master';
}