
create table tbl_spc_career_fare_tables(id int  auto_increment primary key,operator_id int not null,backbone_operator_id int not null,plan varchar(100) not null,plan_detail varchar(255) not null,data_amount_id int null,base_monthly_fee int not null,data_plan_fee int not null,net_connect_fee int not null,kakehodai_flg int not  null,share_flg int not null,created datetime not null,modified datetime not null) engine innodb charset=utf8;

create table tbl_spc_mvno_fare_tables(id int auto_increment primary key,operator_id int not null,backbone_operator_id int not null,plan varchar(100) not null,plan_detail varchar(255) not null,data_amount_id int null,base_start_fee int not null,base_monthly_fee int not null,option_sound_fee int not null,sim_max_allow_add_num int not null,sim_additional_fee int not null,sound_include_flg int not null,sound_include_detail longtext not null) engine innodb charset=utf8;

