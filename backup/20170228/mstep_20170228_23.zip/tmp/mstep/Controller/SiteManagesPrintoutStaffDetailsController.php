<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

App::uses('ScheduleBaseController','Controller');
class SiteManagesPrintoutStaffDetailsController extends ScheduleBaseController{

        var $name = "SiteManagesPrintoutStaffDetails";
		var $uses = [
		
				"TblMstepSiteDetail",
				"TblMstepSiteWorker",
				"TblMstepSiteSchedule",
				"TblMstepWorker",
				"TblMstepSiteRemarkTitle",
				"TblMstepSiteScheduleRemark"
		];
	
        function beforeFilter(){

                parent::beforeFilter();
        }

		function __init(){

				$this->unbindFully();
		}

		function getPrintInformations(){

				$post=$_POST;

				if(!$this->isPostRequest()) exit;

				$worker_id=$post["worker_id"];
				$ym=$post["ym"];

				if(!$worker=$this->TblMstepWorker->getWorkers(array($worker_id),false)) Output::__outputStatus(1);
				$worker=$worker[0]["TblMstepWorker"];

				$site_ids=array();
				$site_names=array();
				$reports_informations=array();
				$schedule_informations=array();
				$siteworker_informations=array();
				$schedule_remark_informations=array();
				if($site_workers=$this->TblMstepSiteWorker->getSiteWorkersByOnYmByWorkerId(array($worker_id),$ym)){

						$schedule_ids=Set::extract($site_workers,"{}.TblMstepSiteWorker.schedule_id");
						foreach($site_workers as $k=>$v){
						
								$ym=$v["TblMstepSiteSchedule"]["start_month_prefix"];
								$d =sprintf("%02d",$v["TblMstepSiteSchedule"]["start_day"]);
								$ymd=$ym.$d;
								$schedule_informations[$ymd]=$v["TblMstepSiteSchedule"];
						}

						$siteworker_informations=Set::combine($site_workers,"{n}.TblMstepSiteWorker.schedule_id","{n}.TblMstepSiteWorker");
						$site_ids=array_values(array_unique(Set::extract($schedule_informations,"{}.site_id")));
						$site_detail=$this->TblMstepSiteDetail->getWorkDetail($site_ids);
						$site_names=Set::combine($site_detail,"{n}.TblMstepSiteDetail.id","{n}.TblMstepSiteDetail.name");
						if($schedule_remarks=$this->TblMstepSiteScheduleRemark->getScheduleRemarks($schedule_ids)){

								$schedule_remark_informations=Set::combine($schedule_remarks,"{n}.TblMstepSiteScheduleRemark.schedule_id","{n}.TblMstepSiteScheduleRemark");
						}
				}

				$start=$ym."01";
				$end=$ym.sprintf("%02d",date("t",strtotime($start)));
				$range=$this->__makeDatePeriod($start,$end);

				foreach($range as $date=>$k){
				
						if(!isset($schedule_informations[$date])){

								$range[$date]["site_detail"]=array();
								$range[$date]["site_worker"]=array();
								$range[$date]["schedule_remark"]=array();
								continue;
						}

						$schedule_information=$schedule_informations[$date];
						$schedule_id=$schedule_information["id"];
						$site_id=$schedule_information["site_id"];
						$site_name=$site_names[$site_id];

						$range[$date]["site_detail"]["name"]=$site_name;
						$range[$date]["site_worker"]["ninku"]=$siteworker_informations[$schedule_id]["man_hour"];
						$range[$date]["site_worker"]["price"]=$worker["price"];
						$range[$date]["site_worker"]["allowance"]=$siteworker_informations[$schedule_id]["allowance"];
						$range[$date]["site_worker"]["report"]=$siteworker_informations[$schedule_id]["report"];

						$is_remarks=isset($schedule_remark_informations[$schedule_id]);
						$range[$date]["schedule_remark"]["remark1"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks1"]:"";
						$range[$date]["schedule_remark"]["remark2"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks2"]:"";
						$range[$date]["schedule_remark"]["remark3"]=($is_remarks)?$schedule_remark_informations[$schedule_id]["remarks3"]:"";
				}

				$remark_titles=$this->TblMstepSiteRemarkTitle->getRemarkTitles();

				$output["data"]["information"]=$range;
				$output["data"]["worker"]["first_name"]=$worker["first_name"];
				$output["data"]["worker"]["last_name"] =$worker["last_name"];
				$output["data"]["remark_titles"]=$remark_titles;
				Output::__outputYes($output);
		}

		function __makeDatePeriod($start,$end){
	
				App::uses("SiteController", "Controller");
				$controller = new SiteController();
				$res = $controller->__makeDatePeriod($start,$end);
				return $res;
		}

}//END class

?>
