<?php

/**
 * @Author: Nguyen Minh Hung
 * @Date:   2016-11-22
 */

require_once "Schedule".DS."ScheduleNinku.php";
App::uses("SiteManagesController", "Controller");

class CustomerController extends AppController {
    var $name = 'Customer';
    var $uses = [
            'TblMstepCustomer',
			'TblMstepSiteWorker',
            'TblMstepMasterUser',
            'TblMstepCustomerInchargeUser',
            'TblMstepSiteDetail',
            'TblMstepSiteSchedule',
            'TblMstepAreaInformation'
    ];
    var $viewAuth = ['index', 'detail', 'searchCustomerByConditions'];

    function beforeFilter() {

			//$siteManager = new SiteManagesController();
			//v(method_exists($siteManager,"deleteSiteById"));

        parent::beforeFilter();
    }

    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {

        // All registered users can logout
//         if (in_array($this->action, $this->viewAuth)) {
//             return true;
//         }

        return parent::isAuthorized($user);
    }
	public function index() {
	    $this->paginate = array(
	            'limit' => 20,
	            'conditions' => array('TblMstepCustomer.del_flg' => '0'),
	            'order' => array(
		            'TblMstepCustomer.created' => 'desc'
		        ),
	            'fields' => array(
                    'id',
                    'name',
                    'TblMstepMasterUser.first_name',
                    'TblMstepMasterUser.last_name'
                )
	    );

	    $this->TblMstepCustomer->unbindModel(

	            array(
	                    'belongsTo' => array('TblMstepCustomerInchargeUser'),
	                    'hasMany' => array('TblMstepSiteDetail')
	            )
        );

	    $listCustomer = $this->paginate("TblMstepCustomer");

	    $this->set(compact('listCustomer'));
	}

	/**
	 * search customer
	 *
	 * @param null
	 *
	 * @return list account
	 */
	function searchCustomerByConditions() {

	    if(!$this->isPostRequest()) exit;
	    $post = $_POST;
	    $res = array();
	    $res["title"] = "顧客";
	    $res["message"] = "見つけられません。";

		//$log_path=$this->__getLogPath();
		//$post=unserialize(file_get_contents($log_path));
	
	    $conditions[] = "TblMstepCustomer.del_flg = 0";

	    // Search name
	    if (isset($post["search_name"]) && $post["search_name"] != null) {
	        array_push($conditions, " TblMstepCustomer.name LIKE '%" . $post['search_name'] . "%'");
	    }

	    // Search master name
	    if (isset($post["search_master_name"]) && $post["search_master_name"] != null) {
	        array_push($conditions, " CONCAT(TblMstepMasterUser.first_name, TblMstepMasterUser.last_name) LIKE '%" . $post['search_master_name'] . "%'");
	    }

	    // Search free keyword
	    if (isset($post["search_keyword"]) && $post["search_keyword"] != null) {
	        $key_word = "(";
	        $key_word .= "TblMstepCustomer.name LIKE '%" . $post['search_keyword'] . "%'";
	        $key_word .= "OR TblMstepCustomer.remarks1 LIKE '%" . $post['search_keyword'] . "%'";
	        $key_word .= "OR TblMstepCustomer.remarks2 LIKE '%" . $post['search_keyword'] . "%'";
	        $key_word .= ")";
	        array_push($conditions, $key_word);
	    }

	    $this->TblMstepCustomer->unbindModel(
            array(
                    'belongsTo' => array('TblMstepCustomerInchargeUser'),
                    'hasMany' => array('TblMstepSiteDetail')
            )
	    );

	    if (!$accounts = $this->TblMstepCustomer->findAll($conditions)) {

	        	Output::__outputStatus(10);
	    }

	    Output::__outputYes($accounts);
	}

	/**
	 * delete customer
	 *
	 * @param null
	 *
	 * @return null
	 */
	function deleteCustomer() {

		//$log_path=$this->__getLogPath();
		//$post=unserialize(file_get_contents($log_path));
	    if(!$this->isPostRequest()) exit;

	    $customer_id = $_POST["customer_id"];

	    if (!$this->TblMstepCustomer->findByIdAndDelFlg($customer_id, 0)) {

	        Output::__outputStatus(1);
	    }

	    $datasource = $this->TblMstepCustomer->getDataSource();
	    $datasource->begin();

	    // delete site
		$site_ids=array();
	    $this->TblMstepSiteDetail->unbindFully();
	    if ($sites = $this->TblMstepSiteDetail->findAllByCustomerIdAndDelFlg($customer_id, 0)) {

	        $site_ids = Set::extract($sites, "{}.TblMstepSiteDetail.id");
			$target_dates=$this->TblMstepSiteSchedule->getNinkuRefreshBySiteId($site_ids);
	    }

	    // Check if exist sites
	    $sites = $this->TblMstepSiteDetail->findAllByCustomerIdAndDelFlg($customer_id, 0);
	    if(count($sites)>0){
	        Output::__outputStatus(1);
	    }

	    // delete customer
	    $save = array();
	    $save["id"] = $customer_id;
	    $save["del_flg"] = 1;
	    if (!$this->TblMstepCustomer->save($save)) {
	        //$datasource->rollback();
	        Output::__outputStatus(5);
	    }

	    // delete incharge user
	    $res = $this->__deleteInchargeUserByCustomerId($customer_id);
	    if (!$res["status"]) {
	        //$datasource->rollback();
	        Output::__outputStatus(5);
	    }

		// ninku count have to be refreshed with these days.
		if(!empty($site_ids) AND $target_dates=$this->TblMstepSiteSchedule->getNinkuRefreshBySiteId($site_ids)){

				if(!$this->__refreshNinku($target_dates)) Output::__outputStatus(1);
		}

	    $datasource->commit();
	    Output::__outputYes();
	}

	public function detail($id = null) {

	    $this->TblMstepSiteDetail->unbindModel(
	            array(
	                    'hasMany' => array('TblMstepSiteWorker'),
	                    'belongsTo' => array('TblMstepCustomer')
	            )
        );

	    $this->TblMstepCustomer->recursive = 2;
	    $_customer = $this->TblMstepCustomer->find('all', array(
	            'conditions' => array(
	                    'TblMstepCustomer.id' => $id,
	                    'TblMstepCustomer.del_flg' => 0
	               ),
	            'contains' => array(
	                    'TblMstepSiteDetail' => array('TblMstepSiteSchedule')
	                   )
	               )
	            );

	    if (!is_numeric($id) || !$_customer) {
	        throw new NotFoundException();
	    }
	    $customer = $_customer[0];

	    $this->set(compact('customer'));
	}

	// Delete Incharge User
	function __deleteInchargeUserByCustomerId($customer_id) {

	    try {

	        $this->TblMstepCustomerInchargeUser->updateAll(array("del_flg" => 1), array("customer_id" => $customer_id));

	    } catch (Exception $e) {

	        $res["message"] = $e->getMessage();
	        $res["status"] = false;
	        return $res;
	    }

	    $res["status"] = true;
	    return $res;
	}

	// Get site information by customer id
	function getSiteByCustomerId(){

			if(!$this->isPostRequest()) exit;
        	$customer_id = $_POST["customer_id"];
        	$this->TblMstepSiteDetail->unbindFully();
        	$sites = $this->TblMstepSiteDetail->findAllByCustomerIdAndDelFlg($customer_id, 0);
        	Output::__outputYes($sites);
    }

    /**
     * add new customer
     *
     * @param null
     *
     * @return null
     */
    function add($customer_id = null) {
        $customer = [];
        $select_pref = [];
        $pic_customer = [];
        if (!empty($customer_id)) {
            $this->TblMstepCustomer->unbindModel(
                    array(
                            'hasMany' => array('TblMstepSiteDetail')
                    )
                );

            if ($_customer = $this->TblMstepCustomer->findAllByIdAndDelFlg($customer_id, 0)) {
                $customer = $_customer[0];
            }

            if (!$customer || !is_numeric($customer_id)) {
                throw new NotFoundException();
            }

            $pic_customer = $this->TblMstepCustomerInchargeUser->findAllByCustomerIdAndDelFlg($customer_id, 0);
            $_select_pref = $this->TblMstepAreaInformation->findAllById($customer['TblMstepCustomer']['area_id']);
            if(!empty($_select_pref)){
                $select_pref = $_select_pref[0]['TblMstepAreaInformation']['pref_id'];
            }
        }

        // get master user

        $_masterUser = $this->__getUserMasterOrSubMaster();
        $masterUser = Set::combine($_masterUser, "{n}.TblMstepMasterUser.id", "{n}.TblMstepMasterUser.full_name");
        $masterUser = json_encode($masterUser);

        //get areas
        $_areas = $this->TblMstepAreaInformation->findAll();
        $areas = Set::combine($_areas, "{n}.TblMstepAreaInformation.id", "{n}.TblMstepAreaInformation.address1");
        $areas = json_encode($areas);

        //■prefs
        $prefs = $this->TblMstepAreaInformation->getPref();
        $prefs = json_encode($prefs);

        $this->set(compact('masterUser', 'customer', 'areas', 'pic_customer', 'prefs', 'select_pref'));
    }

    /**
     * Adds a customer.
     */
    function addCustomer() {

		if(!$this->isPostRequest()) exit;

        $post = $_POST;

        //begin transaction
        $datasource = $this->TblMstepCustomer->getDataSource();
        $datasource->begin();

        $customer = array();
        $pic = array();
        $customer['name'] = $post['name'];
        $customer['address'] = $post['address'];
        $customer['fax'] = $post['fax'];
        $customer['tel'] = $post['tel'];
        $customer['payment_close_date'] = $post['close_date'];
        $customer['payment_deadline_date'] = $post['deadline_date'];
        $customer['inchage_office_userid'] = $post['master_user'];
        $customer['area_id'] = $post['area'];
        $customer['remarks1'] = $post['remarks1'];
        $customer['remarks2'] = $post['remarks2'];

        // $pic_name = $this->convertName($post['pic_name']);

//         $pic['first_name'] = $post['pic_first_name'];
//         $pic['last_name'] = $post['pic_last_name'];
//         $pic['tel'] = $post['pic_phone'];
//         $pic['email'] = $post['pic_email'];
//         if(!empty($post["incharge_user_id"])){
//             $pic['incharge_id'] = $post["incharge_user_id"];
//         }

        if (!empty($post["customer_id"])) {
        //update customer
        $this->TblMstepCustomer->id = $post["customer_id"];
        } else {
        //add new customer
        $this->TblMstepCustomer->create();
        }

        if (!$this->TblMstepCustomer->save($customer)) {
        Output::__outputStatus(5);
        } else {
            if(empty($post["customer_id"])){
                $post["customer_id"] = $this->TblMstepCustomer->getLastInsertID();
            }
            $this->savePicUser($post);
            // remove about incharge_customer_userid
//             $post['customer_id'] = (!empty($post["customer_id"]))? $post["customer_id"] : $this->TblMstepCustomer->getLastInsertID();
//             $inchargeUser = $this->saveInchargeUser($pic);

//             if(!$inchargeUser){
//                 Output::__outputNo();
//             } else {
//                 $res['incharge_customer_userid'] = $inchargeUser;
//                 $this->TblMstepCustomer->id = $pic['customer_id'];

//                 if (!$this->TblMstepCustomer->save($res)) {
//                     Output::__outputNo();
//                 }
//             }
        }
        // end transaction
        $datasource->commit();

        Output::__outputYes();
    }

    function convertName($name){
        $res = [];
        if(!($pos = mb_strpos($name, "　", NULL, "UTF-8"))){
            if(!($pos = mb_strpos($name, " ", NULL, "UTF-8"))){
                $res['first_name'] = $name;
                $res['last_name'] = '';

                return $res;
            }
         }

         $res['first_name'] = mb_substr($name, 0, $pos);
         $res['last_name'] = mb_substr($name, $pos+1);

         return $res;
    }

    function saveInchargeUser($data){
        if(!empty($data['incharge_id'])){
            $this->TblMstepCustomerInchargeUser->id = $data['incharge_id'];
        } else {
            $this->TblMstepCustomerInchargeUser->create();
        }

        if (!$this->TblMstepCustomerInchargeUser->save($data)) {
            return false;
        }

        $incharge_id = (!empty($data['incharge_id']))? $data['incharge_id'] : $this->TblMstepCustomerInchargeUser->getLastInsertID();

        return $incharge_id;
    }

    function savePicUser($data){
        $arrPicUserIds = [];
        // edit pic user
        if(!empty($data['arrPicEdit'])){
            foreach($data['arrPicEdit'] as $arrEdit){
                array_push($arrPicUserIds, $arrEdit['id']);
                $pic=[];
                $pic['first_name'] = $arrEdit['first_name'];
                $pic['last_name'] = $arrEdit['last_name'];
                $pic['tel'] = $arrEdit['phone'];
                $pic['email'] = $arrEdit['email'];
                $this->TblMstepCustomerInchargeUser->id = $arrEdit['id'];
                if(!$this->TblMstepCustomerInchargeUser->save($pic)){
                    Output::__outputStatus(5);
                }
            }
        }

        // delete pic user
        if(count($arrPicUserIds)){
            $this->TblMstepCustomerInchargeUser->updateAll(array("TblMstepCustomerInchargeUser.del_flg" => 1), array(
                    "TblMstepCustomerInchargeUser.customer_id" => $data['customer_id'],
                    "TblMstepCustomerInchargeUser.id NOT IN" => $arrPicUserIds
                )
            );
        }else{
            $this->TblMstepCustomerInchargeUser->updateAll(array("TblMstepCustomerInchargeUser.del_flg" => 1), array(
                    "TblMstepCustomerInchargeUser.customer_id" => $data['customer_id']
                )
            );
        }

        // add pic user
        if(!empty($data['arrPicAdd'])){
            foreach($data['arrPicAdd'] as $arrAdd){
                $pic=[];
                $pic['customer_id'] = $data['customer_id'];
                $pic['first_name'] = $arrAdd['first_name'];
                $pic['last_name'] = $arrAdd['last_name'];
                $pic['tel'] = $arrAdd['phone'];
                $pic['email'] = $arrAdd['email'];
                $this->TblMstepCustomerInchargeUser->create();
                if(!$this->TblMstepCustomerInchargeUser->save($pic)){
                    Output::__outputStatus(5);
                }
            }
        }
    }


    function __getUserMasterOrSubMaster() {

        $users=array();
        $users=$this->TblMstepMasterUser->find('all', array(
            'conditions' => array(
                'del_flg' => 0,
                'OR' => array(
                    array(
                        'authority' => 'master'
                    ),
                    'authority' => 'sub_master'
                )
            )
        ));

        return $users;
    }

		function __refreshNinku($dates){

				$res["status"]=true;
				$instance=new ScheduleNinku($this);
				$inserts=$instance->getNinkInsertAry($dates);
				if(empty($inserts)) return $res;
				return $this->__multiInsert($this->TblMstepSiteWorker,$inserts);
		}

}
