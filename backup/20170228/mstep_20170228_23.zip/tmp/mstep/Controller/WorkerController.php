<?php
class WorkerController extends AppController {
    var $name = 'Worker';
    var $uses = [
            'TblMstepWorker',
            'TblMstepSiteSchedule',
            'TblMstepSiteWorker',
            'TblMstepSiteDetail'
    ];

    function beforeFilter() {

        parent::beforeFilter();
    }

    /**
     * Determines if authorized.
     *
     * @param      <type>   $user   The user
     *
     * @return     boolean  True if authorized, False otherwise.
     */
    public function isAuthorized($user) {

        // All registered users can logout
//         if ($this->action === 'index' || $this->action === 'searchWorkerByConditions') {
//             return true;
//         }

        return parent::isAuthorized($user);
    }
	public function index() {

//		$worker=$this->__getWorkerInformation();
//		$listWorkers=$worker['worker'];
		/**
		 * Edited by Ed
		 * @author duc.nguyen@spc-vn.com
		 * @date 2017-01-25
		 *
		 */
		$sites = $this->TblMstepSiteDetail->find('all', array(
			'conditions' => array(
				'TblMstepSiteDetail.del_flg' => 0
			),
			'order' => array(
				'TblMstepSiteDetail.id' => 'ASC'
			),
			'recursive' => 1
		));

	    $this->set(compact('sites'));
	}
	public function detail($worker_id) {

		/**
		 * Edited by Ed
		 * @auth duc.nguyen@spc-vn.com
		 * @date 2017-01-25
		 */
		if(!is_numeric($worker_id)){
			throw new NotFoundException();
		}
		/** End of edit */

		$this->TblMstepWorker->unbindFully();
		if(!$this->TblMstepWorker->findById($worker_id)){
			throw new NotFoundException();
		}else{
			$worker = $this->TblMstepWorker->findById($worker_id);
		}

		/** Edited by Ed <duc.nguyen@spc-vn.com>
		 * @auth duc.nguyen@spc-vn.com
		 * @date 2017-01-25
		 */
		$_month=date('Ym');
		if(isset($this->request->query['month'])){
			$_month=$this->request->query['month'];
		}
		/** End of edit */

		$pos = strlen($_month)-2;
        $year = substr($_month, 0, $pos);
        $month = substr($_month, $pos);

        if(!is_numeric($year) || !is_numeric($month) || $year<=0 || $month<=0 || $month>12){
            throw new NotFoundException();
        }

        $month_prefix = $year . "/" . $month . "/" . "01";

        $this->set(compact('month_prefix', 'worker'));
	}

	function searchWorkerByConditions(){
	    if(!$this->isPostRequest()) exit;

	    $post = $_POST;
	    $res = array();
	    $res["title"] = "Worker";
	    $res["message"] = "NOT FOUND";

		$conditions=[];
	    if (isset($post["searchby_name"]) && $post["searchby_name"] != null) {
	        array_push($conditions, " CONCAT(TblMstepWorker.first_name, TblMstepWorker.last_name) LIKE '%" . $post['searchby_name'] . "%'");
	    }

	    if(isset($post['site_name']) && $post['site_name']!='') {
	    	array_push($conditions, " TblMstepSiteDetail.name LIKE '%{$post['site_name']}%' OR TblMstepSiteDetail.name_kana LIKE '%{$post['site_name']}%'");
	    }

	    $page=(isset($post['page'])?$post['page']:1);

		$workers=$this->__getWorkerInformation($conditions,$page);
//		v($workers);
		if (!$workers) {

	        Output::__outputStatus(1);
	    }

	    Output::__outputYes($workers);
	}

	function __getWorkerInformation($conditions=array(), $page=1){
		$conditions[] = " TblMstepSiteWorker.del_flg = 0";
		$this->paginate = array(
			'limit' => 20,
			'conditions' => $conditions,
			'fields' => array(
				'TblMstepWorker.first_name',
				'TblMstepWorker.last_name',
				'TblMstepWorker.id'
			),
			'order' => array(
				'TblMstepWorker.id' => 'ASC'
			),
			'group'=>'TblMstepWorker.id',
			'page'=>$page
		);
//		v($this->paginate);

		$this->TblMstepSiteWorker->recursive = 1;
		$this->TblMstepWorker->unbindModel(
			array(
				'belongsTo' => 'TblMstepGroupWorker'
			));
		$this->TblMstepSiteWorker->unbindModel(
			array(
				'belongsTo' => array(
					'TblMstepSiteScheduleRemark',
					'TblMstepSiteSchedule'
				)
			));
		$listWorkers = $this->paginate("TblMstepSiteWorker");
		return array('worker'=>$listWorkers,'paging'=>$this->params['paging']['TblMstepSiteWorker']);
	}

	function getScheduleByMonth(){
	    if(!$this->isPostRequest()) exit;

	    $post = $_POST;
	    $worker_id = $post['worker_id'];
	    $month = $post['month_prefix'];
	    $assign_flg = $post['report_flg'];

	    $this->TblMstepWorker->unbindModel(
	            array(
	                    'belongsTo' => 'TblMstepGroupWorker'
	            ));
	    $this->TblMstepSiteSchedule->unbindModel(
	            array(
	                    'hasMany' => array(
	                            'TblMstepSiteWorker',
	                            'TblMstepScheduleTruck'
	                    )
	            ));
	    $workers = $this->TblMstepSiteWorker->find('all', array(
	            'conditions' => array(
	                    'TblMstepSiteWorker.worker_id' => $worker_id,
	                    'TblMstepSiteWorker.assign_flg' => $assign_flg,
	                    'TblMstepSiteWorker.del_flg' => 0,
	                    'TblMstepSiteSchedule.start_month_prefix' => $month
	            ),
	            'order' => array(
	                    'TblMstepSiteSchedule.start_date' => 'ASC'
	            ),
	            'recursive' => 2
	    ));

	    Output::__outputYes($workers);
	}

	function updateWorkerAllowance(){
	    if(!$this->isPostRequest()) exit;

	    $post = $_POST;

	    $worker_id = $post['worker_id'];
	    if(isset($post['allowance'])){
	       $allowances = $post['allowance'];

	       $this->TblMstepSiteWorker->unbindFully();
	       $datasource = $this->TblMstepSiteWorker->getDataSource();
	       $datasource->begin();

	       foreach($allowances as $allowance){
	           try{
	               !$this->TblMstepSiteWorker->updateAll(
	                       array(
	                               'allowance' => $allowance['allowance']
	                       ),
	                       array(
	                               'worker_id' => $worker_id,
	                               'schedule_id' => $allowance['schedule_id']
	                       )
	                       );
	           }
	           catch (Exception $e){
	               Output::__outputStatus(5);
	           }
	       }

	       $datasource->commit();
	       Output::__outputYes();

	    }else{

			Output::__outputYes();
	    }
	}
}
