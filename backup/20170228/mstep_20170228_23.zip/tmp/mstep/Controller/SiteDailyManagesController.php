<?php

require_once "Schedule".DS."ScheduleGetSiteID.php";
require_once "Schedule".DS."ScheduleGetCustomerInformation.php";
require_once "Schedule".DS."ScheduleLog.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

App::uses('ScheduleBaseController','Controller');
class SiteDailyManagesController extends ScheduleBaseController{

		var $name = "SiteDailyManages";
		var $uses = [

				"TblMstepSiteDetail",
				"TblMstepSiteSchedule",
				"TblMstepMasterUser"
		];

		function beforeFilter() {

				parent::beforeFilter();
				$this->__init();
		}

		function __init(){

				//$this->unbindFully();
		}

		function saveSchedule(){

				$post=$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				$user_id=$post["user_id"];
				$start_date =$post["start_date"];
				$end_date   =$post["end_date"];
				$around_values=isset($post["around_values"])?$post["around_values"]:array();
				$position_values=isset($post["options"]["position"])?$post["options"]["position"]:array();
				$local_time_key =isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;

				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				//transaction
				$datasource=$this->TblMstepSiteDetail->getDataSource();
				$datasource->begin();

				//around values.
				if(!empty($around_values)){
				
						$res=$this->TblMstepSiteDetail->updateAroundValues($around_values);
						if(empty($res["status"])) Output::__outputStatus(1);
				}

				// position values.
				if(!empty($position_values)){
				
						$res=$this->TblMstepSiteSchedule->updatePosition($position_values);
						if(empty($res["status"])) Output::__outputStatus(1);
				}

				$datasource->commit();

				// edit limited time.
				$last_edit_time=time();
				$instance=ScheduleLog::getInstance($this);
				if(!$instance->timeInitialize($user_id,$last_edit_time)) Output::__outputNo(1);
				$last_edit_time=($last_edit_time*1000);

				// new informations.
				$start_date=date("Y-m-d", strtotime($start_date));
				$end_date  =date("Y-m-d", strtotime($end_date));
				$informations = $this->__getInformations($start_date,$end_date);

				$site_ids=$informations["data"]["site_ids"];
				$ninku_situations=$this->__getSiteNinkuSituations($site_ids);

				$output["last_edit_time"]=$last_edit_time;
				$output["informations"]=$informations["informations"];
				$output["ninku_situations"]=$ninku_situations;
				Output::__outputYes($output);
		}

		function __getInformations($start,$end) {

				App::uses("SiteController", "Controller");
				$controller = new SiteController();
				$worker_id=$this->Auth->user("worker_id");
				$res=$controller->__getInformations($start,$end,array(
				
						"worker_id"=>$worker_id
				));
				return $res;
		}

		function __getSiteNinkuSituations($site_ids=array()) {
	
				App::uses("SiteManagesNinkuController", "Controller");
				$controller = new SiteManagesNinkuController();
				$res = $controller->__getSiteNinkuSituations($site_ids);
				return $res;
		}

} //END class

?>
