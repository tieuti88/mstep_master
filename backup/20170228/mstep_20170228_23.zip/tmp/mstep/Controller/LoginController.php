<?php
/*
 * Copyright 2015 SPC Viet Nam Co., Ltd.
 * All right reserved.
 */

/**
 * @Author: Nguyen Chat Hien
 * @Date:   2016-08-17 14:28:44
 * @Last Modified by:   Nguyen Chat Hien
 * @Last Modified time: 2017-02-27 17:27:21
 */

/**
 * Login Controller
 *
 */
App::uses('Folder', 'Utility');
App::uses('File', 'Utility');
class LoginController extends AppController {

		var $name = 'Login';
		var $uses = [
		        'TblMstepAreaInformation'
		];

		public function beforeFilter() {

				$this->Auth->allow('index');
		}

		/**
		 * Determines if authorized.
		 *
		 * @param      <type>   $user   The user
		 *
		 * @return     boolean  True if authorized, False otherwise.
		 */
		public function isAuthorized($user) {

				// All registered users can logout
				if ($this->action === 'logout') {
						return true;
				}

				return parent::isAuthorized($user);
		}

		public function index() {

				$this->layout='login';

				if($this->request->is("post")){

						$log_path=LOGS."login";
						$relpath =$log_path.DS."normal".DS."login.txt";
						if(!empty(CLIENT)) $relpath=$log_path.DS.CLIENT.DS."login.txt";;
						if (!file_exists($relpath)) $file = new File($relpath, true, 0777);

						$this->Session->destroy();
						if ($this->Auth->login()) {

								$data=array();
								$data["id"]=$this->Auth->user("id");
								$data["first_name"]=$this->Auth->user("first_name");
								$data["last_name"]=$this->Auth->user("first_name");
								$data["email"]=$this->Auth->user("email");
								$data["login_id"]=$this->Auth->user("login_id");
								$data["edit_time"]=date("Y/m/d h:i:sa");

								//write log
								@file_put_contents($relpath,serialize($data),FILE_APPEND);

								// Update 2017.01.12 Hung Nguyen start
								// write pref_id for session
								if(!$this->Session->check('Auth.User.pref_id')){
										$pref_id = $this->TblMstepAreaInformation->findById($this->Auth->user("area_id"));
										if($pref_id){
										  $this->Session->write('Auth.User.pref_id', $pref_id['TblMstepAreaInformation']['pref_id']);
										}
								}
								// Update 2017.01.12 Hung Nguyen end
								if($this->Auth->user("authority")=="normal") {

										$url=ROOT_DOMAIN.DS."report".DS."index";
        								$this->redirect($url);
										//$this->redirect(array('controller' => 'report', 'action' => 'index'));

								} else {

										$url=ROOT_DOMAIN.DS."Site".DS."index";
                                        $this->redirect($url);
										//$this->redirect(array('controller' => 'site', 'action' => 'index'));
								}
						} else {

								$this->Session->setFlash(__('パスワードが違います。'));
						}
				}

				//if already logged-in, redirect
				if ($this->Session->check('Auth.User')) {

 						$url=ROOT_DOMAIN.DS."Site".DS."index";
                        			$this->redirect($url);
				}

		}

		public function logout() {

			if ($this->Auth->logout()) {

					 $url=ROOT_DOMAIN.DS;
                     $this->redirect($url);
					//$this->redirect(array('controller' => 'login', 'action' => 'index'));
			}
		}
}
