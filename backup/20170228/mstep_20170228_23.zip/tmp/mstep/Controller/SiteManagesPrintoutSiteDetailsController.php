<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

App::uses('ScheduleBaseController','Controller');
class SiteManagesPrintoutSiteDetailsController extends ScheduleBaseController{

        var $name = "SiteManagesPrintoutSiteDetails";
		var $uses = [
		
				"TblMstepSiteDetail",
				"TblMstepSiteWorker",
				"TblMstepWorker",
				"TblMstepTruck",
				"TblMstepScheduleTruck"
		];
	
        function beforeFilter(){

                parent::beforeFilter();
        }

		function __init(){

				$this->unbindFully();
		}

		function __workerInformations($worker_ids){

				if(!$workers=$this->TblMstepWorker->getWorkers($worker_ids,false)) return array();
				$worker_informations=Set::combine($workers,"{n}.TblMstepWorker.id","{n}.TblMstepWorker");
				return $worker_informations;
		}

		function __getTruckInformations($truck_ids=array()){

				$truck_informations=$this->TblMstepTruck->getTrucks($truck_ids,false);
				return Set::combine($truck_informations,"{n}.TblMstepTruck.id","{n}.TblMstepTruck");
		}

		function __checkPostSiteId($site_id){
		
				return !empty($site_id) AND is_numeric($site_id);
		}

		function getPrintInformations(){
		
				$post=$_POST;

				if(!$this->isPostRequest()) exit;

				$site_id=$post["site_id"];
				//$site_id=4;
				if(!$this->__checkPostSiteId($site_id)) Output::__outputStatus(1);
				if(!$information=$this->TblMstepSiteDetail->findByIdAndDelFlg($site_id,0)) Output::__outputStatus(1);

				$site=$information["TblMstepSiteDetail"];
				$customer=$information["TblMstepCustomer"];
				$site_workers=$information["TblMstepSiteWorker"];
				$area=$information["TblMstepAreaInformation"];
				$schedules=$information["TblMstepSiteSchedule"];

				$schedule_informations=array();
				if(!empty($schedules)) $schedule_informations=Set::combine($schedules,"{n}.id","{n}");
				$schedule_ids=array_keys($schedule_informations);

				$truck_informations=array();

				$schedule_trucks=$this->TblMstepScheduleTruck->getScheduleTrucks($schedule_ids,false);
				if(!empty($schedule_trucks)){

						$truck_ids=Set::extract($schedule_trucks,"{}.TblMstepScheduleTruck.truck_id");
						$truck_informations=$this->__getTruckInformations($truck_ids);
				}

				$worker_informations=array();
				if(!empty($site_workers)){

						$worker_ids=array_unique(Set::extract($site_workers,"{}.worker_id"));
						$worker_informations=$this->__workerInformations($worker_ids);
				}

				$tsv=new TSV();
				$prefs=$tsv->getTSV("pref");

				$output["data"]["site_detail"]["name"] =$site["name"];
				$output["data"]["site_detail"]["ninku"]=$site["power_num"];
				$output["data"]["site_detail"]["remarks"]=$site["remarks"];
				$output["data"]["location"]["pref"]   =(!empty($site["area_id"])?$prefs[$area["pref_id"]]:"");
				$output["data"]["location"]["address"]=(!empty($site["area_id"])?$area["address1"]:"");
				$output["data"]["location"]["town"]   =$site["address"];
				$output["data"]["customer"]["name"]   =$customer["name"];

				$output["data"]["worker"]=array();
				foreach($site_workers as $k=>$v){
				
						$worker_id=$v["worker_id"];
						$schedule_id=$v["schedule_id"];
						$worker_information=$worker_informations[$worker_id];
						$schedule_information=$schedule_informations[$schedule_id];
						$date="{$schedule_information["start_month_prefix"]}{$schedule_information["start_day"]}";

						if(!isset($output["data"]["worker"][$date])) $output["data"]["worker"][$date]=array();
						$counter=count($output["data"]["worker"][$date]);
						$output["data"]["worker"][$date][$counter]["first_name"]=$worker_information["first_name"];
						$output["data"]["worker"][$date][$counter]["last_name"] =$worker_information["last_name"];
						$output["data"]["worker"][$date][$counter]["nickname"]  =$worker_information["nickname"];
				}

				$output["data"]["truck"]=array();
				foreach($schedule_trucks as $k=>$v){
				
						$schedule_truck=$v["TblMstepScheduleTruck"];
						$schedule_id=$schedule_truck["schedule_id"];
						$truck_id=$schedule_truck["truck_id"];
						$schedule_information=$schedule_informations[$schedule_id];
						$truck_information=$truck_informations[$truck_id];
						$date="{$schedule_information["start_month_prefix"]}{$schedule_information["start_day"]}";

						if(!isset($output["data"]["truck"][$date])) $output["data"]["truck"][$date]=array();
						$counter=count($output["data"]["truck"][$date]);
						$output["data"]["truck"][$date][$counter]["name"]=$truck_information["name"];
				}

				Output::__outputYes($output);
		}

}//END class

?>
