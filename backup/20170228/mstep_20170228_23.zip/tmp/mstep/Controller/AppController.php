<?php

require_once "tsv.php";
require_once "output.php";
require_once "SetModel.php";

/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package     app.Controller
 * @link        http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

	var $ext = ".html";
	var $client_id;
	var $check_authentication;
	var $role_num=0;

	public $components = array(
		'Session',
		'Auth' => array(
			'loginAction' => array(
	            'controller' => 'login',
	            'action' => 'index',
	        ),
			'loginRedirect' => array('controller' => 'site', 'action' => 'index'),
			'logoutRedirect' => array('controller' => 'login', 'action' => 'index'),
			'authenticate' => array(
				'Form' => array(
					'userModel' => 'TblMstepLogin',
					'fields' => array('username' => 'login_id',
						'password' => 'login_pass'),
				),
			),
			'authorize' => array('Controller'),
		),
	);

	function __getLogPath(){

			$controller=$this->params["controller"];
			$action    =$this->params["action"];
			$log_path=LOGS."post".DS."{$controller}_{$action}.txt";
			return $log_path;
	}

	function beforeFilter() {

			parent::beforeFilter();

			$this->__noCache();

			if($this->data){

					$post=$this->data;
					$log_path=$this->__getLogPath();
					@file_put_contents($log_path,serialize($post));
			}

			// define client info session
			$this->Session->write('CLIENT_INFO',Configure::read('CLIENT_INFO'));

			if(!defined("UNIQUE_KEY")) define("UNIQUE_KEY",CLIENT);

			// Update 2017.01.10 Hung Nguyen start
			// add sub_master for role
			//$this->check_authentication = $this->Auth->user("authority") === "master";
			$this->check_authentication = in_array($this->Auth->user("authority"), ["master", "sub_master"]);
			if($this->check_authentication===true) $this->role_num=1;

			// Update 2017.01.10 Hung Nguyen end
			$this->set('role', $this->check_authentication);
			$this->set('is_edit', $this->role_num);
			$this->set("controller",$this->params["controller"]);
			$this->set("user_id",(!$this->Auth->user("id"))?0:$this->Auth->user("id"));
			$this->set("user_name",($this->Auth->user("first_name").$this->Auth->user("last_name")));
	}

	function __output($res = array()) {

		Configure::write("debug", 0);
		Output::__output($res);
	}

	/**
	 * Determines if authorized.
	 *
	 * @author Nguyen Chat Hien
	 */
	public function isAuthorized($user) {

		// Admin can access every action
	    // Update 2017.01.10 Hung Nguyen start
	    // add sub_master for role
		//if (isset($user['authority']) && $user['authority'] === 'master') {
		//	return true;
		//}

		if(isset($user['authority']) && in_array($this->Auth->user("authority"), ["master", "sub_master"])){
		    return true;
		}
		// Update 2017.01.10 Hung Nguyen end

		// Default deny
		throw new unAuthorizedException();
	}

	#
	# @author Kiyosawa
	# @date 2011/05/07 14:44:59
	function beforeRender() {

		parent::beforeRender();
	}

	function __arrangeAry($data = array(), $key) {

		$res = array();
		foreach ($data as $k => $v) {

			$__data = current($v);
			$res[$__data[$key]] = $__data;
			unset($res[$__data[$key]][$key]);
		}

		return $res;
	}

	function isPrimaryKey($data = array(), $key) {

		$res = array();
		foreach ($data as $k => $v) {

			$__data = current($v);
			$res[$__data[$key]] = $__data;
		}

		return $res;
	}

		function __multiInsert(Model $model,$inserts=array()){

				try{

						$model->multiInsert($inserts);

				}catch(Exception $e){

						$res["status"]=false;
						$res["message"]=$e->getMessage();
						$res["errorNo"]=1;
						return $res;
				}

				$res["status"]=true;
				return $res;
		}

		function unbindFully(){

				if(empty($this->uses)) return;
				foreach($this->uses as $k=>$model) $this->$model->recursive=-1;
		}

		function isPostRequest(){

				if(in_array(DEVELOP_MODE,array("local","dev"))) return true;
				return $this->request->is("post");
		}

		function __noCache(){
		
				header('Cache-Control: no-cache,no-store,must-revalidate');
				header('Cache-Control: pre-check=0,post-check=0',FALSE);
				header('Pragma: no-cache');
				header('Expires: Mon, 26 Jul 1997 13:00:00 GMT');
				header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');	
		}

}

?>

