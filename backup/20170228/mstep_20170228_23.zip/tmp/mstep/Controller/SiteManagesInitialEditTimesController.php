<?php
/*  ------------------------------------------------------------
AQUA Framework 2.01 customed cake.1.2
(C)BANEXJAPAN 2006-2009 All Rights Reserved.
------------------------------------------------------------  */

require_once "Schedule".DS."ScheduleLog.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigation.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationKeys.php";
require_once "TimeoutInvestigation".DS."TimeoutInvestigationExec.php";

App::uses('ScheduleBaseController','Controller');
class SiteManagesInitialEditTimesController extends ScheduleBaseController{

        var $name = "SiteManagesInitialEditTimes";
        var $uses = [

                "TblMstepScheduleLog",
				"TblMstepMasterUser"
        ];

        function beforeFilter(){

                parent::beforeFilter();
        }

		//edit_time は変更しない
		//no need to change the value of edit_time.
		function initScheduleLog(){
	
				$post     =$this->data;

				//$log_path=$this->__getLogPath();
				//$post=unserialize(file_get_contents($log_path));

				$user_id  =$post["user_id"];
				$local_time_key=isset($post["local_time_key"])?$post["local_time_key"]:false;
				$last_edit_time =isset($post["last_edit_time"])?$post["last_edit_time"]:false;

				$this->__isEditAuthorityOutput($user_id,$last_edit_time,$local_time_key);

				$instance=ScheduleLog::getInstance($this);
				if(!$instance->timeInitialize($user_id)) Output::__outputNo();
				$last_edit_time=$instance->getLastEditTime();

				$output["last_edit_time"]=$last_edit_time;
				Output::__outputYes($output);
		}

}//END class

?>
