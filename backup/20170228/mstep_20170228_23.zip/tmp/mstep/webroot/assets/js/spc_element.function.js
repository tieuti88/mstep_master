//■キャッシュ
$.fn.setDocumentCache=function(list,name){

		var origin=this.find("input[type=hidden]"+((!!name)?"[name=\""+name+"\"]":""));
		var origin_length=origin.size();
	
		//■1つの場合は編集可能か評価
		if(list.length==1 && origin_length==1){
			origin.val(list[0]);
			return this;	
		}
	
		if(origin_length>0) origin.remove();
	
		var attr={"type":"hidden"};
		if(!!name) attr["name"]=name;
	
		var fragment=document.createDocumentFragment();
		var origin=$("<input>").attr(attr);
		var hidden;
		for(var i in list){

				hidden=origin.clone();
				hidden.val(list[i]);
				fragment.appendChild(hidden.get(0));
		}
		this.get(0).appendChild(fragment);
		return this;
}

//■キャッシュ取得
$.fn.getDocumentCache=function(name){

		var	elem=this.find("input[type=hidden]"+((!!name)?"[name=\""+name+"\"]":"")); 
		var list=[];
		for(var i=0;i<elem.size();i++) list.push(elem.eq(i).val());
		return list;
}

$.fn.isDisplay=function(){

		return this.css("display")!="none";
}
